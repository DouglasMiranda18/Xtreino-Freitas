// ==================== TOAST NOTIFICATION SYSTEM ====================
let confirmResolve = null;
const CAMP_SEMIFINAL_DATES = ['2024-11-22','2024-11-23','2025-11-22','2025-11-23'];
const CAMP_FINAL_DATES = ['2024-11-28','2025-11-28'];
let campSemifinalLinks = {};
let campSemifinalLinksLoaded = false;

function showToast(type, message, title = null, duration = 5000) {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: '✓',
        error: '✕',
        info: 'ℹ',
        warning: '⚠'
    };
    
    const titles = {
        success: 'Sucesso',
        error: 'Erro',
        info: 'Informação',
        warning: 'Atenção'
    };

    toast.innerHTML = `
        <div class="toast-icon">${icons[type] || 'ℹ'}</div>
        <div class="toast-content">
            ${title ? `<div class="toast-title">${title}</div>` : ''}
            <div class="toast-message">${message}</div>
        </div>
        <button class="toast-close" onclick="removeToast(this.parentElement)">
            <i class="fas fa-times"></i>
        </button>
    `;

    container.appendChild(toast);

    // Auto remove after duration
    if (duration > 0) {
        setTimeout(() => {
            removeToast(toast);
        }, duration);
    }

    return toast;
}

function removeToast(toast) {
    if (!toast) return;
    toast.classList.add('toast-exit');
    setTimeout(() => {
        if (toast.parentElement) {
            toast.parentElement.removeChild(toast);
        }
    }, 300);
}

// Replace alert() with toast
window.alert = function(message) {
    showToast('info', message, null, 4000);
};

// Elegant confirmation modal
function showConfirm(title, message, confirmText = 'Confirmar', cancelText = 'Cancelar') {
    
    return new Promise((resolve) => {
        const modal = document.getElementById('confirmModal');
        const titleEl = document.getElementById('confirmTitle');
        const messageEl = document.getElementById('confirmMessage');
        const okBtn = document.getElementById('confirmOkBtn');
        
        
        
        if (!modal || !titleEl || !messageEl || !okBtn) {
            console.error('❌ Um ou mais elementos do modal não encontrados!');
            resolve(false);
            return;
        }

        titleEl.textContent = title || 'Confirmar';
        messageEl.textContent = message || '';
        okBtn.textContent = confirmText;
        
        confirmResolve = resolve;
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        
    });
}

function closeConfirmModal() {
    
    const modal = document.getElementById('confirmModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    if (confirmResolve) {
        
        confirmResolve(false);
        confirmResolve = null;
    }
}

function handleConfirmOk() {
    
    
    if (!confirmResolve) {
        console.error('  ❌ confirmResolve é null! Cancelando...');
        closeConfirmModal();
        return;
    }
    
    
    const resolve = confirmResolve;
    confirmResolve = null; // Limpar ANTES de resolver
    const modal = document.getElementById('confirmModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    resolve(true); // Resolver após limpar
    
}

// Replace confirm() with elegant modal
window.confirm = function(message) {
    
    return showConfirm('Confirmar', message);
};

// Helper functions for different toast types
window.showSuccessToast = function(message, title = 'Sucesso') {
    showToast('success', message, title);
};

window.showErrorToast = function(message, title = 'Erro') {
    showToast('error', message, title);
};

window.showInfoToast = function(message, title = 'Informação') {
    showToast('info', message, title);
};

window.showWarningToast = function(message, title = 'Atenção') {
    showToast('warning', message, title);
};

// Admin RBAC and dashboards - Enhanced Security
(async function(){
  // Security: Check if running in admin context
  if (!window.location.pathname.includes('admin.html') && !window.location.pathname.includes('admin')) {
    console.warn('Admin script loaded outside admin context');
    return;
  }

  // Wait firebase
  const waitReady = () => new Promise(res => {
    const tick = () => {
      if (window.firebaseReady && window.firebaseDb && window.firebaseAuth) {
        
        res();
      } else {
        console.log('⏳ Aguardando inicialização do Firebase...', {
          firebaseReady: window.firebaseReady,
          firebaseDb: !!window.firebaseDb,
          firebaseAuth: !!window.firebaseAuth
        });
        setTimeout(tick, 100);
      }
    };
    tick();
  });
  await waitReady();

  const { onAuthStateChanged, signInWithEmailAndPassword, sendPasswordResetEmail, signOut } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js');
  const { collection, getDocs, doc, updateDoc, query, where, orderBy, getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');

  // Security: Admin email whitelist (configure these)
  const ADMIN_EMAILS = [
    'cleitondouglass@gmail.com',
    'cleitondouglass123@hotmail.com',
    'gilmariofreitas378@gmail.com',
    'gilmariofreitas387@gmail.com',
    'flavetyr@gmail.com'
  ];

  // Security: Session timeout (30 minutes)
  const SESSION_TIMEOUT = 30 * 60 * 1000;
  let sessionTimer = null;

  const authGate = document.getElementById('authGate');
  const dashboard = document.getElementById('dashboard');
  const roleBadge = document.getElementById('roleBadge');
  const loginError = document.getElementById('loginError');
  const loginInfo = document.getElementById('loginInfo');

  // Security: Check if user is authorized admin
  async function isAuthorizedAdmin(user) {
    if (!user || !user.email) return false;    
  
    // Check user role in Firestore
    try {
      
      const userDoc = await getDoc(doc(window.firebaseDb, 'users', user.uid));
      if (!userDoc.exists()) {       
        
        // Criar documento do usuário automaticamente
        const { setDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const userData = {
          email: user.email,
          displayName: user.displayName || user.email.split('@')[0],
          role: 'socio', // Definir como socio por padrão
          createdAt: new Date(),
          lastLogin: Date.now()
        };
        
        await setDoc(doc(window.firebaseDb, 'users', user.uid), userData);
        
        
        // Agora tentar novamente
        const newUserDoc = await getDoc(doc(window.firebaseDb, 'users', user.uid));
        if (!newUserDoc.exists()) {
          
          return false;
        }
        
        const newUserData = newUserDoc.data();
        const role = (newUserData.role || '').toLowerCase();
        
        
        if (role === 'socio' || role === 'sócio' || role === 'ceo') {
          
          return true;
        }
        
        return false;
      }
      
      const userData = userDoc.data();
      const role = (userData.role || '').toLowerCase();
      
      
      
      
      // Para socio, permitir acesso total
      if (role === 'socio' || role === 'sócio' || role === 'ceo') {
        
        return true;
      }
      
      const isAuthorized = ['admin', 'gerente', 'vendedor', 'design', 'designer', 'desgin'].includes(role);
      
      
      return isAuthorized;
    } catch (error) {
      console.error('❌ Erro ao verificar cargo:', error);
      return false;
    }
  }

  // Security: Session management
  function startSessionTimer() {
    if (sessionTimer) clearTimeout(sessionTimer);
    sessionTimer = setTimeout(() => {
      
      logout();
    }, SESSION_TIMEOUT);
  }

  function resetSessionTimer() {
    startSessionTimer();
  }

  // Security: Enhanced logout
  async function logout() {
    try {
      await signOut(window.firebaseAuth);
      sessionStorage.removeItem('adminSession');
      localStorage.removeItem('adminSession');
      if (sessionTimer) clearTimeout(sessionTimer);
      showAuthGate();
    } catch (error) {
      console.error('Logout error:', error);
    }
  }

  // Security: Show login form
  function showAuthGate() {
    authGate.classList.remove('hidden');
    dashboard.classList.add('hidden');
    document.body.style.overflow = 'auto';
  }

  // Security: Show dashboard
  function showDashboard(userRole) {
    authGate.classList.add('hidden');
    dashboard.classList.remove('hidden');
    setView(userRole);
    startSessionTimer();
    // NÃO chamar controlSectionVisibility aqui - será chamado no onAuthStateChanged após carregar dados
  }
  
  // Expor showDashboard globalmente imediatamente
  window.showDashboard = showDashboard;

  // Control section visibility based on role
  function controlSectionVisibility(userRole) {
    const role = (userRole || '').toLowerCase().trim();
    
    // Prevenir múltiplas chamadas conflitantes - se já foi aplicado para este role, não aplicar novamente
    if (window.lastAppliedRole === role && window.visibilityApplied) {
      
      return;
    }
    
    
    window.lastAppliedRole = role;
    window.visibilityApplied = true;
    
    // Get all section elements
    const sectionKPIs = document.getElementById('sectionKPIs');
    const sectionFilters = document.getElementById('sectionFilters');
    const sectionCharts = document.getElementById('sectionCharts');
    const sectionUsers = document.getElementById('sectionUsers');
    const sectionTokenStats = document.getElementById('sectionTokenStats');
    const sectionUsersManagement = document.getElementById('sectionUsersManagement');
    const sectionTokens = document.getElementById('sectionTokens');
    const sectionCoupons = document.getElementById('sectionCoupons');
    const sectionCouponUsage = document.getElementById('sectionCouponUsage');
    const sectionAffiliates = document.getElementById('sectionAffiliates');
    const sectionAffiliateSales = document.getElementById('sectionAffiliateSales');
    const sectionPasseBooyah = document.getElementById('sectionPasseBooyah');
    const sectionHighlights = document.getElementById('sectionHighlights');
    const sectionNews = document.getElementById('sectionNews');
    const sectionProducts = document.getElementById('sectionProducts');
    const sectionEventsSection = document.getElementById('sectionEvents');
    const sectionSchedules = document.getElementById('sectionSchedules');
    const sectionAdminHistory = document.getElementById('sectionAdminHistory');
    const sectionAffiliatePanel = document.getElementById('sectionAffiliatePanel');
    
    // Ocultar todas as seções por padrão
    if (sectionKPIs) sectionKPIs.style.display = 'none';
    if (sectionFilters) sectionFilters.style.display = 'none';
    if (sectionCharts) sectionCharts.style.display = 'none';
    if (sectionUsers) sectionUsers.style.display = 'none';
    if (sectionTokenStats) sectionTokenStats.style.display = 'none';
    if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
    if (sectionTokens) sectionTokens.style.display = 'none';
    if (sectionCoupons) sectionCoupons.style.display = 'none';
    if (sectionCouponUsage) sectionCouponUsage.style.display = 'none';
    if (sectionAffiliates) sectionAffiliates.style.display = 'none';
    if (sectionAffiliateSales) sectionAffiliateSales.style.display = 'none';
    if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'none';
    if (sectionProducts) sectionProducts.style.display = 'none';
    if (sectionEventsSection) sectionEventsSection.style.display = 'none';
    if (sectionSchedules) sectionSchedules.style.display = 'none';
    if (sectionHighlights) sectionHighlights.style.display = 'none';
    if (sectionNews) sectionNews.style.display = 'none';
    if (sectionAdminHistory) sectionAdminHistory.style.display = 'none';
    if (sectionAffiliatePanel) sectionAffiliatePanel.style.display = 'none';
    
    // Staff: Apenas seção de agendamentos (14h às 18h, xtreino-tokens)
    if (role === 'staff') {
      // Mostrar apenas seção de agendamentos
      if (sectionSchedules) {
        sectionSchedules.style.display = 'block';
        sectionSchedules.classList.remove('hidden');
      }
      
      // Ocultar todas as outras seções
      if (sectionKPIs) sectionKPIs.style.display = 'none';
      if (sectionFilters) sectionFilters.style.display = 'none';
      if (sectionCharts) sectionCharts.style.display = 'none';
      if (sectionUsers) sectionUsers.style.display = 'none';
      if (sectionTokenStats) sectionTokenStats.style.display = 'none';
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
      if (sectionTokens) sectionTokens.style.display = 'none';
      if (sectionCoupons) sectionCoupons.style.display = 'none';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'none';
      if (sectionAffiliates) sectionAffiliates.style.display = 'none';
      if (sectionAffiliateSales) sectionAffiliateSales.style.display = 'none';
      if (sectionAffiliatePanel) sectionAffiliatePanel.style.display = 'none';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'none';
      if (sectionProducts) sectionProducts.style.display = 'none';
      if (sectionHighlights) sectionHighlights.style.display = 'none';
      if (sectionNews) sectionNews.style.display = 'none';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'none';
      
      
      return; // Sair da função para não aplicar outras regras
    }
    
    // Afiliado: Apenas painel de afiliado
    if (role === 'afiliado') {
      // Mostrar apenas painel do afiliado
      if (sectionAffiliatePanel) {
        sectionAffiliatePanel.style.display = 'block';
        sectionAffiliatePanel.classList.remove('hidden');
      }
      
      // Ocultar todas as outras seções
      if (sectionKPIs) sectionKPIs.style.display = 'none';
      if (sectionFilters) sectionFilters.style.display = 'none';
      if (sectionCharts) sectionCharts.style.display = 'none';
      if (sectionUsers) sectionUsers.style.display = 'none';
      if (sectionTokenStats) sectionTokenStats.style.display = 'none';
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
      if (sectionTokens) sectionTokens.style.display = 'none';
      if (sectionCoupons) sectionCoupons.style.display = 'none';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'none';
      if (sectionAffiliates) sectionAffiliates.style.display = 'none';
      if (sectionAffiliateSales) sectionAffiliateSales.style.display = 'none';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'none';
      if (sectionProducts) sectionProducts.style.display = 'none';
      if (sectionSchedules) sectionSchedules.style.display = 'none';
      if (sectionHighlights) sectionHighlights.style.display = 'none';
      if (sectionNews) sectionNews.style.display = 'none';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'none';
      
      

          
      return; // Sair da função para não aplicar outras regras
    }
    
    // Design: Apenas destaques e notícias
    if (role === 'design' || role === 'desgin' || role === 'designer') {
      // Mostrar apenas Notícias e Destaques
      if (sectionHighlights) sectionHighlights.style.display = 'block';
      if (sectionNews) sectionNews.style.display = 'block';
      
      // Ocultar todas as outras seções
      if (sectionKPIs) sectionKPIs.style.display = 'none';
      if (sectionFilters) sectionFilters.style.display = 'none';
      if (sectionCharts) sectionCharts.style.display = 'none';
      if (sectionUsers) sectionUsers.style.display = 'none';
      if (sectionTokenStats) sectionTokenStats.style.display = 'none';
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
      if (sectionTokens) sectionTokens.style.display = 'none';
      if (sectionCoupons) sectionCoupons.style.display = 'none';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'none';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'none';
      if (sectionProducts) sectionProducts.style.display = 'none';
      if (sectionSchedules) sectionSchedules.style.display = 'none';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'none';
    }
    // Sócio: Limited access - only basic sections
    else if (role === 'socio' || role === 'sócio') {
      // Mostrar apenas seções básicas para sócio
      if (sectionKPIs) sectionKPIs.style.display = 'block';
      if (sectionFilters) sectionFilters.style.display = 'block';
      if (sectionCharts) sectionCharts.style.display = 'block';
      if (sectionUsers) sectionUsers.style.display = 'block';
      if (sectionTokenStats) sectionTokenStats.style.display = 'block';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'block';
      
      if (sectionPasseBooyah) {
        sectionPasseBooyah.style.display = 'block';
        
      }
      
      if (sectionSchedules) {
        sectionSchedules.style.display = 'block';
        
      } 
      
      // Ocultar seções administrativas
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
      if (sectionTokens) sectionTokens.style.display = 'none';
      if (sectionCoupons) sectionCoupons.style.display = 'none';
      if (sectionProducts) sectionProducts.style.display = 'none';
      if (sectionEventsSection) sectionEventsSection.style.display = 'none';
      if (sectionHighlights) sectionHighlights.style.display = 'none';
      if (sectionNews) sectionNews.style.display = 'none';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'none';
      
      
    }
    // CEO: Can see and edit everything
    else if (role === 'ceo' || role === 'ceo') {
      
      // Mostrar todas as seções
      if (sectionKPIs) sectionKPIs.style.display = 'block';
      if (sectionFilters) sectionFilters.style.display = 'block';
      if (sectionCharts) sectionCharts.style.display = 'block';
      if (sectionUsers) sectionUsers.style.display = 'block';
      if (sectionTokenStats) sectionTokenStats.style.display = 'block';
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'block';
      if (sectionTokens) sectionTokens.style.display = 'block';
      if (sectionCoupons) sectionCoupons.style.display = 'block';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'block';
      if (sectionAffiliates) sectionAffiliates.style.display = 'block';
      if (sectionAffiliateSales) sectionAffiliateSales.style.display = 'block';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'block';
      if (sectionProducts) sectionProducts.style.display = 'block';
      if (sectionEventsSection) { sectionEventsSection.style.display = 'block'; loadEventsPreview(); }
      if (sectionSchedules) sectionSchedules.style.display = 'block';
      if (sectionHighlights) sectionHighlights.style.display = 'block';
      if (sectionNews) sectionNews.style.display = 'block';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'block';
      
    }
    // Admin: Can see and edit everything
    else if (role === 'admin') {
      // Mostrar todas as seções
      if (sectionKPIs) sectionKPIs.style.display = 'block';
      if (sectionFilters) sectionFilters.style.display = 'block';
      if (sectionCharts) sectionCharts.style.display = 'block';
      if (sectionUsers) sectionUsers.style.display = 'block';
      if (sectionTokenStats) sectionTokenStats.style.display = 'block';
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'block';
      if (sectionTokens) sectionTokens.style.display = 'block';
      if (sectionCoupons) sectionCoupons.style.display = 'block';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'block';
      if (sectionAffiliates) sectionAffiliates.style.display = 'block';
      if (sectionAffiliateSales) sectionAffiliateSales.style.display = 'block';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'block';
      if (sectionProducts) sectionProducts.style.display = 'block';
      if (sectionEventsSection) { sectionEventsSection.style.display = 'block'; loadEventsPreview(); }
      if (sectionSchedules) sectionSchedules.style.display = 'block';
      if (sectionHighlights) sectionHighlights.style.display = 'block';
      if (sectionNews) sectionNews.style.display = 'block';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'block';
    }
    // Gerente: Acesso a vendas gerais do mês
    else if (role === 'gerente') {
      // Mostrar seções de vendas e relatórios gerais
      if (sectionKPIs) sectionKPIs.style.display = 'block';
      if (sectionFilters) sectionFilters.style.display = 'block';
      if (sectionCharts) sectionCharts.style.display = 'block';
      if (sectionTokenStats) sectionTokenStats.style.display = 'block';
      if (sectionUsers) sectionUsers.style.display = 'block';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'block';
      
      // Ocultar seções administrativas específicas
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
      if (sectionTokens) sectionTokens.style.display = 'none';
      if (sectionCoupons) sectionCoupons.style.display = 'none';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'none';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'none';
      if (sectionProducts) sectionProducts.style.display = 'none';
      if (sectionEventsSection) sectionEventsSection.style.display = 'none';
      // Gerente também pode ver e operar o controle de horários
      if (sectionSchedules) sectionSchedules.style.display = 'block';
      // Exibir Notícias e Destaques para leitura (edições já são limitadas por permissões)
      if (sectionHighlights) sectionHighlights.style.display = 'block';
      if (sectionNews) sectionNews.style.display = 'block';
    }
    // Vendedor: Vendas recentes, cupons, vendas para aprovação, controle de passe e gerenciamento de tokens
    else if (role === 'vendedor') {
      // Mostrar seções específicas para vendedor
      if (sectionKPIs) sectionKPIs.style.display = 'block';
      if (sectionCharts) sectionCharts.style.display = 'block';
      if (sectionTokenStats) sectionTokenStats.style.display = 'block';
      if (sectionTokens) sectionTokens.style.display = 'block';
      if (sectionCoupons) sectionCoupons.style.display = 'block';
      if (sectionCouponUsage) sectionCouponUsage.style.display = 'block';
      if (sectionPasseBooyah) sectionPasseBooyah.style.display = 'block';
      if (sectionUsers) sectionUsers.style.display = 'block';
      
      // Ocultar seções administrativas
      if (sectionFilters) sectionFilters.style.display = 'none';
      if (sectionUsersManagement) sectionUsersManagement.style.display = 'none';
      if (sectionProducts) sectionProducts.style.display = 'none';
      if (sectionEventsSection) sectionEventsSection.style.display = 'none';
      if (sectionSchedules) sectionSchedules.style.display = 'none';
      if (sectionHighlights) sectionHighlights.style.display = 'none';
      if (sectionNews) sectionNews.style.display = 'none';
      if (sectionAdminHistory) sectionAdminHistory.style.display = 'none';
    }
    
  }
  // Control edit permissions based on role
  function controlEditPermissions(userRole) {
    const role = (userRole || '').toLowerCase();
    
    // Get all input elements, buttons, and editable elements
    const inputs = document.querySelectorAll('input, textarea, select');
    const buttons = document.querySelectorAll('button');
    const editButtons = document.querySelectorAll('.edit-btn, .save-btn, .delete-btn, .add-btn, [class*="btn"]');
    const editableElements = document.querySelectorAll('[contenteditable="true"]');
    
    // Combine all editable elements
    const allEditableElements = [...inputs, ...buttons, ...editButtons, ...editableElements];
    
    
    // Design: Can only edit highlights and news sections
    if (role === 'design' || role === 'desgin' || role === 'designer') {
      
      allEditableElements.forEach((element, index) => {
        // Check if element is in highlights or news sections
        const isInHighlights = element.closest('#sectionHighlights');
        const isInNews = element.closest('#sectionNews');
        
        if (isInHighlights || isInNews) {
          // Enable editing for highlights and news
          element.disabled = false;
          element.readOnly = false;
          element.style.pointerEvents = 'auto';
          element.style.opacity = '1';
        } else {
          // Disable editing for all other sections
          element.disabled = true;
          element.readOnly = true;
          element.style.pointerEvents = 'none';
          element.style.opacity = '0.5';
        }
      });
      
    }
    // Sócio: acesso somente leitura (CEO NÃO entra aqui)
    else if (role === 'socio' || role === 'sócio') {
      
      allEditableElements.forEach(element => {
        element.disabled = true;
        element.readOnly = true;
        element.style.pointerEvents = 'none';
        element.style.opacity = '0.5';
      });
      
    }
    // CEO, Admin, Gerente: acesso total de edição
    else if (role === 'ceo' || role === 'admin' || role === 'gerente') {
      
      allEditableElements.forEach(element => {
        element.disabled = false;
        element.readOnly = false;
        element.style.pointerEvents = 'auto';
        element.style.opacity = '1';
      });
      
    }
    // Vendedor: Limited edit access
    else if (role === 'vendedor') {
      
      allEditableElements.forEach(element => {
        // Vendedor can edit in specific sections: tokens, coupons, passe, users
        const isInAllowedSection = element.closest('#sectionTokens, #sectionCoupons, #sectionCouponUsage, #sectionPasseBooyah, #sectionUsers, #sectionKPIs, #sectionCharts');
        
        if (isInAllowedSection) {
          element.disabled = false;
          element.readOnly = false;
          element.style.pointerEvents = 'auto';
          element.style.opacity = '1';
        } else {
          element.disabled = true;
          element.readOnly = true;
          element.style.pointerEvents = 'none';
          element.style.opacity = '0.5';
        }
      });
      
    }
    
  }

  // Security: Show login error
  function showLoginError(message) {
    loginError.textContent = message;
    loginError.classList.remove('hidden');
    setTimeout(() => {
      loginError.classList.add('hidden');
    }, 5000);
  }

  function showLoginInfo(message) {
    if (!loginInfo) return;
    loginInfo.textContent = message;
    loginInfo.classList.remove('hidden');
    setTimeout(() => {
      loginInfo.classList.add('hidden');
    }, 7000);
  }

  // Forgot password handler
  const forgotBtn = document.getElementById('btnForgotPassword');
  if (forgotBtn) {
    forgotBtn.addEventListener('click', async () => {
      try {
        const emailInput = document.getElementById('adminEmail');
        const email = (emailInput?.value || '').trim();
        if (!email) {
          showLoginError('Informe seu email para redefinir a senha.');
          return;
        }
        await sendPasswordResetEmail(window.firebaseAuth, email);
        showLoginInfo('Enviamos um email com o link para redefinir sua senha.');
      } catch (err) {
        console.error('Erro ao enviar reset de senha:', err);
        const msg = (err && err.code) ? String(err.code) : 'Falha ao enviar email de redefinição.';
        showLoginError(msg.replace('auth/', '').replaceAll('-', ' '));
      }
    });
  }

  function setView(authRole){
    const role = (authRole||'').toLowerCase();
    roleBadge.textContent = `Permissão: ${authRole||'desconhecida'}`;
    
    // Apply role-based section visibility and edit permissions with a delay to ensure DOM is ready
    // REMOVIDO: controlSectionVisibility agora é chamada após carregamento de dados no onAuthStateChanged
    
    // Apply edit permissions with a longer delay to ensure all elements are loaded
    setTimeout(() => {
      controlEditPermissions(role);
      
      // Verificação adicional para vendedor - garantir que elementos estejam habilitados
      if (role === 'vendedor') {
        const allowedSections = ['sectionTokens', 'sectionCoupons', 'sectionCouponUsage', 'sectionPasseBooyah', 'sectionUsers', 'sectionKPIs', 'sectionCharts'];
        
        allowedSections.forEach(sectionId => {
          const section = document.getElementById(sectionId);
          if (section) {
            const elements = section.querySelectorAll('input, textarea, select, button, [contenteditable="true"]');
            elements.forEach(element => {
              // Só habilitar se não estiver em uma operação temporária
              if (!element.hasAttribute('data-temp-disabled')) {
                element.disabled = false;
                element.readOnly = false;
                element.style.pointerEvents = 'auto';
                element.style.opacity = '1';
              }
            });
          }
        });
      }
    }, 500);
    
    // Controle de visão
    const kpiCards = document.querySelectorAll('#kpiToday, #kpiMonth, #kpiReceivable');
    const productsCard = document.getElementById('popularHoursChart')?.closest('.bg-white');
    const salesChartCard = document.getElementById('salesChart')?.closest('.bg-white');
    const topProductsCard = document.getElementById('topProductsChart')?.closest('.bg-white');
    
    if (role === 'vendedor'){
      // Vendedor: vê pedidos recentes e KPIs (visibilidade controlada por controlSectionVisibility)
      // Removido: ocultação de KPIs - agora controlado por controlSectionVisibility
      if (productsCard) productsCard.classList.add('hidden');
      if (salesChartCard) salesChartCard.classList.add('hidden');
      if (topProductsCard) topProductsCard.classList.add('hidden');
    } else if (role === 'gerente'){
      // Gerente: vê financeiro, exceto fluxo total mensal e gráfico de Vendas 30d
      const kpiMonthCard = document.getElementById('kpiMonth')?.closest('.bg-white');
      if (kpiMonthCard) kpiMonthCard.classList.add('hidden');
      if (salesChartCard) salesChartCard.classList.add('hidden');
    } else if (role === 'design'){
      // Design: esconde todos os KPIs e gráficos
      kpiCards.forEach(e => e && (e.closest('.bg-white').classList.add('hidden')));
      if (productsCard) productsCard.classList.add('hidden');
      if (salesChartCard) salesChartCard.classList.add('hidden');
      if (topProductsCard) topProductsCard.classList.add('hidden');
    } else if (role === 'socio' || role === 'ceo'){
      // Sócio: vê tudo (read-only)
      // Nenhuma ocultação de elementos
    }
  }

  // Variáveis de paginação
  let usuariosData = [];
  let usuariosPage = 1;
  const usuariosPerPage = 5;
  
  let tokensData = [];
  let tokensPage = 1;
  const tokensPerPage = 3;
  
  let tokenUsageData = [];
  let tokenUsagePage = 1;
  const tokenUsagePerPage = 3;
  
  let confirmedOrdersData = [];
  let confirmedOrdersPage = 1;
  const confirmedOrdersPerPage = 5;

  // Função para carregar usuários do Firestore
  async function carregarUsuarios() {
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;

    try {
      // Verificar se Firebase está inicializado
      if (!window.firebaseDb) {
        console.error('❌ Firebase não inicializado - carregarUsuarios');
        return;
      }
      
      
      // Buscar usuários no Firestore
      const usersRef = collection(window.firebaseDb, 'users');
      const snapshot = await getDocs(usersRef);
      
      
      // Armazenar todos os dados
      usuariosData = [];
      snapshot.forEach(doc => {
        usuariosData.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      // Atualizar contador
      document.getElementById('usersCount').textContent = `${usuariosData.length} usuários`;
      
      // Mostrar primeira página
      mostrarUsuariosPagina(1);
      
    } catch (error) {
      console.error('Erro ao carregar usuários:', error);
      tbody.innerHTML = '<tr><td colspan="2" class="py-6 text-center text-red-500">Erro ao carregar usuários</td></tr>';
    }
  }

  // Função para mostrar usuários da página específica
  function mostrarUsuariosPagina(pagina) {
    const tbody = document.getElementById('usersTableBody');
    const startIndex = (pagina - 1) * usuariosPerPage;
    const endIndex = startIndex + usuariosPerPage;
    const usuariosPagina = usuariosData.slice(startIndex, endIndex);
    
    // Limpar tabela
    tbody.innerHTML = '';
    
    // Adicionar usuários da página
    usuariosPagina.forEach(user => {
      const row = document.createElement('tr');
      row.className = 'border-b border-gray-100 hover:bg-gray-50';
      
      row.innerHTML = `
        <td class="py-2 px-2">${user.email || 'Email não informado'}</td>
        <td class="py-2 px-2">
          <select class="role-select border border-gray-300 rounded px-2 py-1 text-xs" data-uid="${user.id}">
            <option value="Vendedor" ${user.role === 'Vendedor' ? 'selected' : ''}>Vendedor</option>
            <option value="Gerente" ${user.role === 'Gerente' ? 'selected' : ''}>Gerente</option>
            <option value="Ceo" ${user.role === 'Ceo' ? 'selected' : ''}>Ceo</option>
          </select>
        </td>
      `;
      
      tbody.appendChild(row);
    });
    
    // Atualizar informações de paginação
    const totalPages = Math.ceil(usuariosData.length / usuariosPerPage);
    document.getElementById('usersPageInfo').textContent = `Página ${pagina} de ${totalPages}`;
    
    // Gerar botões de paginação
    gerarBotoesPaginacao('usersPagination', pagina, totalPages, (p) => mostrarUsuariosPagina(p));
    
    // Adicionar event listener para mudanças de role
    tbody.addEventListener('change', alterarRole);
  }

  // Função para gerar botões de paginação
  function gerarBotoesPaginacao(containerId, paginaAtual, totalPaginas, callback) {
    const container = document.getElementById(containerId);
    if (!container) return;
    
    container.innerHTML = '';
    
    if (totalPaginas <= 1) return;
    
    // Botão anterior
    if (paginaAtual > 1) {
      const prevBtn = document.createElement('button');
      prevBtn.textContent = '«';
      prevBtn.className = 'px-2 py-1 text-xs bg-gray-200 hover:bg-gray-300 rounded';
      prevBtn.onclick = () => callback(paginaAtual - 1);
      container.appendChild(prevBtn);
    }
    
    // Números das páginas
    const startPage = Math.max(1, paginaAtual - 2);
    const endPage = Math.min(totalPaginas, paginaAtual + 2);
    
    for (let i = startPage; i <= endPage; i++) {
      const pageBtn = document.createElement('button');
      pageBtn.textContent = i;
      pageBtn.className = `px-2 py-1 text-xs rounded ${i === paginaAtual ? 'bg-blue-500 text-white' : 'bg-gray-200 hover:bg-gray-300'}`;
      pageBtn.onclick = () => callback(i);
      container.appendChild(pageBtn);
    }
    
    // Botão próximo
    if (paginaAtual < totalPaginas) {
      const nextBtn = document.createElement('button');
      nextBtn.textContent = '»';
      nextBtn.className = 'px-2 py-1 text-xs bg-gray-200 hover:bg-gray-300 rounded';
      nextBtn.onclick = () => callback(paginaAtual + 1);
      container.appendChild(nextBtn);
    }
  }
  // Função para alterar role do usuário
  async function alterarRole(event) {
    if (!event.target.classList.contains('role-select')) return;
    
    const select = event.target;
    const uid = select.getAttribute('data-uid');
    const novoRole = select.value;
    const email = select.closest('tr').querySelector('td:first-child').textContent;
    
    // Desabilitar select durante a operação
    select.disabled = true;
    select.style.opacity = '0.6';
    select.setAttribute('data-temp-disabled', 'true');
    
    try {
      // Atualizar no Firestore
      const userRef = doc(window.firebaseDb, 'users', uid);
      await updateDoc(userRef, { role: novoRole });
      
      // Mostrar sucesso
      alert(`Role de ${email} alterado para ${novoRole} com sucesso!`);
      
    } catch (error) {
      console.error('Erro ao alterar role:', error);
      alert('Erro ao alterar role. Tente novamente.');
      
      // Reverter select para valor anterior
      select.value = select.getAttribute('data-original-value') || 'Vendedor';
    } finally {
      // Reabilitar select
      select.disabled = false;
      select.style.opacity = '1';
      select.removeAttribute('data-temp-disabled');
    }
  }

  // Função para carregar dados de tokens
  async function carregarDadosTokens() {
    try {
      // Verificar se Firebase está inicializado
      if (!window.firebaseDb) {
        console.error('❌ Firebase não inicializado - carregarDadosTokens');
        return;
      }
      
      // 
      // Buscar pedidos de tokens
      const ordersRef = collection(window.firebaseDb, 'orders');
      const ordersSnapshot = await getDocs(ordersRef);
      // 
      
      tokensData = [];
      ordersSnapshot.forEach(doc => {
        const order = doc.data();
        const status = String(order.status || '').toLowerCase();
        const descriptorRaw = order.description || order.item || order.itemName || order.title || '';
        const descriptor = String(descriptorRaw).toLowerCase();
        // Log detalhado removido
        // Considera tokens se houver menção a "token" em qualquer campo descritivo
        if (descriptor.includes('token')) {
          // Apenas pedidos pagos/confirmados entram nas compras
          if (['paid','approved','confirmed'].includes(status)) {
            const originalDate = order.createdAt ? (order.createdAt.seconds ? new Date(order.createdAt.seconds * 1000) : new Date(order.createdAt)) : new Date(order.timestamp || 0);
            // Tenta extrair quantidade de tokens do texto
            const m = String(descriptorRaw).match(/(\d+)\s*token/i);
            const tokenQty = m ? parseInt(m[1]) : (order.tokens || 1);
            tokensData.push({
              id: doc.id,
              cliente: order.customer || order.customerName || order.buyerEmail || 'Cliente não informado',
              pacote: order.item || order.itemName || order.title || 'Pacote de Tokens',
              tokens: tokenQty,
              valor: order.amount || order.total || 0,
              data: originalDate.toLocaleDateString('pt-BR'),
              originalDate: originalDate
            });
          }
        }
      });
      
      // Ordenar por data (mais recentes primeiro) - usar timestamp original
      tokensData.sort((a, b) => {
        const dateA = a.originalDate || new Date(0);
        const dateB = b.originalDate || new Date(0);
        return dateB - dateA;
      });
      
      // Atualizar contador
      document.getElementById('tokensCount').textContent = `${tokensData.length} compras`;
      document.getElementById('totalTokensPurchased').textContent = tokensData.length;
      // 
      
      // Mostrar primeira página
      mostrarTokensPagina(1);
      
    } catch (error) {
      console.error('Erro ao carregar dados de tokens:', error);
    }
  }

  // Função para mostrar tokens da página específica
  function mostrarTokensPagina(pagina) {
    const tbody = document.getElementById('tokensTbody');
    const startIndex = (pagina - 1) * tokensPerPage;
    const endIndex = startIndex + tokensPerPage;
    const tokensPagina = tokensData.slice(startIndex, endIndex);
    
    // Limpar tabela
    tbody.innerHTML = '';
    
    // Adicionar tokens da página
    tokensPagina.forEach(token => {
      const row = document.createElement('tr');
      row.className = 'border-b border-gray-100 hover:bg-gray-50';
      
      row.innerHTML = `
        <td class="py-1 px-1 text-xs">${token.cliente}</td>
        <td class="py-1 px-1 text-xs">${token.pacote}</td>
        <td class="py-1 px-1 text-xs">${token.tokens}</td>
        <td class="py-1 px-1 text-xs">${token.valor}</td>
        <td class="py-1 px-1 text-xs">${token.data}</td>
      `;
      
      tbody.appendChild(row);
    });
    
    // Atualizar informações de paginação
    const totalPages = Math.ceil(tokensData.length / tokensPerPage);
    document.getElementById('tokensPageInfo').textContent = `Página ${pagina} de ${totalPages}`;
    
    // Gerar botões de paginação
    gerarBotoesPaginacao('tokensPurchasesPagination', pagina, totalPages, (p) => mostrarTokensPagina(p));
  }

  // Função para carregar dados de uso de tokens
  async function carregarDadosUsoTokens() {
    try {
      // Verificar se Firebase está inicializado
      if (!window.firebaseDb) {
        console.error('❌ Firebase não inicializado - carregarDadosUsoTokens');
        return;
      }
      
      // Buscar registros de uso de tokens
      const registrationsRef = collection(window.firebaseDb, 'registrations');
      const registrationsSnapshot = await getDocs(registrationsRef);
      
      tokenUsageData = [];
      registrationsSnapshot.forEach(doc => {
        const reg = doc.data();
        if (reg.paidWithTokens) {
          const originalDate = reg.createdAt ? (reg.createdAt.seconds ? new Date(reg.createdAt.seconds * 1000) : new Date(reg.createdAt)) : new Date(0);
          tokenUsageData.push({
            id: doc.id,
            cliente: reg.email || 'Cliente não informado',
            evento: reg.eventType || reg.title || 'Evento',
            tokens: reg.tokensUsed || '1',
            data: originalDate.toLocaleString('pt-BR'),
            originalDate: originalDate
          });
        }
      });
      
      // Ordenar por data (mais recentes primeiro) - usar timestamp original
      tokenUsageData.sort((a, b) => {
        const dateA = a.originalDate || new Date(0);
        const dateB = b.originalDate || new Date(0);
        return dateB - dateA;
      });
      
      // Atualizar contador
      document.getElementById('totalTokensUsed').textContent = tokenUsageData.length;
      
      // Mostrar primeira página
      mostrarUsoTokensPagina(1);
      
    } catch (error) {
      console.error('Erro ao carregar dados de uso de tokens:', error);
    }
  }

  // Função para mostrar uso de tokens da página específica
  function mostrarUsoTokensPagina(pagina) {
    const tbody = document.getElementById('tokenUsageTbody');
    const startIndex = (pagina - 1) * tokenUsagePerPage;
    const endIndex = startIndex + tokenUsagePerPage;
    const tokenUsagePagina = tokenUsageData.slice(startIndex, endIndex);
    
    // Limpar tabela
    tbody.innerHTML = '';
    
    // Adicionar uso de tokens da página
    tokenUsagePagina.forEach(usage => {
      const row = document.createElement('tr');
      row.className = 'border-b border-gray-100 hover:bg-gray-50';
      
      row.innerHTML = `
        <td class="py-1 px-1 text-xs">${usage.cliente}</td>
        <td class="py-1 px-1 text-xs">${usage.evento}</td>
        <td class="py-1 px-1 text-xs">${usage.tokens}</td>
        <td class="py-1 px-1 text-xs">${usage.data}</td>
      `;
      
      tbody.appendChild(row);
    });
    
    // Atualizar informações de paginação
    const totalPages = Math.ceil(tokenUsageData.length / tokenUsagePerPage);
    
    // Gerar botões de paginação
    gerarBotoesPaginacao('tokenUsagePagination', pagina, totalPages, (p) => mostrarUsoTokensPagina(p));
  }

  // Função para carregar pedidos confirmados
  async function carregarPedidosConfirmados() {
    try {
      // Verificar se Firebase está inicializado
      if (!window.firebaseDb) {
        console.error('❌ Firebase não inicializado - carregarPedidosConfirmados');
        return;
      }
      
      
      // Buscar pedidos confirmados
      const ordersRef = collection(window.firebaseDb, 'orders');
      const ordersSnapshot = await getDocs(ordersRef);
      
      
      // Função auxiliar para obter nome do item/evento
      const getItemName = (order) => {
        // Se tiver eventType, mapear para nome legível
        if (order.eventType) {
          const eventMap = {
            'modo-liga': 'Modo Liga',
            'xtreino-tokens': 'XTreino Tokens',
            'xtreino': 'XTreino Tokens',
            'semanal-freitas': 'Semanal Freitas',
            'semanal': 'Semanal Freitas',
            'camp-freitas': 'Camp Freitas',
            'camp': 'Camp Freitas'
          };
          return eventMap[order.eventType.toLowerCase()] || order.eventType;
        }
        // Tentar outros campos
        return order.title || order.item || order.productName || 'Item não informado';
      };
      
      confirmedOrdersData = [];
      ordersSnapshot.forEach(doc => {
        const order = doc.data();
        // Log detalhado removido
        if (['paid','approved','confirmed'].includes(String(order.status||'').toLowerCase())) {
          const originalDate = order.createdAt ? (order.createdAt.seconds ? new Date(order.createdAt.seconds * 1000) : new Date(order.createdAt)) : new Date(0);
          confirmedOrdersData.push({
            id: doc.id,
            cliente: order.customer || order.customerName || order.buyerEmail || 'Cliente não informado',
            item: getItemName(order),
            valor: order.amount || order.total || 0,
            data: originalDate.toLocaleDateString('pt-BR'),
            originalDate: originalDate
          });
        }
      });
      
      // Ordenar por data (mais recentes primeiro)
      confirmedOrdersData.sort((a, b) => {
        const dateA = a.originalDate || new Date(0);
        const dateB = b.originalDate || new Date(0);
        return dateB - dateA;
      });
      
      // Atualizar contador
      document.getElementById('confirmedCount').textContent = `${confirmedOrdersData.length} pedidos`;
      // 
      
      // Mostrar primeira página
      mostrarPedidosConfirmadosPagina(1);
      
    } catch (error) {
      console.error('Erro ao carregar pedidos confirmados:', error);
    }
  }

  // Função para mostrar pedidos confirmados da página específica
  function mostrarPedidosConfirmadosPagina(pagina) {
    const tbody = document.getElementById('confirmedTbody');
    const startIndex = (pagina - 1) * confirmedOrdersPerPage;
    const endIndex = startIndex + confirmedOrdersPerPage;
    const pedidosPagina = confirmedOrdersData.slice(startIndex, endIndex);
    
    // Limpar tabela
    tbody.innerHTML = '';
    
    // Adicionar pedidos da página
    pedidosPagina.forEach(pedido => {
      const row = document.createElement('tr');
      row.className = 'border-b border-gray-100 hover:bg-gray-50';
      
      row.innerHTML = `
        <td class="py-1 px-1 text-xs">${pedido.cliente}</td>
        <td class="py-1 px-1 text-xs">${pedido.item}</td>
        <td class="py-1 px-1 text-xs">${pedido.valor}</td>
        <td class="py-1 px-1 text-xs">${pedido.data}</td>
      `;
      
      tbody.appendChild(row);
    });
    
    // Atualizar informações de paginação
    const totalPages = Math.ceil(confirmedOrdersData.length / confirmedOrdersPerPage);
    document.getElementById('confirmedPageInfo').textContent = `Página ${pagina} de ${totalPages}`;
    
    // Gerar botões de paginação
    gerarBotoesPaginacao('confirmedPagination', pagina, totalPages, (p) => mostrarPedidosConfirmadosPagina(p));
  }

  // Submissão manual de equipe/cadastro rápido (confirma vaga sem pagamento)
  let _isSavingTeam = false;
  async function submitAddTeam(e){
    if (_isSavingTeam) { e?.preventDefault(); return; }
    try{
      e?.preventDefault();
          const hourEl = document.getElementById('addHour');
          const teamEl = document.getElementById('addTeamName');
          const contactEl = document.getElementById('addContact');
          const personEl = document.getElementById('addPerson');
          const notesEl = document.getElementById('addNotes');
          const msgEl = document.getElementById('addTeamMsg');
          const dateEl = document.getElementById('boardDate');
          const typeEl = document.getElementById('boardEventType');
          const schedule = (hourEl?.value || '').trim();
          const teamName = (teamEl?.value || '').trim();
          const contact = (contactEl?.value || '').trim();
          const person = (personEl?.value || '').trim();
          const notes = (notesEl?.value || '').trim();
          const date = (dateEl?.value || '').trim();
          const eventType = (typeEl?.value || '').trim();
          if (!teamName || !contact){
            alert('Informe ao menos Time/Org e Contato.');
            return;
          }
          if (!date){
            alert('Selecione uma data no painel de horários.');
            return;
          }
          const submitBtn = document.querySelector('#formAddTeam button[type="submit"], #formAddTeam button:not([type="button"])');
          const originalBtnText = submitBtn ? submitBtn.textContent : null;
          _isSavingTeam = true;
          if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Salvando...'; }
          if (msgEl) msgEl.textContent = '';
          // Se horário não estiver definido, cria sem horário específico
          const payload = {
            teamName,
            contact,
            person: person || null,
            notes: notes || null,
            date,
            schedule: schedule || '—',
            eventType: eventType || null,
            status: 'confirmed'
          };
          try{
            const { collection, addDoc, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            await addDoc(collection(window.firebaseDb,'registrations'), { ...payload, createdAt: serverTimestamp() });
            if (msgEl) msgEl.textContent = 'Time adicionado com sucesso!';
            // limpar campos
            if (teamEl) teamEl.value = '';
            if (contactEl) contactEl.value = '';
            if (personEl) personEl.value = '';
            if (notesEl) notesEl.value = '';
            // Atualiza quadro e pendências
            try { await loadBoard(); } catch(_){}
            try { await loadPending(true); } catch(_){}
          }catch(err){
            alert('Falha ao salvar time.');
          } finally {
            _isSavingTeam = false;
            if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = originalBtnText || 'Adicionar'; }
          }
    }catch(_){ _isSavingTeam = false; }
  }
  // Expor submitAddTeam globalmente
  window.submitAddTeam = submitAddTeam;
  
  onAuthStateChanged(window.firebaseAuth, async (user) => {
    if (!user){
      authGate.classList.remove('hidden');
      dashboard.classList.add('hidden');
      return;
    }
    // fetch role
    const uid = user.uid;
    let role = 'Vendedor';
    try{
      const { getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const { doc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const ref = doc(collection(window.firebaseDb,'users'), uid);
      const snap = await getDoc(ref);
      if (snap.exists()) role = (snap.data().role)||'Vendedor';
    }catch(e){}

    // 
    if (!['admin','ceo','gerente','vendedor','design','designer','desgin','socio','sócio','afiliado','staff'].includes((role||'').toLowerCase())){
      authGate.classList.remove('hidden');
      dashboard.classList.add('hidden');
      return;
    }
    authGate.classList.add('hidden');
    dashboard.classList.remove('hidden');
    const roleLower = (role||'').toLowerCase().trim();
    
    const isManager = ['ceo','gerente'].includes(roleLower);
    const isCeo = roleLower==='ceo';
    const isSocio = roleLower==='socio' || roleLower==='ceo';
    const isAffiliate = roleLower==='afiliado';
    const isStaff = roleLower==='staff';
    const canViewAll = ['ceo','gerente','socio'].includes(roleLower);
    window.adminRoleLower = roleLower;
    // Garantir que a sessão conheça o papel atual (corrige bloqueio de CEO)
    try {
      const sess = JSON.parse(sessionStorage.getItem('adminSession')||'{}');
      sessionStorage.setItem('adminSession', JSON.stringify({
        ...sess,
        role: roleLower,
        uid: sess.uid || user.uid,
        email: sess.email || user.email,
        timestamp: Date.now()
      }));
    } catch(_) {}
    // Atualiza badge de papel na UI
    try{
      const badge = document.getElementById('roleBadge');
      if (badge){
        badge.textContent = `Permissões: ${roleLower.toUpperCase()}`;
      }
    }catch(_){ }
    
    // Carregar usuários de permissões depois de definir o cargo
    if (window.loadPermissionsUsers) {
      window.loadPermissionsUsers();
    }
    
    // Carregar dados das novas seções
    if (window.loadTokensUsers) {
      window.loadTokensUsers();
    }
    
    if (window.loadAdminHistory) {
      window.loadAdminHistory();
    }
    
    // Carregar dados de cupons
    if (window.loadCoupons) {
      window.loadCoupons();
    }
    
    if (window.loadCouponUsage) {
      window.loadCouponUsage();
    }
    
    if (window.loadAffiliates) {
      window.loadAffiliates();
    }
    
    // Se for afiliado, carregar dados do painel de afiliado
    if (isAffiliate) {
      await loadAffiliatePanelData(user.uid);
    }
    
    // Se for staff, configurar interface restrita
    if (isStaff) {
      // Forçar evento para xtreino-tokens e desabilitar seleção
      const typeEl = document.getElementById('boardEventType');
      if (typeEl) {
        typeEl.value = 'xtreino-tokens';
        typeEl.disabled = true;
        typeEl.style.opacity = '0.6';
        typeEl.style.cursor = 'not-allowed';
      }
      
      // Ocultar botão "Destravar tudo do dia"
      const btnClearLocks = document.getElementById('btnClearLocks');
      if (btnClearLocks) {
        btnClearLocks.style.display = 'none';
      }
      
      // Carregar board automaticamente com evento correto
      setTimeout(() => {
        if (window.loadBoard) {
          loadBoard();
        }
      }, 500);
    }
    
  // Carregar pedidos de camisa (envios)
  if (window.loadShirtOrders) {
    window.loadShirtOrders();
  }
    // Controla visibilidade conforme o papel - REMOVIDO para evitar conflito com controlSectionVisibility
    // A visibilidade agora é controlada exclusivamente pela função controlSectionVisibility

    try {
      // Carregamento de dados conforme papel
      if (canViewAll) {
        // CEO/Gerente/Sócio: pode carregar datasets completos
        await carregarUsuarios();
        await carregarDadosTokens();
        await carregarDadosUsoTokens();
        await carregarPedidosConfirmados();
      }
    } catch(e){
      console.error('❌ Erro ao carregar dados:', e);
    }
    // bind filtros e export
    const btnApply = document.getElementById('btnApplyFilter');
    if (btnApply) btnApply.onclick = applyFilter;
    const btnOrd = document.getElementById('btnExportOrdersCsv');
    if (btnOrd) btnOrd.onclick = exportOrdersCsv;
    const btnSch = document.getElementById('btnExportSchedulesCsv');
    if (btnSch) btnSch.onclick = exportSchedulesCsv;
    const btnLoadBoard = document.getElementById('btnLoadBoard');
    if (btnLoadBoard) btnLoadBoard.onclick = loadBoard;
    const formAddTeam = document.getElementById('formAddTeam');
    if (formAddTeam) formAddTeam.onsubmit = submitAddTeam;
    // Bind filtros do histórico de cupons - configurar após DOM estar pronto
    setupCouponUsageFilters();
    // Carrega relatórios e pendências para todas as funções
    await loadReports().catch(()=>{});
    if (canViewAll){
      await loadRecentSchedules().catch(()=>{});
      await loadPending(true).catch(()=>{});
    } else {
      await loadRecentOrders().catch(()=>{});
      await loadPending(false).catch(()=>{});
    }
    
    // APLICAR CONTROLE DE VISIBILIDADE APÓS CARREGAMENTO DE TODOS OS DADOS
    // Usar um delay maior e garantir que seja a última chamada
    setTimeout(() => {
      const finalRole = (roleLower || '').toLowerCase().trim();
      
      // Resetar flag para permitir reaplicação se necessário
      window.visibilityApplied = false;
      controlSectionVisibility(finalRole);
      try { renderTokensSectionPager(); } catch(_) {}
      // Garantir que a visibilidade não seja alterada depois
      window.lastAppliedRole = finalRole;
    }, 1500); // Delay maior para garantir que tudo foi carregado
  });

  // ---- Relatórios ----
  let charts = {};
  let period = { from: null, to: null };
  // Bind filtros de período
  try {
    const btn = document.getElementById('btnApplyFilter');
    if (btn) btn.addEventListener('click', applyFilter);
    const sel = document.getElementById('reportPeriod');
    const fromEl = document.getElementById('dateFrom');
    const toEl = document.getElementById('dateTo');
    if (sel) sel.addEventListener('change', ()=>{
      const isCustom = sel.value === 'custom';
      if (fromEl) { fromEl.disabled = !isCustom; if (!isCustom) fromEl.value = ''; }
      if (toEl) { toEl.disabled = !isCustom; if (!isCustom) toEl.value = ''; }
    });
  } catch(_){}

  // Unifica pedidos: usa APENAS registrations (mais importante - eventos são o core do negócio)
  // Isso evita duplicação entre orders e registrations que marcam a mesma coisa
  async function fetchUnifiedOrders() {
    const items = [];
    try {
      const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      
      // Usar APENAS registrations (eventos são o core do negócio e mais importante)
      // Orders e registrations estavam marcando a mesma coisa, causando duplicação
      try{
        const regs = await getDocs(collection(window.firebaseDb,'registrations'));
        regs.forEach(d => {
          const r = d.data();
          const ts = (r.createdAt?.toDate ? r.createdAt.toDate() : (r.timestamp? new Date(r.timestamp) : new Date()));
          items.push({ 
            ts, 
            amount: Number(r.price||0), 
            item:(r.title||r.eventType||'Reserva'), 
            customer:(r.email||'-'), 
            status:(r.status||''), 
            paymentMethod: (r.paidWithTokens ? 'tokens' : 'mercado_pago'),
            source: 'registrations',
            docId: d.id,
            externalRef: r.external_reference || r.externalRef || null,
            schedule: r.schedule || null,
            teamName: r.teamName || null
          });
        });
      }catch(_){}
      
      // Orders removido - estava duplicando com registrations
      // Registrations é a fonte única de verdade para eventos (core do negócio)
    } catch(_){}
    return items;
  }

  async function loadReports(){
    try{
      await loadKpis().catch(()=>{});
      // await loadTokensData().catch(()=>{}); // Desabilitado - usando novas funções de paginação
      await renderSalesChart().catch(()=>{});
      await renderTopProducts().catch(()=>{});
      await renderPaymentMethodsChart().catch(()=>{});
      await renderPopularHours().catch(()=>{});
      await renderActiveUsers().catch(()=>{});
    }catch(e){ console.error('Erro ao carregar relatórios', e); }
  }

  // ===== Paginação de salto entre seções (1 2 3 4 ›) no card de Tokens =====
  const TOKENS_JUMP_SECTIONS = [
    'sectionCoupons',
    'sectionCouponUsage',
    'sectionPasseBooyah',
    'sectionHighlights',
    'sectionNews',
    'sectionProducts',
    'sectionShirtOrders',
    'sectionWhatsAppLinks',
    'sectionSchedules',
    'sectionResetData'
  ];
  let tokensJumpPage = 0; // índice de página do paginador de seções
  const tokensJumpPerPage = 5;

  function scrollToSectionId(id){
    try{
      const el = document.getElementById(id);
      if (!el) return;
      // Se a seção estiver oculta por visibilidade, torná-la visível
      if (el.style && el.style.display === 'none') {
        el.style.display = 'block';
      }
      el.scrollIntoView({ behavior:'smooth', block:'start' });
    }catch(_){ }
  }

  function renderTokensSectionPager(pageIndex){
    const container = document.getElementById('tokensJumpPagination');
    if (!container) return;
    if (typeof pageIndex === 'number') tokensJumpPage = pageIndex;
    container.innerHTML = '';

    const start = tokensJumpPage * tokensJumpPerPage;
    const end = Math.min(start + tokensJumpPerPage, TOKENS_JUMP_SECTIONS.length);
    const totalPages = Math.ceil(TOKENS_JUMP_SECTIONS.length / tokensJumpPerPage) || 1;

    // Botões numéricos 1..N do grupo atual
    for (let i = start; i < end; i++) {
      const btn = document.createElement('button');
      btn.textContent = String((i - start) + 1);
      btn.className = `px-2 py-1 text-xs rounded cursor-pointer ${i===start? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`;
      btn.addEventListener('click', () => scrollToSectionId(TOKENS_JUMP_SECTIONS[i]));
      container.appendChild(btn);
    }

    // Botão próximo ›
    if (tokensJumpPage < totalPages - 1) {
      const next = document.createElement('button');
      next.textContent = '›';
      next.className = 'px-2 py-1 text-xs rounded bg-gray-200 text-gray-700 hover:bg-gray-300';
      next.addEventListener('click', () => renderTokensSectionPager(tokensJumpPage + 1));
      container.appendChild(next);
    }
  }

  // Funções para gerenciar tokens
  async function loadTokensData() {
    
    try {
      await loadTokenPurchases();
      await loadTokenUsage();
      await updateTokenStats();
    } catch (error) {
      console.error('❌ Error loading tokens data:', error);
    }
  }

  async function loadTokenPurchases() {
    
    try {
      const ordersSnap = await getDocs(collection(window.firebaseDb, 'orders'));
      const orders = [];
      
      ordersSnap.forEach(doc => {
        const data = doc.data();
        if (data.item && (data.item.includes('Token') || data.item.includes('token'))) {
          orders.push({
            id: doc.id,
            ...data
          });
        }
      });

      
      
      // Ordenar por data mais recente
      orders.sort((a, b) => {
        const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.timestamp || 0);
        const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.timestamp || 0);
        return dateB - dateA;
      });

      // Mostrar apenas os últimos 10
      const recentOrders = orders.slice(0, 10);
      
      const tbody = document.getElementById('tokensTbody');
      if (tbody) {
        tbody.innerHTML = '';
        
        recentOrders.forEach(order => {
          const date = order.createdAt?.toDate ? order.createdAt.toDate() : new Date(order.timestamp || 0);
          const formattedDate = date.toLocaleDateString('pt-BR');
          
          const row = document.createElement('tr');
          row.innerHTML = `
            <td class="px-4 py-2">${order.customer || order.customerEmail || '-'}</td>
            <td class="px-4 py-2">${order.item || '-'}</td>
            <td class="px-4 py-2">${extractTokenQuantity(order.item)}</td>
            <td class="px-4 py-2">${brl(order.amount || order.total || 0)}</td>
            <td class="px-4 py-2">${formattedDate}</td>
          `;
          tbody.appendChild(row);
        });
      }
    } catch (error) {
      console.error('❌ Error loading token purchases:', error);
    }
  }
  async function loadTokenUsage() {
    
    try {
      const regsSnap = await getDocs(collection(window.firebaseDb, 'registrations'));
      const usages = [];
      
      regsSnap.forEach(doc => {
        const data = doc.data();
        if (data.paidWithTokens === true) {
          usages.push({
            id: doc.id,
            ...data
          });
        }
      });

      
      
      // Ordenar por data mais recente
      usages.sort((a, b) => {
        const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.timestamp || 0);
        const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.timestamp || 0);
        return dateB - dateA;
      });

      // Mostrar apenas os últimos 10
      const recentUsages = usages.slice(0, 10);
      
      const tbody = document.getElementById('tokenUsageTbody');
      if (tbody) {
        tbody.innerHTML = '';
        
        // Helper para nome amigável do evento
        const getEventLabel = (et)=>{
          const m = String(et||'').toLowerCase();
          if (m.includes('xtreino')) return 'XTreino Tokens';
          if (m.includes('modo-liga') || m.includes('liga')) return 'Modo Liga';
          if (m.includes('camp')) return 'Camp Freitas';
          if (m.includes('semanal')) return 'Semanal Freitas';
          return et || 'Evento';
        };
        
        recentUsages.forEach(usage => {
          const date = usage.createdAt?.toDate ? usage.createdAt.toDate() : new Date(usage.timestamp || 0);
          const formattedDate = date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR');
          
          // Event label (prioriza título salvo)
          const title = usage.title || usage.item || getEventLabel(usage.eventType) || '-';
          // Extrair horário de schedule (ex.: "Segunda - 19h") ou de 'hour'
          const schedStr = String(usage.schedule || usage.hour || '');
          const hourMatch = schedStr.match(/(\d{1,2})\s*h/);
          const hourOnly = hourMatch ? `${hourMatch[1]}h` : (schedStr || '-');
          // Nome do time
          const teamName = usage.teamName || usage.name || usage.team || '-';
          const eventDisplay = `${title} • ${hourOnly} • ${teamName}`;
          
          const row = document.createElement('tr');
          row.innerHTML = `
            <td class="px-4 py-2">${usage.email || '-'}</td>
            <td class="px-4 py-2">${eventDisplay}</td>
            <td class="px-4 py-2">${getTokenCountForEvent(usage.eventType)}</td>
            <td class="px-4 py-2">${formattedDate}</td>
          `;
          tbody.appendChild(row);
        });
      }
    } catch (error) {
      console.error('❌ Error loading token usage:', error);
    }
  }

  async function updateTokenStats() {
    
    try {
      const TOKENS_PER_USE = 5; // cada uso/slot equivale a 5 tokens
      // Calcular tokens comprados
      const ordersSnap = await getDocs(collection(window.firebaseDb, 'orders'));
      let totalTokensPurchased = 0;
      
      ordersSnap.forEach(doc => {
        const data = doc.data();
        if (data.item && (data.item.includes('Token') || data.item.includes('token'))) {
          totalTokensPurchased += extractTokenQuantity(data.item);
        }
      });

      // Calcular tokens usados
      const regsSnap = await getDocs(collection(window.firebaseDb, 'registrations'));
      let totalTokensUsed = 0;
      
      regsSnap.forEach(doc => {
        const data = doc.data();
        if (data.paidWithTokens === true) {
          totalTokensUsed += getTokenCountForEvent(data.eventType);
        }
      });

      

      // Atualizar UI
      const purchasedEl = document.getElementById('totalTokensPurchased');
      const usedEl = document.getElementById('totalTokensUsed');
      
      // Exibir em "equivalente de usos" (tokens ÷ 5) com 1 casa decimal
      const purchasedEq = (totalTokensPurchased / TOKENS_PER_USE);
      const usedEq = (totalTokensUsed / TOKENS_PER_USE);
      
      if (purchasedEl) purchasedEl.textContent = Number.isFinite(purchasedEq) ? purchasedEq.toFixed(1) : '0.0';
      if (usedEl) usedEl.textContent = Number.isFinite(usedEq) ? usedEq.toFixed(1) : '0.0';
    } catch (error) {
      console.error('❌ Error updating token stats:', error);
    }
  }

  function extractTokenQuantity(item) {
    const match = item.match(/(\d+)\s*Token/i);
    return match ? parseInt(match[1]) : 1;
  }

  function getTokenCountForEvent(eventType) {
    // Todos os eventos usam 1 token
    return 1;
  }

  function brl(n){ try {return n.toLocaleString('pt-BR', {style:'currency',currency:'BRL'})} catch(_) {return `R$ ${Number(n||0).toFixed(2)}`;} }

  async function loadKpis(){
    const kpiTodayEl = document.getElementById('kpiToday');
    const kpiMonthEl = document.getElementById('kpiMonth');
    const kpiRecEl = document.getElementById('kpiReceivable');
    const kpiActiveEl = document.getElementById('kpiActiveUsers');
    if (!kpiTodayEl || !kpiMonthEl || !kpiRecEl) return;

    

    // Usar a mesma lógica da loadKPIs() que está funcionando corretamente
    const { collection, query, where, getDocsFromServer } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const ordersCol = collection(window.firebaseDb, 'orders');

    // Today sales (sum) - apenas pedidos pagos
    const today = new Date();
    today.setHours(0,0,0,0);
    const qToday = query(ordersCol, where('createdAt', '>=', today));
    const todaySnap = await getDocsFromServer(qToday);
    let sumToday = 0;
    todaySnap.forEach(d => {
        const data = d.data();
        const status = (data.status || '').toLowerCase();
        if (status === 'paid' || status === 'approved' || status === 'confirmed') {
            sumToday += Number(data.amount || 0);
        }
    });

    // Month sales - apenas pedidos pagos
    const firstMonth = new Date();
    firstMonth.setDate(1); firstMonth.setHours(0,0,0,0);
    const qMonth = query(ordersCol, where('createdAt', '>=', firstMonth));
    const monthSnap = await getDocsFromServer(qMonth);
    let sumMonth = 0, receivable = 0;
    monthSnap.forEach(d => {
        const data = d.data();
        const val = Number(data.amount || 0);
        const status = (data.status || '').toLowerCase();
        
        // Apenas pedidos pagos para o total do mês
        if (status === 'paid' || status === 'approved' || status === 'confirmed') {
            sumMonth += val;
        }
        
        // Pedidos pendentes para receber
        if (status === 'pending') {
            receivable += val;
        }
    });
    
    
    
    kpiTodayEl.textContent = brl(sumToday);
    kpiMonthEl.textContent = brl(sumMonth);
    kpiRecEl.textContent = brl(receivable);

    if (kpiActiveEl){
      const roleLower = (window.adminRoleLower||'').toLowerCase();
      if (roleLower==='ceo' || roleLower==='gerente' || roleLower==='socio'){
        try{
          const usersSnap = await getDocs(collection(window.firebaseDb,'users'));
          const weekAgo = Date.now() - 7*24*60*60*1000;
          let active = 0; usersSnap.forEach(d=>{ const u=d.data(); if (Number(u.lastLogin||0) >= weekAgo) active++; });
          kpiActiveEl.textContent = String(active);
        }catch(_){ kpiActiveEl.textContent = '—'; }
      } else {
        // Vendedor não tem permissão para ler users
        kpiActiveEl.textContent = '—';
      }
    }
  }

  async function renderSalesChart(){
    const canvas = document.getElementById('salesChart');
    if (!canvas) return;
    const all = await fetchUnifiedOrders();
    // Intervalo dinâmico com base no filtro
    const today = new Date(); today.setHours(0,0,0,0);
    const start = period.from ? new Date(period.from) : new Date(today.getTime() - 29*24*60*60*1000);
    const end = period.to ? new Date(period.to) : today;
    const days = [];
    const cur = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const endDay = new Date(end.getFullYear(), end.getMonth(), end.getDate());
    while (cur <= endDay){ days.push(new Date(cur)); cur.setDate(cur.getDate()+1); }
    const labels = days.map(d=>d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }));
    
    // Agrupar por external_reference primeiro (transações únicas)
    const transactionsByRef = new Map();
    
    all.forEach(o => {
      const ts = o.ts;
      if (period.from && ts < period.from) return;
      if (period.to && ts > period.to) return;
      const status = (o.status||'').toLowerCase();
      if (status === 'paid' || status === 'confirmed') {
        const externalRef = o.externalRef || o.docId || 'no-ref';
        
        if (transactionsByRef.has(externalRef)) {
          const existing = transactionsByRef.get(externalRef);
          existing.amount += Number(o.amount || 0);
          existing.date = ts || existing.date; // Usar a primeira data encontrada
        } else {
          transactionsByRef.set(externalRef, {
            amount: Number(o.amount || 0),
            date: ts
          });
        }
      }
    });
    
    // Mapear faturamento e quantidade por dia (a partir de transações únicas)
    const revenueMap = Object.fromEntries(labels.map(l=>[l,0]));
    const quantityMap = Object.fromEntries(labels.map(l=>[l,0]));
    
    transactionsByRef.forEach(transaction => {
      const ts = transaction.date;
      if (!ts) return;
      const label = ts.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      if (revenueMap[label] !== undefined) {
        revenueMap[label] += transaction.amount;
        quantityMap[label] += 1; // Conta 1 transação, não múltiplos documentos
      }
    });
    
    const revenueData = labels.map(l=>revenueMap[l]);
    const quantityData = labels.map(l=>quantityMap[l]);
    
    try { if (charts.sales) { charts.sales.destroy(); } } catch(_){}
    
    charts.sales = new Chart(canvas.getContext('2d'), {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Faturamento (R$)',
            data: revenueData,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            tension: 0.4,
            fill: true,
            yAxisID: 'y'
          },
          {
            label: 'Quantidade de Vendas',
            data: quantityData,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            tension: 0.4,
            fill: true,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false
        },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: { size: 12, weight: 'bold' },
              padding: 15,
              usePointStyle: true
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                if (context.datasetIndex === 0) {
                  return `Faturamento: R$ ${context.parsed.y.toFixed(2).replace('.', ',')}`;
                } else {
                  return `Quantidade: ${context.parsed.y} venda${context.parsed.y !== 1 ? 's' : ''}`;
                }
              }
            }
          }
        },
        scales: {
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                return 'R$ ' + value.toFixed(0);
              }
            },
            title: {
              display: true,
              text: 'Faturamento (R$)',
              font: { size: 12, weight: 'bold' }
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            beginAtZero: true,
            grid: {
              drawOnChartArea: false
            },
            ticks: {
              stepSize: 1
            },
            title: {
              display: true,
              text: 'Quantidade',
              font: { size: 12, weight: 'bold' }
            }
          }
        }
      }
    });
    
    // Atualiza título com o intervalo
    try {
      const title = document.getElementById('salesChartTitle');
      if (title){ const fmt = d => d.toLocaleDateString('pt-BR'); title.textContent = `Vendas — ${fmt(start)} a ${fmt(end)}`; }
    } catch(_){ }
  }

  // Função para normalizar nomes de produtos
  function normalizeProductName(name) {
    if (!name || name === 'undefined' || name === 'Item' || name === 'Pedido') {
      return 'Produto Diverso';
    }
    
    const normalized = String(name).trim();
    
    // Normalizar tokens
    if (normalized.toLowerCase().includes('token')) {
      const match = normalized.match(/(\d+)\s*token/i);
      if (match) {
        return `${match[1]} Token${match[1] > 1 ? 's' : ''} XTreino`;
      }
      if (normalized.toLowerCase().includes('undefined')) {
        return 'Token XTreino';
      }
      return normalized.replace(/undefined/gi, '').trim() || 'Token XTreino';
    }
    
    // Normalizar eventos/treinos
    if (normalized.toLowerCase().includes('modo liga') || normalized.toLowerCase().includes('modo-liga')) {
      return 'XTreino Modo Liga';
    }
    if (normalized.toLowerCase().includes('semanal')) {
      return 'Semanal Freitas';
    }
    if (normalized.toLowerCase().includes('camp') || normalized.toLowerCase().includes('campeonato')) {
      return 'Camp Freitas';
    }
    if (normalized.toLowerCase().includes('reserva') || normalized.toLowerCase().includes('treino')) {
      return 'Reserva de Evento';
    }
    
    // Normalizar sensibilidades
    if (normalized.toLowerCase().includes('sensibilidade') || normalized.toLowerCase().includes('sensibilidade')) {
      return 'Sensibilidade Free Fire';
    }
    
    // Limpar "undefined" de qualquer nome
    return normalized.replace(/undefined/gi, '').trim() || 'Produto Diverso';
  }

  async function renderTopProducts(){
    const canvas = document.getElementById('topProductsChart');
    if (!canvas) return;
    const all = await fetchUnifiedOrders();
    
    // Agrupar por external_reference primeiro (transações únicas)
    const transactionsByRef = new Map();
    
    all.forEach(o => {
      if ((o.status||'').toLowerCase() !== 'paid' && (o.status||'').toLowerCase() !== 'confirmed') return;
      
      const externalRef = o.externalRef || o.docId || 'no-ref';
      const rawName = o.item || 'Produto Diverso';
      const normalizedName = normalizeProductName(rawName);
      const amount = Number(o.amount || 0);
      
      if (transactionsByRef.has(externalRef)) {
        const existing = transactionsByRef.get(externalRef);
        existing.amount += amount;
        // Se o produto normalizado for diferente, manter o primeiro ou combinar
        if (!existing.products.includes(normalizedName)) {
          existing.products.push(normalizedName);
        }
      } else {
        transactionsByRef.set(externalRef, {
          amount: amount,
          products: [normalizedName]
        });
      }
    });
    
    // Agregar por produto a partir das transações únicas
    const revenueMap = {}; // Faturamento por produto
    const quantityMap = {}; // Quantidade de transações por produto
    
    transactionsByRef.forEach(transaction => {
      // Se uma transação tem múltiplos produtos, distribuir o valor igualmente
      const amountPerProduct = transaction.amount / transaction.products.length;
      transaction.products.forEach(productName => {
        revenueMap[productName] = (revenueMap[productName] || 0) + amountPerProduct;
        quantityMap[productName] = (quantityMap[productName] || 0) + 1;
      });
    });
    
    // Ordenar por faturamento e pegar top 5
    const entries = Object.entries(revenueMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, revenue]) => ({
        name,
        revenue,
        quantity: quantityMap[name] || 0
      }));
    
    try { if (charts.top) { charts.top.destroy(); } } catch(_){}
    
    charts.top = new Chart(canvas.getContext('2d'), {
      type: 'bar',
      data: {
        labels: entries.map(e => e.name),
        datasets: [{
          label: 'Faturamento (R$)',
          data: entries.map(e => e.revenue),
          backgroundColor: '#3b82f6',
          borderColor: '#2563eb',
          borderWidth: 2,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: { size: 12, weight: 'bold' },
              padding: 15
            }
          },
          tooltip: {
            callbacks: {
              afterLabel: function(context) {
                const index = context.dataIndex;
                const quantity = entries[index].quantity;
                return `Quantidade: ${quantity} venda${quantity !== 1 ? 's' : ''}`;
              },
              label: function(context) {
                return `Faturamento: R$ ${context.parsed.y.toFixed(2).replace('.', ',')}`;
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                return 'R$ ' + value.toFixed(0);
              }
            },
            title: {
              display: true,
              text: 'Faturamento (R$)',
              font: { size: 12, weight: 'bold' }
            }
          },
          x: {
            ticks: {
              maxRotation: 45,
              minRotation: 45,
              font: { size: 10 }
            }
          }
        }
      }
    });
  }

  // Renderizar gráfico de formas de pagamento
  async function renderPaymentMethodsChart(){
    const canvas = document.getElementById('paymentMethodsChart');
    if (!canvas) return;
    const all = await fetchUnifiedOrders();
    
    const paymentMap = {
      tokens: { count: 0, revenue: 0, label: 'Tokens' },
      mercado_pago: { count: 0, revenue: 0, label: 'QR Code / Mercado Pago' }
    };
    
    // Agrupar por external_reference para evitar contar múltiplas vezes a mesma transação
    // Uma transação pode ter múltiplos documentos (ex: múltiplos horários/times)
    const transactionsByRef = new Map();
    
    all.forEach(o => {
      const status = (o.status||'').toLowerCase();
      if (status === 'paid' || status === 'confirmed') {
        const externalRef = o.externalRef || o.docId || 'no-ref';
        
        // Se já existe uma transação com esse external_reference, agrupar
        if (transactionsByRef.has(externalRef)) {
          const existing = transactionsByRef.get(externalRef);
          // Somar o valor (pode ter múltiplos itens na mesma transação)
          existing.amount += Number(o.amount || 0);
          existing.items.push({
            item: o.item,
            amount: Number(o.amount || 0),
            source: o.source
          });
        } else {
          // Nova transação
          transactionsByRef.set(externalRef, {
            method: o.paymentMethod || 'mercado_pago',
            amount: Number(o.amount || 0),
            items: [{
              item: o.item,
              amount: Number(o.amount || 0),
              source: o.source
            }]
          });
        }
      }
    });
    
    // Contar transações únicas (não documentos individuais)
    transactionsByRef.forEach(transaction => {
      const method = transaction.method;
      const key = method === 'tokens' ? 'tokens' : 'mercado_pago';
      paymentMap[key].count += 1; // Conta 1 transação, não múltiplos documentos
      paymentMap[key].revenue += transaction.amount;
    });
    
    
    
    
    
    const labels = Object.values(paymentMap).map(p => p.label);
    const countData = Object.values(paymentMap).map(p => p.count);
    const revenueData = Object.values(paymentMap).map(p => p.revenue);
    
    try { if (charts.payment) { charts.payment.destroy(); } } catch(_){}
    
    charts.payment = new Chart(canvas.getContext('2d'), {
      type: 'doughnut',
      data: {
        labels,
        datasets: [
          {
            label: 'Quantidade de Vendas',
            data: countData,
            backgroundColor: ['#10b981', '#3b82f6'],
            borderColor: ['#059669', '#2563eb'],
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            labels: {
              font: { size: 12, weight: 'bold' },
              padding: 15,
              usePointStyle: true
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                const index = context.dataIndex;
                const revenue = revenueData[index];
                const count = countData[index];
                return [
                  `${context.label}: ${count} venda${count !== 1 ? 's' : ''}`,
                  `Faturamento: R$ ${revenue.toFixed(2).replace('.', ',')}`
                ];
              }
            }
          }
        }
      }
    });
  }

  // Atualiza todos os componentes do dashboard
  async function refreshDashboard(){
    try { await loadKpis(); } catch(_){ }
    try { await renderSalesChart(); } catch(_){ }
    try { await renderTopProducts(); } catch(_){ }
    try { await renderPaymentMethodsChart(); } catch(_){ }
    try { await loadTokensData(); } catch(_){ }
  }

  async function loadRecentOrders(){
    const tbody = document.getElementById('ordersTbody');
    const count = document.getElementById('ordersCount');
    if (!tbody) return;
    tbody.innerHTML = '';
    const items = [];
    
    // Orders - apenas pedidos com dados completos
    try {
    const snap = await getDocs(collection(window.firebaseDb,'orders'));
      snap.forEach(d=>{ 
        const o = d.data(); 
        const ts = new Date(o.createdAt||o.timestamp||0); 
        if (period.from && ts < period.from) return; 
        if (period.to && ts > period.to) return; 
        
        // Só adiciona se tiver dados essenciais
        const client = o.customer || o.buyerEmail || '';
        const item = o.item || o.productName || '';
        const value = Number(o.amount || o.total || 0);
        const status = o.status || '—';
        
        if (client && item && value > 0) {
          items.push({ 
            ts, 
            client, 
            item, 
            value, 
            status,
            id: d.id 
          }); 
        }
      });
    } catch(e) { console.error('Erro ao carregar orders:', e); }
    
    // Registrations pagas - apenas com dados completos
    try{
      const regsSnap = await getDocs(collection(window.firebaseDb,'registrations'));
      regsSnap.forEach(d=>{ 
        const r = d.data(); 
        const status = (r.status || '').toLowerCase(); 
        if (status !== 'paid') return; 
        
        const ts = (r.createdAt?.toDate ? r.createdAt.toDate() : (r.timestamp ? new Date(r.timestamp) : new Date())); 
        if (period.from && ts < period.from) return; 
        if (period.to && ts > period.to) return; 
        
        // Só adiciona se tiver dados essenciais
        const client = r.email || '';
        const item = r.title || r.eventType || '';
        const value = Number(r.price || 0);
        
        if (client && item && value > 0) {
          items.push({ 
            ts, 
            client, 
            item, 
            value, 
            status: 'paid',
            id: d.id 
          }); 
        }
      });
    } catch(e) { console.error('Erro ao carregar registrations:', e); }
    
    // ordenar por data desc e renderizar
    items.sort((a,b)=> b.ts - a.ts);
    
    // Limitar a 20 pedidos mais recentes
    const recentItems = items.slice(0, 20);
    
    recentItems.forEach((row, index) => { 
      const tr = document.createElement('tr'); 
      tr.innerHTML = `
        <td class="py-2 font-mono text-xs">${row.id ? row.id.substring(0, 6) : index + 1}</td>
        <td class="py-2">${row.client}</td>
        <td class="py-2">${row.item}</td>
        <td class="py-2 font-semibold">${brl(row.value)}</td>
        <td class="py-2">
          <span class="px-2 py-1 rounded-full text-xs font-semibold ${row.status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}">
            ${row.status}
          </span>
        </td>
      `; 
      tbody.appendChild(tr); 
    });
    
    if (count) count.textContent = `${recentItems.length} pedidos`;
  }
  // Nova função para carregar dados de tokens
  async function loadTokensData(){
    try {
      
      
      // Debug: mostrar todos os orders
      const ordersSnap = await getDocs(collection(window.firebaseDb,'orders'));
      
      ordersSnap.forEach(d => {
        const o = d.data();
        console.log('Order:', {
          id: d.id,
          description: o.description,
          item: o.item,
          status: o.status,
          customer: o.customer || o.buyerEmail
        });
      });
      
      // Debug: mostrar todas as registrations
      const regsSnap = await getDocs(collection(window.firebaseDb,'registrations'));
      
      regsSnap.forEach(d => {
        const r = d.data();
        console.log('Registration:', {
          id: d.id,
          email: r.email,
          eventType: r.eventType,
          paidWithTokens: r.paidWithTokens,
          status: r.status
        });
      });
      
      // Carregar compras de tokens
      await loadTokenPurchases();
      // Carregar uso de tokens
      await loadTokenUsage();
      // Atualizar estatísticas gerais
      await updateTokenStats();
    } catch(e) { 
      console.error('Erro ao carregar dados de tokens:', e); 
    }
  }

  // Carregar compras de tokens
  async function loadTokenPurchases(){
    const tbody = document.getElementById('tokensTbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    try {
      const snap = await getDocs(collection(window.firebaseDb,'orders'));
      const tokenPurchases = [];
      
      snap.forEach(d => {
        const o = d.data();
        const description = o.description || o.item || '';
        
        // Verifica se é uma compra de tokens (mais flexível)
        if (description.toLowerCase().includes('token') || 
            description.toLowerCase().includes('xtreino') ||
            (o.item && o.item.toLowerCase().includes('token'))) {
          const ts = new Date(o.createdAt || o.timestamp || 0);
          if (period.from && ts < period.from) return;
          if (period.to && ts > period.to) return;
          
          // Extrai quantidade de tokens da descrição (mais flexível)
          const tokenMatch = description.match(/(\d+)\s*token/i) || 
                           description.match(/token[:\s]*(\d+)/i) ||
                           description.match(/(\d+)\s*xtreino/i);
          const tokenCount = tokenMatch ? parseInt(tokenMatch[1]) : 1;
          
          console.log('Token purchase found:', {
            description,
            tokenCount,
            client: o.customer || o.buyerEmail,
            status: o.status
          });
          
          tokenPurchases.push({
            ts,
            client: o.customer || o.buyerEmail || '',
            package: description,
            tokens: tokenCount,
            value: Number(o.amount || o.total || 0),
            id: d.id
          });
        }
      });
      
      // Ordenar por data desc e mostrar últimos 10
      tokenPurchases.sort((a,b) => b.ts - a.ts);
      const recentPurchases = tokenPurchases.slice(0, 10);
      
      recentPurchases.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="py-2">${row.client}</td>
          <td class="py-2">${row.package}</td>
          <td class="py-2 font-semibold text-green-600">${row.tokens}</td>
          <td class="py-2 font-semibold">${brl(row.value)}</td>
          <td class="py-2 text-gray-500">${row.ts.toLocaleDateString('pt-BR')}</td>
        `;
        tbody.appendChild(tr);
      });
      
    } catch(e) { 
      console.error('Erro ao carregar compras de tokens:', e); 
    }
  }

  // Carregar uso de tokens
  async function loadTokenUsage(){
    const tbody = document.getElementById('tokenUsageTbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    
    try {
      const snap = await getDocs(collection(window.firebaseDb,'registrations'));
      const tokenUsage = [];
      
      snap.forEach(d => {
        const r = d.data();
        
        // Verifica se foi pago com tokens
        if (r.paidWithTokens === true) {
          console.log('Token usage found:', {
            client: r.email,
            event: r.title || r.eventType,
            paidWithTokens: r.paidWithTokens,
            status: r.status
          });
          const ts = (r.createdAt?.toDate ? r.createdAt.toDate() : (r.timestamp ? new Date(r.timestamp) : new Date()));
          if (period.from && ts < period.from) return;
          if (period.to && ts > period.to) return;
          
          // Determina quantidade de tokens baseado no tipo de evento
          let tokenCount = 1; // padrão
          const eventType = (r.eventType || '').toLowerCase();
          if (eventType.includes('modo liga')) tokenCount = 3;
          else if (eventType.includes('semanal')) tokenCount = 3.5;
          else if (eventType.includes('final semanal')) tokenCount = 7;
          else if (eventType.includes('camp')) tokenCount = 5;
          
          tokenUsage.push({
            ts,
            client: r.email || '',
            event: r.title || r.eventType || 'Evento',
            tokens: tokenCount,
            schedule: r.schedule || '',
            id: d.id
          });
        }
      });
      
      // Ordenar por data desc e mostrar últimos 10
      tokenUsage.sort((a,b) => b.ts - a.ts);
      const recentUsage = tokenUsage.slice(0, 10);
      
      recentUsage.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td class="py-2">${row.client}</td>
          <td class="py-2">${row.event}</td>
          <td class="py-2 font-semibold text-blue-600">${row.tokens}</td>
          <td class="py-2 text-gray-500">${row.ts.toLocaleDateString('pt-BR')} ${row.schedule}</td>
        `;
        tbody.appendChild(tr);
      });
      
    } catch(e) { 
      console.error('Erro ao carregar uso de tokens:', e); 
    }
  }

  // Atualizar estatísticas gerais de tokens
  async function updateTokenStats(){
    try {
      let totalPurchased = 0;
      let totalUsed = 0;
      
      // Contar tokens comprados
      const ordersSnap = await getDocs(collection(window.firebaseDb,'orders'));
      ordersSnap.forEach(d => {
        const o = d.data();
        const description = o.description || o.item || '';
        
        if ((description.toLowerCase().includes('token') || 
             description.toLowerCase().includes('xtreino') ||
             (o.item && o.item.toLowerCase().includes('token'))) && 
            o.status === 'paid') {
          const tokenMatch = description.match(/(\d+)\s*token/i);
          const tokenCount = tokenMatch ? parseInt(tokenMatch[1]) : 1;
          totalPurchased += tokenCount;
        }
      });
      
      // Contar tokens usados
      const regsSnap = await getDocs(collection(window.firebaseDb,'registrations'));
      regsSnap.forEach(d => {
        const r = d.data();
        
        if (r.paidWithTokens === true) {
          const eventType = (r.eventType || '').toLowerCase();
          let tokenCount = 1;
          if (eventType.includes('modo liga')) tokenCount = 3;
          else if (eventType.includes('semanal')) tokenCount = 3.5;
          else if (eventType.includes('final semanal')) tokenCount = 7;
          else if (eventType.includes('camp')) tokenCount = 5;
          
          totalUsed += tokenCount;
        }
      });
      
      // Atualizar elementos
      const purchasedEl = document.getElementById('totalTokensPurchased');
      const usedEl = document.getElementById('totalTokensUsed');
      
      if (purchasedEl) purchasedEl.textContent = totalPurchased;
      if (usedEl) usedEl.textContent = totalUsed;
      
    } catch(e) { 
      console.error('Erro ao atualizar estatísticas de tokens:', e); 
    }
  }

  // Pendências (orders.status === 'pending' OU registrations.status === 'pending')
  async function loadPending(isManager){
    const tbody = document.getElementById('pendingTbody');
    const countEl = document.getElementById('pendingCount');
    if (!tbody) return;
    tbody.innerHTML = '';
    let total = 0;
    try{
      const clauses = [ where('status','==','pending') ];
      if (!isManager && window.firebaseAuth?.currentUser?.uid){
        clauses.push(where('ownerId','==', window.firebaseAuth.currentUser.uid));
      }
      const ordSnap = await getDocs(query(collection(window.firebaseDb,'orders'), ...clauses));
      ordSnap.forEach(d=>{
        const o = d.data();
        const tr = document.createElement('tr');
        const created = new Date(o.createdAt||o.timestamp||Date.now()).toLocaleString('pt-BR');
        tr.innerHTML = `
          <td class="py-2">${o.customer||o.buyerEmail||'-'}</td>
          <td class="py-2">${o.item||o.productName||'-'}</td>
          <td class="py-2">${brl(Number(o.amount||o.total||0))}</td>
          <td class="py-2">${created}</td>
          <td class="py-2 space-x-2">
            <button class="px-2 py-1 bg-green-600 text-white rounded text-xs" data-approve="${d.id}">Aprovar</button>
            <button class="px-2 py-1 bg-red-600 text-white rounded text-xs" data-remove="${d.id}">Remover</button>
          </td>`;
        tbody.appendChild(tr); total++;
      });
    }catch(_){}
    try{
      const regClauses = [ where('status','==','pending') ];
      if (!isManager && window.firebaseAuth?.currentUser?.uid){
        regClauses.push(where('userId','==', window.firebaseAuth.currentUser.uid));
      }
      const regSnap = await getDocs(query(collection(window.firebaseDb,'registrations'), ...regClauses));
      regSnap.forEach(d=>{
        const r = d.data();
        const tr = document.createElement('tr');
        const created = new Date(r.createdAt?.toDate ? r.createdAt.toDate() : (r.timestamp||Date.now())).toLocaleString('pt-BR');
        tr.innerHTML = `
          <td class="py-2">${r.email||'-'}</td>
          <td class="py-2">${r.title||r.eventType||'-'}</td>
          <td class="py-2">${brl(Number(r.price||0))}</td>
          <td class="py-2">${created}</td>
          <td class="py-2 space-x-2">
            <button class="px-2 py-1 bg-green-600 text-white rounded text-xs" data-approve-reg="${d.id}">Aprovar</button>
            <button class="px-2 py-1 bg-red-600 text-white rounded text-xs" data-remove-reg="${d.id}">Remover</button>
          </td>`;
        tbody.appendChild(tr); total++;
      });
    }catch(_){ }
    if (countEl) countEl.textContent = `${total} pendentes`;
    tbody.addEventListener('click', async (e)=>{
      const approve = e.target.closest('[data-approve]');
      const approveReg = e.target.closest('[data-approve-reg]');
      const remove = e.target.closest('[data-remove]');
      const removeReg = e.target.closest('[data-remove-reg]');
      try{
        if (approve){
          const id = approve.getAttribute('data-approve');
          const { doc, setDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
          await setDoc(doc(collection(window.firebaseDb,'orders'), id), { status:'paid', updatedAt: Date.now() }, { merge:true });
          approve.closest('tr')?.remove();
          // atualizar métricas e recentes
          await refreshDashboard();
        } else if (approveReg){
          const id = approveReg.getAttribute('data-approve-reg');
          const { doc, setDoc, collection, getDoc, addDoc, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
          // marca registro como pago
          await setDoc(doc(collection(window.firebaseDb,'registrations'), id), { status:'paid', paidAt: Date.now() }, { merge:true });
          // cria um pedido em 'orders' para alimentar métricas e lista
          try{
            const snap = await getDoc(doc(collection(window.firebaseDb,'registrations'), id));
            if (snap.exists()){
              const r = snap.data();
              await addDoc(collection(window.firebaseDb,'orders'), {
                itemName: r.title || r.eventType || 'Reserva',
                amount: Number(r.price||0),
                customerName: r.email || '-',
                ownerId: r.userId || null,
                status: 'paid',
                createdAt: serverTimestamp()
              });
            }
          }catch(_){ }
          approveReg.closest('tr')?.remove();
          await refreshDashboard();
        } else if (remove){
          const id = remove.getAttribute('data-remove');
          const { doc, deleteDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
          await deleteDoc(doc(collection(window.firebaseDb,'orders'), id));
          remove.closest('tr')?.remove();
          await refreshDashboard();
        } else if (removeReg){
          const id = removeReg.getAttribute('data-remove-reg');
          const { doc, deleteDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
          await deleteDoc(doc(collection(window.firebaseDb,'registrations'), id));
          removeReg.closest('tr')?.remove();
          await refreshDashboard();
        }
      }catch(_){ alert('Ação falhou'); }
    });
  }

  async function loadRecentSchedules(){
    const tbody = document.getElementById('schedulesTbody');
    const count = document.getElementById('schedulesCount');
    if (!tbody) return;
    tbody.innerHTML = '';
    const snap = await getDocs(collection(window.firebaseDb,'schedules'));
    let i=1; let total=0; snap.forEach(d=>{ const s=d.data(); const ts=new Date(s.createdAt||s.timestamp||s.date||0); if (period.from&&ts<period.from) return; if (period.to&&ts>period.to) return; total++; const tr=document.createElement('tr'); tr.innerHTML=`<td class="py-2">${i++}</td><td class="py-2">${s.eventType||''}</td><td class="py-2">${s.date||''}</td><td class="py-2">${s.hour||''}</td><td class="py-2">${s.name||s.email||''}</td>`; tbody.appendChild(tr); });
    if (count) count.textContent = `${total} inscrições`;
  }
  function parsePeriod(){
    const sel = document.getElementById('reportPeriod');
    const fromEl = document.getElementById('dateFrom');
    const toEl = document.getElementById('dateTo');
    const v = sel?.value || 'today';
    const now = new Date();
    if (v==='today'){ period.from = new Date(now.getFullYear(), now.getMonth(), now.getDate()); period.to = null; }
    else if (v==='7d'){ const d=new Date(); d.setDate(d.getDate()-7); period.from = d; period.to = null; }
    else if (v==='30d'){ const d=new Date(); d.setDate(d.getDate()-30); period.from = d; period.to = null; }
    else { period.from = fromEl?.value? new Date(fromEl.value) : null; period.to = toEl?.value? new Date(toEl.value) : null; }
  }
  async function applyFilter(){ parsePeriod(); await loadReports(); }

  async function exportOrdersCsv(){
    const all = await fetchUnifiedOrders();
    const rows = [['data','cliente','item','valor','status']];
    all.forEach(o=>{ const ts=o.ts; if (period.from&&ts<period.from) return; if (period.to&&ts>period.to) return; rows.push([ts.toISOString(), o.customer||'', o.item||'', String(o.amount||0), o.status||'']); });
    downloadCsv('vendas.csv', rows);
  }

  async function exportSchedulesCsv(){
    const regs = await getDocs(collection(window.firebaseDb,'registrations'));
    const rows = [['id','data','evento','dia','hora','cliente']];
    regs.forEach(d=>{ const r=d.data(); const ts=(r.createdAt?.toDate ? r.createdAt.toDate() : (r.timestamp? new Date(r.timestamp) : new Date())); if (period.from&&ts<period.from) return; if (period.to&&ts>period.to) return; const schedule=String(r.schedule||''); const m=schedule.match(/(\d{1,2})h/); const hora=m?`${m[1]}h`:schedule; rows.push([d.id, ts.toISOString(), r.eventType||r.title||'Reserva', r.date||'', hora, r.email||'']); });
    downloadCsv('inscricoes.csv', rows);
  }

  // Bind botão reconciliar
  (function(){
    const btn = document.getElementById('btnReconcile');
    if (btn && !btn._bound){
      btn.addEventListener('click', ()=> reconcilePayments());
      btn._bound = true;
    }
  })();

  // Reconciliar pagamentos (24h) pelo external_reference
  async function reconcilePayments(){
    try{
      const { collection, getDocs, query, where, doc, updateDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const since = Date.now() - 24*60*60*1000;
      let checked = 0, approved = 0, ordersChecked = 0, ordersApproved = 0, tokensCredited = 0;
      // 1) Registrations pendentes
      const regsRef = collection(window.firebaseDb,'registrations');
      const regSnap = await getDocs(query(regsRef, where('status','==','pending')));
      for (const d of regSnap.docs){
        const r = d.data();
        const ts = r.createdAt?.toDate?.()?.getTime?.() || r.timestamp || 0;
        if ((r.external_reference || r.external_reference) && ts >= since){
          checked++;
          const res = await fetch('/.netlify/functions/check-payment-status', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ external_reference: r.external_reference }) });
          if (res.ok){
            const data = await res.json();
            const st = String(data?.status||'').toLowerCase();
            if (['approved','paid','accredited'].includes(st)){
              await updateDoc(doc(window.firebaseDb,'registrations', d.id), { status:'paid', paidAt: Date.now() });
              approved++;
            }
          }
        }
      }
      // 2) Orders pendentes (tokens/produtos)
      const ordersRef = collection(window.firebaseDb,'orders');
      const ordSnap = await getDocs(query(ordersRef, where('status','in',['pending','approved','']) ));
      for (const d of ordSnap.docs){
        const o = d.data();
        const ts = o.createdAt?.toDate?.()?.getTime?.() || o.timestamp || 0;
        if ((o.external_reference || o.preference_id) && ts >= since){
          ordersChecked++;
          const payload = o.external_reference ? { external_reference: o.external_reference } : { preference_id: o.preference_id };
          const res = await fetch('/.netlify/functions/check-payment-status', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(payload) });
          if (res.ok){
            const data = await res.json();
            const st = String(data?.status||'').toLowerCase();
            if (['approved','paid','accredited'].includes(st)){
              await updateDoc(doc(window.firebaseDb,'orders', d.id), { status:'paid', paidAt: Date.now(), paymentStatus: 'approved' });
              ordersApproved++;
              // Se for compra de tokens, creditar saldo
              const isTokens = /token/i.test(String(o.title||'')) || /token/i.test(String(o.item||'')) || /token/i.test(String(o.description||''));
              if (isTokens){
                try{
                  const email = o.customer || o.buyerEmail;
                  if (email){
                    const { getDocs: g2, query: q2, where: w2 } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
                    const usersRef = collection(window.firebaseDb,'users');
                    const userSnap = await g2(q2(usersRef, w2('email','==', email)));
                    if (!userSnap.empty){
                      const u = userSnap.docs[0];
                      const current = Number(u.data().tokens||0);
                      const qty = parseInt(String(o.title||'').match(/(\\d+)/)?.[1] || '1', 10);
                      await updateDoc(doc(window.firebaseDb,'users', u.id), { tokens: current + qty });
                      tokensCredited += qty;
                    }
                  }
                }catch(_){}
              }
            }
          }
        }
      }
      alert(`Reconciliados:\nInscrições → verificados ${checked}, confirmados ${approved}\nPedidos → verificados ${ordersChecked}, confirmados ${ordersApproved}\nTokens creditados: ${tokensCredited}`);
    }catch(e){
      console.error('Reconcile error', e);
      alert('Falha ao reconciliar pagamentos.');
    }
  }

  function downloadCsv(filename, rows){
    const csv = rows.map(r=>r.map(v => '"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], { type:'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  async function renderPopularHours(){
    const canvas = document.getElementById('popularHoursChart');
    if (!canvas) return;
    const regs = await getDocs(collection(window.firebaseDb,'registrations'));
    const hours = ['14','15','16','17','18','19','20','21','22','23'];
    const map = Object.fromEntries(hours.map(h=>[h,0]));
    regs.forEach(d=>{ const r=d.data(); if ((r.status||'').toLowerCase()!=='paid') return; const schedule=String(r.schedule||''); const m=schedule.match(/(\d{1,2})h/); const h=(m?m[1]:schedule).toString().padStart(2,'0'); if (map[h]!==undefined) map[h]++; });
    const data = hours.map(h=>map[h]);
    try { if (charts.hours) { charts.hours.destroy(); } } catch(_){ }
    charts.hours = new Chart(canvas.getContext('2d'), { type:'bar', data:{ labels: hours.map(h=>`${h}h`), datasets:[{label:'Agendamentos', data, backgroundColor:'#34d399'}] }, options:{plugins:{legend:{display:false}}} });
  }

  // ===== HELPER FUNCTIONS PARA loadBoard =====
  
  // Mapa de tipos de eventos e suas variações
  function getEventTypeConfig() {
    return {
      canonical: {
        'modo-liga': (s) => s === 'liga' || s.includes('modo liga'),
        'camp-final': (s) => s === 'camp-final' || s.includes('camp final') || s.includes('vaga direto'),
        'camp-freitas': (s) => s === 'camp' || s.includes('camp freitas'),
        'semanal-freitas': (s) => s === 'semanal' || s.includes('semanal freitas'),
        'xtreino-tokens': (s) => s.includes('xtreino')
      },
      aliases: {
        'modo-liga': ['modo-liga','liga','modo liga'],
        'camp-freitas': ['camp-freitas','camp','camp freitas'],
        'camp-final': ['camp-final','camp final','final','vaga direto','vaga final'],
        'semanal-freitas': ['semanal-freitas','semanal','semanal freitas'],
        'xtreino-tokens': ['xtreino-tokens','xtreino','xtreino tokens']
      }
    };
  }

  // Normaliza tipo de evento para forma canônica
  function canonicalType(t) {
    const s = String(t||'').toLowerCase();
    const config = getEventTypeConfig();
    for (const [canonical, matcher] of Object.entries(config.canonical)) {
      if (matcher(s)) return canonical;
    }
    return t;
  }

  // Resolve aliases para um tipo de evento
  function resolveAliases(t) {
    const canon = canonicalType(t);
    const config = getEventTypeConfig();
    const base = config.aliases[canon] ? [...config.aliases[canon]] : [canon];
    base.push(null, '');
    return Array.from(new Set(base.filter(v => v !== undefined)));
  }

  // Retorna capacidade por horário
  function getCapacityForHour(eventType, hour, isCampFinalDate, isCampSemifinalDate) {
    const ev = String(eventType||'').toLowerCase();
    const hourNum = parseInt(String(hour||'').match(/(\d{1,2})/)?.[1] || 0, 10);
    
    if (ev === 'liga' || ev.includes('modo-liga') || ev.includes('modo liga')) return 15;
    if (ev.includes('camp-final') || canonicalType(eventType) === 'camp-final') {
      if (isCampFinalDate && hourNum === 18) return 2;
      return 2;
    }
    if (ev.includes('semanal') && hourNum === 22) return 4;
    if (ev.includes('camp') && isCampSemifinalDate && hourNum === 17) return 3;
    return 12;
  }

  // Retorna horários padrão para tipo de evento
  function getDefaultHoursForEvent(eventType, isCampFinalDate) {
    return ['14:00','15:00','16:00','17:00','18:00','19:00','20:00','21:00','22:00','23:00'];
  }

  // Busca registrations pelo dia
  async function fetchRegistrationsByDate(date, eventType) {
    try {
      const { collection, query, where, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const regs = collection(window.firebaseDb, 'registrations');
      const q = query(regs, where('date', '==', date), where('status', 'in', ['paid','confirmed','approved']));
      const snap = await getDocs(q);
      const map = {};
      
      snap.forEach(d => {
        const r = d.data();
        if (eventType && r.eventType && !String(r.eventType).toLowerCase().includes(String(eventType).toLowerCase())) return;
        
        const raw = String(r.schedule || r.hour || '').toLowerCase();
        const m = raw.match(/(\d{1,2})/);
        if (!m) return;
        
        const hh = String(parseInt(m[1], 10)).padStart(2, '0');
        const key = `${hh}:00`;
        map[key] = (map[key] || 0) + 1;
      });
      
      return map;
    } catch (e) {
      console.error('Erro ao buscar registrations:', e);
      return {};
    }
  }

  // Busca e normaliza horário em string
  function extractHour(hourStr) {
    const match = String(hourStr || '').match(/(\d{1,2})/);
    if (!match) return null;
    return String(parseInt(match[1], 10)).padStart(2, '0');
  }

  // Busca overrides (travas e ocupações extras)
  async function fetchScheduleOverrides(date, eventType) {
    const overrides = {};
    try {
      const { collection: c, query: q, where: w, getDocs: g } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const ovRef = c(window.firebaseDb, 'schedule_overrides');
      const variants = resolveAliases(eventType);
      
      // Buscar por variações de eventType
      for (const v of variants) {
        if (v === undefined) continue;
        try {
          const ovSnap = await g(q(ovRef, w('date', '==', date), w('eventType', '==', v)));
          ovSnap.forEach(d => {
            const raw = d.data();
            const hh = extractHour(raw.hour || raw.hh);
            if (!hh) return;
            const k = `${hh}:00`;
            const agg = overrides[k] || { lockedAny: false, extraOccupied: 0 };
            agg.lockedAny = agg.lockedAny || (raw.locked === true);
            if (raw.extraOccupied) agg.extraOccupied += Number(raw.extraOccupied || 0);
            overrides[k] = agg;
          });
        } catch (e) {
          console.warn(`Erro ao buscar overrides para variante '${v}':`, e);
        }
      }
      
      // Fallback: documentos sem eventType definido
      try {
        const allSnap = await g(q(ovRef, w('date', '==', date)));
        allSnap.forEach(d => {
          const raw = d.data() || {};
          const hh = extractHour(raw.hour || raw.hh);
          if (!hh) return;
          const docFamily = canonicalType(raw.eventType || raw.event_type || '');
          if (docFamily && docFamily !== canonicalType(eventType)) return;
          if (!docFamily && !variants.includes(null) && !variants.includes('')) return;
          const k = `${hh}:00`;
          const agg = overrides[k] || { lockedAny: false, extraOccupied: 0 };
          agg.lockedAny = agg.lockedAny || (raw.locked === true);
          if (raw.extraOccupied) agg.extraOccupied += Number(raw.extraOccupied || 0);
          overrides[k] = agg;
        });
      } catch (e) {
        console.warn('Erro ao buscar overrides fallback:', e);
      }
    } catch (e) {
      console.error('Erro ao buscar schedule_overrides:', e);
    }
    
    return overrides;
  }

  // Filtra horários por role (staff vê apenas 14h-18h)
  function filterEntriesByRole(entries) {
    if (window.adminRoleLower !== 'staff') return entries;
    return entries.filter(hour => {
      const hourNum = parseInt(String(hour).replace(/\D/g,'')) || 0;
      return hourNum >= 14 && hourNum <= 18;
    });
  }

  // Aplica travas fixas do Modo Liga
  function applyFixedModoLigaLocks(overrides, eventType) {
    if (canonicalType(eventType) !== 'modo-liga') return overrides;
    const fixed = { ...overrides };
    ['16:00', '17:00'].forEach(hour => {
      if (!fixed[hour]) {
        fixed[hour] = { lockedAny: true, extraOccupied: 0 };
      } else {
        fixed[hour].lockedAny = true;
      }
    });
    return fixed;
  }

  // Renderiza linha da tabela
  function createBoardTableRow(hour, capacity, occupied, overrides, eventType) {
    const tr = document.createElement('tr');
    const ovData = overrides[hour] || {};
    const isFixedLock = false; //(canonicalType(eventType) === 'modo-liga' && (hour === '16:00' || hour === '17:00'));
    const locked = isFixedLock ? true : !!(ovData.lockedAny === undefined ? ovData.locked : ovData.lockedAny);
    const isStaff = window.adminRoleLower === 'staff';
    
    const remaining = Math.max(0, capacity - occupied);
    const occupiedText = remaining === 0 ? 'Lotado' : `Restam ${remaining}`;
    const lockButton = isStaff ? '' : `<button class="px-2 py-1 ${locked?'bg-red-600 text-white':'bg-yellow-400 text-black'} rounded text-xs" data-toggle-lock="${hour}" ${isFixedLock ? 'title="Horário fixo - confirmação necessária para destravar"' : ''}>${locked?'Destravar':'Travar'}</button>`;
    
    tr.innerHTML = `<td class="py-2">${hour}</td><td class="py-2">${occupiedText}</td><td class="py-2 space-x-2">
      <button class="px-2 py-1 bg-blue-600 text-white rounded text-xs" data-add-hour="${hour}">Adicionar</button>
      <button class="px-2 py-1 bg-gray-200 text-gray-800 rounded text-xs" data-manage-hour="${hour}">Gerenciar</button>
      <button class="px-2 py-1 bg-emerald-600 text-white rounded text-xs" data-export-hour="${hour}">Exportar</button>
      ${lockButton}
    </td>`;
    
    return tr;
  }

  // Busca todos os overrides para um horário (consolidado)
  async function findAllOverridesForHour(date, eventType, hh) {
    
    const { collection: c, query: q, where: w, getDocs: g } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const ovRef = c(window.firebaseDb, 'schedule_overrides');
    const toUpdate = new Map();
    const variants = resolveAliases(eventType);
    const canon = canonicalType(eventType);
    
    
    // Query com eventType canônico e variações
    try {
      
      const snap1 = await g(q(ovRef, w('date', '==', date), w('eventType', '==', canon), w('hour', '==', hh)));
      
      snap1.forEach(d => toUpdate.set(d.id, d));
    } catch (e) {
      console.warn('❌ Erro na query eventType canônico:', e.message);
    }
    
    // Query com hh (formato alternativo)
    try {
      
      const snap2 = await g(q(ovRef, w('date', '==', date), w('eventType', '==', canon), w('hh', '==', hh)));
      
      snap2.forEach(d => toUpdate.set(d.id, d));
    } catch (e) {
      console.warn('❌ Erro na query hh:', e.message);
    }
    
    // Variações de aliases
    for (const v of variants) {
      if (!v) continue;
      try {
        
        const snapV = await g(q(ovRef, w('date', '==', date), w('eventType', '==', v), w('hour', '==', hh)));
        
        snapV.forEach(d => toUpdate.set(d.id, d));
      } catch (e) {
        console.warn(`  ⚠️ Erro variant ${v}:`, e.message);
      }
    }
    
    // Fallback: documentos sem eventType definido (apenas se necessário)
    try {
      
      const snapAll = await g(q(ovRef, w('date', '==', date)));
      
      snapAll.forEach(d => {
        const raw = d.data() || {};
        const hhDoc = extractHour(raw.hour || raw.hh);
        
        if (!hhDoc || hhDoc !== hh) {
          
          return;
        }
        const docFamily = canonicalType(raw.eventType || raw.event_type || '');
        if (docFamily && docFamily !== canon) {
          
          return;
        }
        if (!docFamily && !variants.includes(null) && !variants.includes('')) {
          
          return;
        }
        
        toUpdate.set(d.id, d);
      });
    } catch (e) {
      console.warn('❌ Erro ao buscar overrides fallback:', e.message);
    }
    
    const result = Array.from(toUpdate.values());
    
    return result;
  }

  // Carrega quadro de horários por data/evento
  async function loadCampSemifinalLinks(force = false) {
    try{
      if (!window.firebaseDb) return {};
      if (campSemifinalLinksLoaded && !force) return campSemifinalLinks;
      const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const ref = collection(window.firebaseDb, 'camp_semifinal_links');
      const snap = await getDocs(ref);
      campSemifinalLinks = {};
      snap.forEach(doc => {
        const data = doc.data() || {};
        campSemifinalLinks[doc.id] = data;
      });
      campSemifinalLinksLoaded = true;
      return campSemifinalLinks;
    }catch(error){
      console.error('❌ Erro ao carregar links das semifinais do Camp:', error);
      return campSemifinalLinks;
    }
  }

  function renderCampSemifinalLinksPanel(selectedDate = null) {
    const panel = document.getElementById('campSemifinalLinksPanel');
    const list = document.getElementById('campSemifinalLinksList');
    if (!panel || !list) return;
    const normalizedDate = (selectedDate && /^\d{4}-\d{2}-\d{2}$/.test(selectedDate)) ? selectedDate : null;
    const year = normalizedDate ? normalizedDate.slice(0,4) : null;
    const relevantDates = year ? CAMP_SEMIFINAL_DATES.filter(d => d.startsWith(year)) : [];

    if (!normalizedDate || !relevantDates.includes(normalizedDate)) {
      panel.classList.add('hidden');
      list.innerHTML = '';
      return;
    }

    panel.classList.remove('hidden');
    list.innerHTML = '';

    relevantDates.forEach((dateValue, index) => {
      const linkData = campSemifinalLinks[dateValue] || {};
      const linkValue = linkData.link || '';
      const fmt = new Date(`${dateValue}T00:00:00`);
      const dateLabel = fmt.toLocaleDateString('pt-BR', { day:'2-digit', month:'2-digit', year:'numeric' });
      const suffix = index === 0 ? '(Link 1)' : '(Link 2)';
      const card = document.createElement('div');
      card.className = 'bg-white border border-red-200 rounded-lg p-4 shadow-sm';
      const escapedValue = linkValue ? linkValue.replace(/"/g,'&quot;') : '';
      card.innerHTML = `
        <div class="flex items-start justify-between gap-3">
          <div>
            <p class="text-sm font-semibold text-red-700">${dateLabel} • 17h ${suffix}</p>
            <p class="text-xs text-gray-500">Cole o link do grupo onde enviará ID e senha da sala.</p>
          </div>
        </div>
        <div class="mt-3 space-y-2">
          <input data-camp-link-input="${dateValue}" type="url" value="${escapedValue}" placeholder="https://chat.whatsapp.com/..." class="w-full border border-red-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-300" />
          <div class="flex items-center gap-2">
            <button data-save-camp-link="${dateValue}" class="px-3 py-2 bg-red-600 text-white rounded text-xs font-semibold hover:bg-red-700">Salvar link</button>
            <span id="campSemifinalStatus-${dateValue}" class="text-xs ${linkValue ? 'text-green-700' : 'text-gray-500'}">
              ${linkValue ? 'Link ativo' : 'Nenhum link cadastrado'}
            </span>
          </div>
        </div>
      `;
      list.appendChild(card);
    });
  }

  async function saveCampSemifinalLink(dateValue) {
    try{
      if (!window.firebaseDb) {
        showNotification('Firebase não inicializado ainda', 'error');
        return;
      }
      const input = document.querySelector(`[data-camp-link-input="${dateValue}"]`);
      if (!input) return;
      const link = input.value.trim();
      const { doc, setDoc, collection, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const ref = doc(collection(window.firebaseDb, 'camp_semifinal_links'), dateValue);
      await setDoc(ref, {
        date: dateValue,
        hour: '17h',
        link,
        status: link ? 'active' : 'inactive',
        updatedAt: serverTimestamp()
      }, { merge: true });
      showNotification('Link atualizado com sucesso!', 'success');
      await loadCampSemifinalLinks(true);
      renderCampSemifinalLinksPanel(dateValue);
    }catch(error){
      console.error('❌ Erro ao salvar link da semifinal do Camp:', error);
      showNotification('Erro ao salvar link da semifinal', 'error');
    }
  }

  (function(){
    const panel = document.getElementById('campSemifinalLinksPanel');
    if (panel) {
      panel.addEventListener('click', async (event)=>{
        const btn = event.target.closest('[data-save-camp-link]');
        if (!btn) return;
        const dateValue = btn.getAttribute('data-save-camp-link');
        await saveCampSemifinalLink(dateValue);
      });
    }
    const refreshBtn = document.getElementById('campSemifinalLinksRefresh');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', async ()=>{
        await loadCampSemifinalLinks(true);
        const dateValue = document.getElementById('boardDate')?.value || null;
        renderCampSemifinalLinksPanel(dateValue);
      });
    }
  })();

  let _isLoadingBoard = false;
  async function loadBoard(){
    if (_isLoadingBoard) return;
    _isLoadingBoard = true;
    try {
      // Validação de elementos DOM
      const dateEl = document.getElementById('boardDate');
      const typeEl = document.getElementById('boardEventType');
      const tbody = document.getElementById('boardTbody');
      if (!dateEl || !typeEl || !tbody) {
        console.warn('Elementos DOM não encontrados para loadBoard');
        return;
      }

      const date = dateEl.value;
      const eventType = typeEl.value;
      
      // Validação de data
      if (!date) {
        renderCampSemifinalLinksPanel(null);
        tbody.innerHTML = '';
        return
      }

      const ovEventType = canonicalType(eventType);
      const isCampSemifinalDate = CAMP_SEMIFINAL_DATES.includes(date);
      const isCampFinalDate = CAMP_FINAL_DATES.includes(date);

      // ===== Configuração de UI por role =====
      const btnClearLocks = document.getElementById('btnClearLocks');
      if (window.adminRoleLower === 'staff') {
        if (btnClearLocks) btnClearLocks.style.display = 'none';
        if (typeEl) {
          typeEl.value = 'xtreino-tokens';
          typeEl.disabled = true;
        }
      } else {
        if (typeEl) typeEl.disabled = false;
        if (btnClearLocks) btnClearLocks.style.display = '';
      }

      // ===== Carregar dados de semifinal =====
      if (ovEventType === 'camp-freitas') {
        await loadCampSemifinalLinks();
        renderCampSemifinalLinksPanel(date);
      } else {
        renderCampSemifinalLinksPanel(null);
      }

      // ===== Bind do botão de destravar tudo do dia =====
      bindClearLocksButton(btnClearLocks, date, ovEventType);

      // ===== Determinar horários e capacidade =====
      const defaultHours = getDefaultHoursForEvent(eventType, isCampFinalDate);
      
      if (defaultHours.length === 0) {
        tbody.innerHTML = '';
        return;
      }

      // ===== Carregar dados de registrations =====
      const occupancyMap = await fetchRegistrationsByDate(date, eventType);

      // ===== Carregar overrides (travas e extras) =====
      let overridesMap = await fetchScheduleOverrides(date, ovEventType);
      
      // Aplicar travas fixas do Modo Liga
      //overridesMap = applyFixedModoLigaLocks(overridesMap, ovEventType);

      // Mesclar overrides no mapa de ocupação
      const mergedMap = {};
      defaultHours.forEach(hour => {
        const occupied = occupancyMap[hour] || 0;
        const cap = getCapacityForHour(eventType, hour, isCampFinalDate, isCampSemifinalDate);
        let final = occupied;
        
        const ovData = overridesMap[hour];
        if (ovData?.extraOccupied) {
          final += ovData.extraOccupied;
        }
        if (ovData?.lockedAny) {
          final = cap;
        }
        
        mergedMap[hour] = final;
      });

      // ===== Filtrar horários por role =====
      let entries = [...defaultHours].sort((a, b) => {
        const na = parseInt(String(a).replace(/\D/g,'')) || 0;
        const nb = parseInt(String(b).replace(/\D/g,'')) || 0;
        return na - nb;
      });
      entries = filterEntriesByRole(entries);

      // ===== Renderizar tabela =====
      tbody.innerHTML = '';
      
      if (entries.length === 0) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td class="py-2" colspan="3">Sem horários disponíveis para esta data/evento.</td>';
        tbody.appendChild(tr);
        return;
      }

      entries.forEach(hour => {
        const cap = getCapacityForHour(eventType, hour, isCampFinalDate, isCampSemifinalDate);
        const occupied = mergedMap[hour] || 0;
        const tr = createBoardTableRow(hour, cap, occupied, overridesMap, ovEventType);
        tbody.appendChild(tr);
      });

      // ===== Bind dos botões de ação =====
      bindBoardTableActions(tbody, date, eventType, ovEventType);

    } catch (e) {
      console.error('❌ Erro em loadBoard:', e.message || e);
    } finally {
      _isLoadingBoard = false;
    }
  }

  // Binda ações dos botões da tabela
  function bindBoardTableActions(tbody, date, eventType, ovEventType) {
    // Remover listeners antigos para evitar duplicação
    if (!tbody || !tbody.parentNode) return;
    const newTbody = tbody.cloneNode(true);
    tbody.parentNode.replaceChild(newTbody, tbody);
    
    newTbody.addEventListener('click', async (e) => {
      try {
        const btnAdd = e.target.closest('[data-add-hour]');
        const btnManage = e.target.closest('[data-manage-hour]');
        const btnToggle = e.target.closest('[data-toggle-lock]');
        const btnExport = e.target.closest('[data-export-hour]');

        if (btnAdd) {
          const h = btnAdd.getAttribute('data-add-hour');
          const modal = document.getElementById('modalAddTeam');
          const hourInput = document.getElementById('addHour');
          if (hourInput) hourInput.value = h;
          if (modal) modal.classList.remove('hidden');
        } 
        else if (btnManage) {
          const h = btnManage.getAttribute('data-manage-hour');
          openManageHourModal(date, eventType, h);
        } 
        else if (btnExport) {
          const h = btnExport.getAttribute('data-export-hour');
          try {
            const text = await buildExportList(date, ovEventType, h);
            await navigator.clipboard.writeText(text);
            alert('Lista copiada para a área de transferência.');
          } catch (err) {
            console.error('Falha ao exportar lista:', err);
            alert('Falha ao exportar lista.');
          }
        } 
        else if (btnToggle) {
          const h = btnToggle.getAttribute('data-toggle-lock');
          await handleToggleLock(h, date, eventType, ovEventType);
        }
      } catch (e) {
        console.error('Erro ao processar ação da tabela:', e);
      }
    });
  }

  // Handler para toggle de travamento de horário
  async function handleToggleLock(hour, date, eventType, ovEventType) {
    
    const isFixedLock = false // (canonicalType(eventType) === 'modo-liga' && (hour === '16:00' || hour === '17:00'));
    
    
    if (isFixedLock) {
      // Verificar estado atual (se "Destravar" está visível)
      const btn = document.querySelector(`[data-toggle-lock="${hour}"]`);
      const isCurrentlyLocked = btn?.textContent.trim() === 'Destravar';
      
      
      if (isCurrentlyLocked) {
        const userConfirmed = await confirm(`⚠️ ATENÇÃO: Este horário (${hour}) está configurado como fixo travado para o Modo Liga.\n\nDeseja realmente destravar?`);
        
        if (!userConfirmed) {          
          return;
        }
      }
    }

    try {
      const hh = extractHour(hour);
      
      if (!hh) {
        alert('Erro: horário inválido');
        return;
      }      

      const docsArr = await findAllOverridesForHour(date, eventType, hh);       
      if (docsArr.length > 0) {        
        // Verificar estado atual
        const anyLocked = docsArr.some(d => d.data()?.locked === true);
        const newLocked = !anyLocked;
        
        // Atualizar em batch
        const { writeBatch, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const batch = writeBatch(window.firebaseDb);
        
        docsArr.forEach(d => {
          const ref = doc(window.firebaseDb, 'schedule_overrides', d.id);
          
          batch.update(ref, { locked: newLocked, eventType: ovEventType, hour: hh, hh });
        });
        
        await batch.commit();
        
      } else {
        
        // Criar novo documento
        const { addDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const ovRef = collection(window.firebaseDb, 'schedule_overrides');
        const newDoc = await addDoc(ovRef, { 
          date, 
          eventType: ovEventType, 
          hour: hh, 
          hh, 
          locked: true, 
          extraOccupied: 0, 
          createdAt: Date.now() 
        });
        
      }

      await loadBoard();
      
    } catch (e) {
      console.error('❌ Erro ao alternar trava:', e);
      console.error('📋 Stack:', e.stack);
      alert('Falha ao alternar trava do horário.\n\nErro: ' + (e.message || 'Desconhecido'));
    }
  }



  function bindClearLocksButton(btn, date, ovEventType) {
    if (!btn || window.adminRoleLower === 'staff') return;

    // Remover listener anterior se existir (permite rebinding quando evento muda)
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);    
    
    newBtn.addEventListener('click', async () => {
        try {
            const canon = canonicalType(ovEventType);
            const variants = resolveAliases(ovEventType);                     
            
            const userConfirmed = await confirm(`Destravar todas as travas e zerar ocupações extras de ${date} (${ovEventType})?`);
            
            if (!userConfirmed) {                
                return;
            }

            const { collection, query, where, getDocs, doc, writeBatch } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            const ovRef = collection(window.firebaseDb, 'schedule_overrides');
            const updates = [];

            // Query 1: Buscar por variantes canônicas/aliases            
            for (const v of variants) {
                if (!v) continue;
                try {
                    const snap = await getDocs(query(ovRef, where('date', '==', date), where('eventType', '==', v)));
                    
                    snap.forEach(d => {
                        const data = d.data();

                        updates.push({ 
                            ref: doc(window.firebaseDb, 'schedule_overrides', d.id), 
                            data: { locked: false, extraOccupied: 0, eventType: canon } 
                        });
                    });
                } catch (e) {
                    console.warn(`  ⚠️  Erro na variante "${v}":`, e.message);
                }
            }

            // Query 2: Fallback - apenas documentos que AINDA não têm eventType ou que combinam com aliases            
            try {
                const snapAll = await getDocs(query(ovRef, where('date', '==', date)));               
                
                snapAll.forEach(d => {
                    // Pular se já foi adicionado na Query 1
                    if (updates.some(u => u.ref._key.path.segments[1] === d.id)) {                        
                        return;
                    }
                    
                    const raw = d.data();
                    const docFamily = canonicalType(raw.eventType || raw.event_type || '');                    
                    
                    // Incluir APENAS se:
                    // 1. Não tem eventType (docs antigos) OU
                    // 2. O eventType corresponde ao canonicalType do evento selecionado
                    if (!docFamily) {                        
                        updates.push({ 
                            ref: doc(window.firebaseDb, 'schedule_overrides', d.id), 
                            data: { locked: false, extraOccupied: 0, eventType: canon } 
                        });
                    } else if (docFamily === canon) {                        
                        updates.push({ 
                            ref: doc(window.firebaseDb, 'schedule_overrides', d.id), 
                            data: { locked: false, extraOccupied: 0, eventType: canon } 
                        });
                    } 
                });
            } catch (e) {
                console.warn('❌ Erro no fallback:', e.message);
            }            
            
            if (updates.length === 0) {                
                showToast('info', 'Nenhuma trava encontrada para este dia', 'Info');
                return;
            }

            // Commit em chunks de 400 (limite do Firestore é 500)
            const CHUNK_SIZE = 400;
            for (let i = 0; i < updates.length; i += CHUNK_SIZE) {
                const chunk = updates.slice(i, i + CHUNK_SIZE);
                const batch = writeBatch(window.firebaseDb);
                chunk.forEach(u => {
                    batch.update(u.ref, u.data);
                });
                const chunkNum = Math.floor(i / CHUNK_SIZE) + 1;
                const totalChunks = Math.ceil(updates.length / CHUNK_SIZE);                
                await batch.commit();
            }            
            
            showToast('success', `trava(s) removida(s) e ocupações zeradas`, 'Sucesso');
            await loadBoard();
        } catch (error) {            
            showToast('error', `Falha ao destravar tudo: ${error.message}`, 'Erro');
        }
    });
  }

  async function openManageHourModal(date, eventType, hour){
    try{
      const title = document.getElementById('manageHourTitle');
      const list = document.getElementById('manageHourList');
      const modal = document.getElementById('modalManageHour');
      if (!list || !modal) return;
      if (title) title.textContent = `Gerenciar ${hour} — ${date}`;
      list.innerHTML = '<div class="text-sm text-gray-500">Carregando...</div>';
      const { collection, query, where, getDocs, doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const regs = collection(window.firebaseDb,'registrations');
      // Busca reservas PAGAS/CONFIRMADAS do dia; filtra por eventType e hora com normalização (schedule ou hour)
      const snap = await getDocs(query(regs, where('date','==', date), where('status','in',['paid','confirmed','approved'])));
      list.innerHTML = '';
      let any = false;
      const evLower = String(eventType||'').toLowerCase();
      const normalizeHour = (s)=>{ const m = String(s||'').match(/(\d{1,2})/); return m? String(parseInt(m[1],10)).padStart(2,'0') : null; };
      const targetHH = normalizeHour(hour);
      snap.forEach(d=>{
        const r = d.data();
        if (evLower && r.eventType && !String(r.eventType).toLowerCase().includes(evLower)) return;
        const schedStr = String(r.schedule||'');
        const hourStr = String(r.hour||'');
        const regHH = normalizeHour(schedStr) || normalizeHour(hourStr);
        if (targetHH && regHH && targetHH !== regHH) return;
        any = true;
        const row = document.createElement('div');
        row.className = 'flex items-center justify-between border-b py-2';
        row.innerHTML = `<div class="text-sm"><div class="font-semibold">${r.teamName||r.email||'-'}</div><div class="text-gray-500">${r.contact||r.phone||''}</div></div>
          <button class="px-2 py-1 bg-red-600 text-white rounded text-xs" data-remove-reg-id="${d.id}">Remover</button>`;
        list.appendChild(row);
      });
      if (!any){ list.innerHTML = '<div class="text-sm text-gray-500">Nenhum time neste horário.</div>'; }
      list.addEventListener('click', async (e)=>{
        const btn = e.target.closest('[data-remove-reg-id]');
        if (!btn) return;
        const id = btn.getAttribute('data-remove-reg-id');
        try{
          await deleteDoc(doc(collection(window.firebaseDb,'registrations'), id));
          btn.closest('.flex')?.remove();
          try{ await loadBoard(); }catch(_){ }
        }catch(_){ alert('Falha ao remover.'); }
      });
      modal.classList.remove('hidden');
    }catch(e){ console.error('openManageHourModal error', e); }
  }

  // Usuários ativos nos últimos 30 dias (baseado em lastLogin em users)
  async function renderActiveUsers(){
    try{
          const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      const snap = await getDocs(collection(window.firebaseDb,'users'));
      const thirtyDaysAgo = Date.now() - 30*24*60*60*1000;
      let active = 0; snap.forEach(d=>{ const u=d.data(); if (Number(u.lastLogin||0) >= thirtyDaysAgo) active++; });
          const kpiActiveEl = document.getElementById('kpiActiveUsers');
          if (kpiActiveEl) kpiActiveEl.textContent = String(active);
    }catch(e){  }
  }

  // [removido duplicado]
})();

// ===== Exportação de lista por horário =====
async function buildExportList(date, eventType, hour){
  const hh = String(hour).match(/(\d{1,2})/)?.[1] || '';
  const { collection, getDocs, query, where } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
  const regs = collection(window.firebaseDb,'registrations');
  const snap = await getDocs(query(regs, where('date','==', date)));
  // Normalização robusta do tipo de evento para casar variações (ex.: 'XTREINO MODO LIGA', 'modo-liga', 'modoLiga')
  const normalize = (s)=> String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
  const evLower = normalize(eventType);
  const normalizeHour = (s)=>{ const m = String(s||'').match(/(\d{1,2})/); return m ? String(parseInt(m[1],10)).padStart(2,'0') : null; };
  const teams = [];
  snap.forEach(d=>{
    const r = d.data();
    // Aplicar filtro por tipo de evento com sinônimos
    const rType = normalize(r.eventType);
    if (evLower){
      if (evLower.includes('liga')) { if (!rType.includes('liga')) return; }
      else if (evLower.includes('semanal')) { if (!rType.includes('semanal')) return; }
      else if (evLower.includes('camp')) { if (!rType.includes('camp')) return; }
      else if (evLower.includes('xtreino') || evLower.includes('tokens')) {
        if (!(rType.includes('xtreino') || rType.includes('tokens'))) return;
      }
    }
    const regHH = normalizeHour(r.schedule) || normalizeHour(r.hour);
    if (regHH !== hh) return;
    const st = String(r.status||'').toLowerCase();
    if (!['paid','confirmed'].includes(st)) return;
    const name = r.teamName || r.name || r.email || 'Time';
    teams.push({ name, createdAt: r.createdAt?.toDate?.() || new Date(0) });
  });
  teams.sort((a,b)=> (a.createdAt?.getTime?.()||0) - (b.createdAt?.getTime?.()||0));
  // Definir capacidade por tipo (modo liga = 15; demais = 12)
  const type = String(eventType||'').toLowerCase();
  const capacity = type.includes('liga') ? 15 : 12;
  const slots = [];
  for (let i=1;i<=capacity;i++){
    const t = teams[i-1]?.name || '';
    slots.push({ idx: i, team: t });
  }
  const dd = date.split('-');
  const dateBr = dd.length===3 ? `${dd[2]}/${dd[1]}` : date;
  const H = hh;
  if (type.includes('semanal')){
    const header = `░𝐒𝐄𝐌𝐀𝐍𝐀𝐋 𝐅𝐑𝐄𝐈𝐓𝐀𝐒//𝟏ª𝐅𝐀𝐒𝐄 ${H}𝐇░`;
    const rules = `\n\n🆔 𝐄 𝐒𝐄𝐍𝐇𝐀 𝟏𝟎 𝐌𝐈𝐍𝐔𝐓𝐎𝐒 𝐀𝐍𝐓𝐄𝐒\n📋𝐑𝐄𝐆𝐑𝐀𝐒 𝐍𝐀 𝐃𝐄𝐒𝐂𝐑𝐈ÇÃ𝐎\n`;
    const lines = slots.map((s,idx)=>{
      const prefix = (idx%2===0) ? '╭⊱💚⊱╮' : '╰⊱💚⊱╯';
      const num = String(s.idx).padStart(2,'0');
      return `${prefix}𝑺𝑳𝑶𝑻 ${num}: ${s.team}`;
    }).join('\n\n');
    const footer = `\n\n|🛡️|𝐂𝐋𝐀𝐒𝐒𝐈𝐅𝐈𝐂𝐀𝐌 𝟒 𝐄𝐐𝐔𝐈𝐏𝐄𝐒 𝐃𝐈𝐑𝐄𝐓𝐎 𝐏𝐑𝐀 𝐅𝐈𝐍𝐀𝐋 𝐇𝐎𝐉𝐄!\n\n𝐁𝐎𝐀 𝐒𝐎𝐑𝐓𝐄 𝐀 𝐓𝐎𝐃𝐎𝐒!`;
    return `${header}\n${rules}\n${lines}\n${footer}`;
  } else if (type.includes('camp')){
    const header = `𝐂𝐀𝐌𝐏𝐄𝐎𝐍𝐀𝐓𝐎 𝐅𝐑𝐄𝐈𝐓𝐀𝐒| 2ª𝐅𝐀𝐒𝐄 ${H}𝐇 \n\n🗓️ 𝐃𝐀𝐓𝐀 : ${dateBr}\n🆔 𝐄 𝐒𝐄𝐍𝐇𝐀 𝟏𝟎 𝐌𝐈𝐍𝐔𝐓𝐎𝐒 𝐀𝐍𝐓𝐄𝐒\n📋𝐑𝐄𝐆𝐑𝐀𝐒 𝐍𝐀 𝐃𝐄𝐒𝐂𝐑𝐈ÇÃ𝐎\n`;
    const lines = slots.map((s,idx)=>{
      const num = String(s.idx).padStart(2,'0');
      if (idx===0) return `╔❤️╗𝑺𝑳𝑶𝑻 ${num}: ${s.team}`;
      if (idx===slots.length-1) return `╚❤️╝𝑺𝑳𝑶𝑻 ${num}: ${s.team}`;
      return `╟❤️╢𝑺𝑳𝑶𝑻 ${num}: ${s.team}`;
    }).join('\n\n');
    const footer = `\n\n🛡️•𝑪𝑳𝑨𝑺𝑺𝑰𝐅𝐈𝐂𝐀𝐌 𝟔 𝑬𝑸𝑼𝐈𝐏𝐄𝐒 𝑷𝑹𝑨 𝑷𝑹𝑶́𝑿𝐈𝐌𝐀 𝑭𝐀𝐒𝐄!\n\n𝐁𝐎𝐀 𝐒𝐎𝐑𝐓𝐄 𝐀 𝐓𝐎𝐃𝐎𝐒!`;
    return `${header}\n${lines}\n${footer}`;
  } else if (type.includes('liga')) {
    // Modo Liga: formato conforme exemplo enviado
    const header = `:::𝑳𝑰𝑺𝑻𝑨 𝑴𝑶𝑫𝑶 𝑳𝑰𝑮𝑨 ⋮ 𝑿𝑻 𝑭𝑹𝑬𝑰𝑻𝑨𝑺 ${H}H:::\n\n\n\n➺🆔 𝑬  𝑺𝑬𝑵𝐇𝑨: 𝟏𝟎 𝑴𝐈𝑵𝑼𝑻𝑶𝑺 𝑨𝑵𝑻𝑬𝑺\n\n➺🏷️𝑹𝑬𝑮𝑹𝑨𝑺 𝑵𝑨 𝑫𝑬𝑺𝑪𝑹𝐈ÇÃ𝐎\n`;
    // Garantir que todos os slots sejam incluídos, mesmo vazios, sem pular linhas
    const lines = slots.map(s=>{
      const num = String(s.idx).padStart(2,'0');
      const teamName = s.team || ''; // Slot vazio fica sem nome, mas linha é criada
      return `   ⃟🩵 ${num}: ${teamName}`;
    }).filter(line => line.trim()).join('\n\n'); // Filtrar linhas completamente vazias
    const footer = `\n\n「📽️」𝑺𝑻𝑹𝑬𝑨𝑴𝑬𝑹: \n\n「🧑🏻‍🏫」𝑪𝑶𝑨𝑪𝑯:`;
    return `${header}\n${lines}\n\n${footer}`;
  } else {
    // XTreino normal (padrão)
    const header = `:::𝑳𝑰𝑺𝑻𝑨 𝑫𝑬 𝑺𝑳𝑶𝑻 ⋮ 𝑿𝑻 𝑭𝑹𝑬𝑰𝑻𝑨𝑺 ${H}H:::\n\n➺🆔 𝑬  𝑺𝑬𝑵𝐇𝑨: 𝟏𝟎 𝑴𝐈𝑵𝑼𝑻𝑶𝑺 𝑨𝑵𝑻𝑬𝑺\n➺🏷️𝑹𝑬𝑮𝑹𝑨𝑺 𝑵𝑨 𝑫𝑬𝑺𝑪𝑹𝐈ÇÃ𝐎\n`;
    // Garantir que todos os slots sejam incluídos, mesmo vazios, sem pular linhas
    const lines = slots.map(s=>{
      const num = String(s.idx).padStart(2,'0');
      const teamName = s.team || ''; // Slot vazio fica sem nome, mas linha é criada
      return `   ⃟🩵 𝑺𝑳𝑶𝑻 ${num}: ${teamName}`;
    }).filter(line => line.trim()).join('\n\n'); // Filtrar linhas completamente vazias
    const footer = `\n\n「📽️」𝑺𝑻𝑹𝑬𝑨𝑴𝑬𝑹: \n\n「🧑🏻‍🏫」𝑪𝑶𝑨𝑪𝑯:`;
    return `${header}\n\n${lines}\n${footer}`;
  }
}

// Admin logic: Auth gate, roles, Firestore reads, Chart.js rendering

async function ensureFirebase(maxWaitMs = 5000) {
    const start = Date.now();
    while (!window.firebaseReady && Date.now() - start < maxWaitMs) {
        await new Promise(r => setTimeout(r, 150));
    }
    return !!window.firebaseReady;
}

function currencyBRL(value) {
    return (value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
async function fetchRole(uid) {
    const { doc, getDoc, collection, query, where, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    // 1) tentativa direta por docId == uid
    const ref = doc(collection(window.firebaseDb,'users'), uid);
    let snap = await getDoc(ref);
    if (snap.exists()) return { role: (snap.data().role || 'Usuario') };
    // 2) fallback: procurar por campo uid
    try{
        const q = query(collection(window.firebaseDb,'users'), where('uid','==', uid));
        const res = await getDocs(q);
        let found = null;
        res.forEach(d=>{ if (!found) found = d.data(); });
        if (found) return { role: (found.role || 'Usuario') };
    }catch(_){ }
    return { role: 'Usuario' };
}

function can(role, permission) {
    const matrix = {
        admin: ['view_all', 'manage_products', 'edit_content'],
        manager: ['view_all', 'manage_products'],
        editor: ['edit_content'],
        viewer: []
    };
    return (matrix[role?.role] || []).includes(permission);
}

async function loadKPIs() {
    const { collection, query, where, orderBy, limit, getDocsFromServer } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const ordersCol = collection(window.firebaseDb, 'orders');

    

    // Today sales (sum) - apenas pedidos pagos
    const today = new Date();
    today.setHours(0,0,0,0);
    const qToday = query(ordersCol, where('createdAt', '>=', today));
    const todaySnap = await getDocsFromServer(qToday);
    let sumToday = 0;
    todaySnap.forEach(d => {
        const data = d.data();
        const status = (data.status || '').toLowerCase();
        if (status === 'paid' || status === 'approved' || status === 'confirmed') {
            sumToday += Number(data.amount || 0);
        }
    });
    document.getElementById('kpiToday').textContent = currencyBRL(sumToday);
    

    // Month sales - apenas pedidos pagos
    const firstMonth = new Date();
    firstMonth.setDate(1); firstMonth.setHours(0,0,0,0);
    const qMonth = query(ordersCol, where('createdAt', '>=', firstMonth));
    const monthSnap = await getDocsFromServer(qMonth);
    let sumMonth = 0, receivable = 0;
    monthSnap.forEach(d => {
        const data = d.data();
        const val = Number(data.amount || 0);
        const status = (data.status || '').toLowerCase();
        
        // Apenas pedidos pagos para o total do mês
        if (status === 'paid' || status === 'approved' || status === 'confirmed') {
            sumMonth += val;
        }
        
        // Pedidos pendentes para receber
        if (status === 'pending') {
            receivable += val;
        }
    });
    document.getElementById('kpiMonth').textContent = currencyBRL(sumMonth);
    document.getElementById('kpiReceivable').textContent = currencyBRL(receivable);
    
}

async function loadCharts() {
    const { collection, query, orderBy, limit, getDocsFromServer } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const ordersCol = collection(window.firebaseDb, 'orders');
    const q = query(ordersCol, orderBy('createdAt', 'desc'), limit(50));
    const snap = await getDocsFromServer(q);

    const byDay = new Map();
    const top = new Map();
    snap.forEach(d => {
        const data = d.data();
        const day = (data.createdAt?.toDate ? data.createdAt.toDate() : new Date()).toISOString().slice(0,10);
        byDay.set(day, (byDay.get(day) || 0) + Number(data.amount || 0));
        const name = data.itemName || 'Produto';
        top.set(name, (top.get(name) || 0) + Number(data.amount || 0));
    });

    const labels = Array.from(byDay.keys()).sort();
    const values = labels.map(k => byDay.get(k));

    const topEntries = Array.from(top.entries()).sort((a,b) => b[1]-a[1]).slice(0,5);
    const topLabels = topEntries.map(e => e[0]);
    const topValues = topEntries.map(e => e[1]);

    const salesCtx = document.getElementById('salesChart');
    new Chart(salesCtx, {
        type: 'line',
        data: { labels, datasets: [{ label: 'Vendas (R$)', data: values, borderColor: '#4a90e2', backgroundColor: 'rgba(74,144,226,0.15)', tension: 0.3 }] },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    const topCtx = document.getElementById('topProductsChart');
    new Chart(topCtx, {
        type: 'bar',
        data: { labels: topLabels, datasets: [{ label: 'Faturamento', data: topValues, backgroundColor: '#4a90e2' }] },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });
}

// ===== SISTEMA DE FILTROS PARA HORÁRIOS MAIS PROCURADOS =====

// Variável global para armazenar o gráfico
let popularHoursChart = null;

// Função para carregar eventos únicos do banco de dados
async function loadEventOptions() {
    try {
        if (!window.firebaseDb) {
            console.warn('Firebase não inicializado ainda');
            return;
        }
        
        const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const registrationsCol = collection(window.firebaseDb, 'registrations');
        const snap = await getDocs(registrationsCol);
        
        const events = new Set();
        snap.forEach(doc => {
            const data = doc.data();
            if (data.eventType && data.eventType.trim()) {
                events.add(data.eventType.trim());
            }
        });
        
        const eventFilter = document.getElementById('eventFilter');
        if (eventFilter) {
            // Limpar opções existentes (exceto a primeira)
            eventFilter.innerHTML = '<option value="">Todos os eventos</option>';
            
            // Adicionar eventos únicos ordenados alfabeticamente
            Array.from(events).sort().forEach(event => {
                const option = document.createElement('option');
                option.value = event;
                option.textContent = event;
                eventFilter.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Erro ao carregar eventos:', error);
    }
}

// Função para obter o dia da semana em português
function getDayOfWeek(date) {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    return days[date.getDay()];
}

// Função para carregar dados de horários com filtros
async function loadPopularHoursData(dayFilter = '', eventFilter = '') {
    try {
        if (!window.firebaseDb) {
            console.warn('Firebase não inicializado ainda');
            return { labels: [], data: [] };
        }
        
        const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const registrationsCol = collection(window.firebaseDb, 'registrations');
        const snap = await getDocs(registrationsCol);
        
        const hourCounts = new Map();
        
        snap.forEach(doc => {
            const data = doc.data();
            
            // Filtrar por status (apenas confirmados/pagos)
            if (!['paid', 'confirmed', 'approved'].includes(data.status)) return;
            
            // Filtrar por evento se especificado
            if (eventFilter && data.eventType !== eventFilter) return;
            
            // Filtrar por dia da semana se especificado
            if (dayFilter) {
                const registrationDate = data.date ? new Date(data.date) : new Date();
                const dayOfWeek = getDayOfWeek(registrationDate);
                if (dayOfWeek !== dayFilter) return;
            }
            
            // Extrair horário
            const hour = data.schedule || data.hour || '—';
            if (hour && hour !== '—') {
                hourCounts.set(hour, (hourCounts.get(hour) || 0) + 1);
            }
        });
        
        // Converter para arrays ordenados
        const entries = Array.from(hourCounts.entries());
        entries.sort((a, b) => {
            // Extrair número do horário para ordenação
            const hourA = parseInt(String(a[0]).replace(/\D/g, '')) || 0;
            const hourB = parseInt(String(b[0]).replace(/\D/g, '')) || 0;
            return hourA - hourB;
        });
        
        return {
            labels: entries.map(([hour]) => hour),
            data: entries.map(([, count]) => count)
        };
    } catch (error) {
        console.error('Erro ao carregar dados de horários:', error);
        return { labels: [], data: [] };
    }
}

// Função para renderizar o gráfico de horários mais procurados
async function renderPopularHours() {
    try {
        const dayFilter = document.getElementById('dayFilter')?.value || '';
        const eventFilter = document.getElementById('eventFilter')?.value || '';
        
        const chartData = await loadPopularHoursData(dayFilter, eventFilter);
        const ctx = document.getElementById('popularHoursChart');
        
        if (!ctx) return;
        
        // Destruir gráfico existente se houver
        if (popularHoursChart) {
            popularHoursChart.destroy();
        }
        
        // Criar novo gráfico
        popularHoursChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: 'Demanda',
                    data: chartData.data,
                    backgroundColor: '#4a90e2',
                    borderColor: '#357abd',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                aspectRatio: 2.5,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return `Demanda: ${context.parsed.y} reservas`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            font: {
                                size: 10
                            }
                        }
                    },
                    x: {
                        ticks: {
                            maxRotation: 45,
                            font: {
                                size: 10
                            }
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Erro ao renderizar gráfico de horários:', error);
    }
}

// Função para configurar event listeners dos filtros
function setupPopularHoursFilters() {
    const dayFilter = document.getElementById('dayFilter');
    const eventFilter = document.getElementById('eventFilter');
    const resetBtn = document.getElementById('resetFiltersBtn');
    
    if (dayFilter) {
        dayFilter.addEventListener('change', renderPopularHours);
    }
    
    if (eventFilter) {
        eventFilter.addEventListener('change', renderPopularHours);
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            if (dayFilter) dayFilter.value = '';
            if (eventFilter) eventFilter.value = '';
            renderPopularHours();
        });
    }
}
// ===== FIM DO SISTEMA DE FILTROS =====

async function loadTables(canManageProducts) {
    const { collection, query, orderBy, limit, getDocsFromServer } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    // Orders
    const ordersCol = collection(window.firebaseDb, 'orders');
    const qOrders = query(ordersCol, orderBy('createdAt', 'desc'), limit(20));
    const snapOrders = await getDocsFromServer(qOrders);
    const ordersTbody = document.getElementById('ordersTbody');
    if (!ordersTbody) return; // card não existe nesta visão
    ordersTbody.innerHTML = '';
    let count = 0;
    snapOrders.forEach(docu => {
        const o = docu.data();
        const tr = document.createElement('tr');
        tr.innerHTML = `<td class="py-2">${docu.id.slice(0,6)}</td>
        <td class="py-2">${o.customerName || '-'}</td>
        <td class="py-2">${o.itemName || '-'}</td>
        <td class="py-2">${currencyBRL(Number(o.amount||0))}</td>
        <td class="py-2">${o.status || '-'}</td>`;
        ordersTbody.appendChild(tr);
        count++;
    });
    const ordersCountEl = document.getElementById('ordersCount');
    if (ordersCountEl) ordersCountEl.textContent = `${count} pedidos`;

    // Products
    const productsTbody = document.getElementById('productsTbody');
    if (productsTbody) {
        const productsCol = collection(window.firebaseDb, 'products');
        const qProd = query(productsCol, orderBy('name'), limit(50));
        const snapProd = await getDocsFromServer(qProd);
        productsTbody.innerHTML = '';
        snapProd.forEach(docu => {
            const p = docu.data();
            const canEdit = canManageProducts;
            const tr = document.createElement('tr');
            tr.innerHTML = `<td class="py-2">${p.name || '-'}</td>
            <td class="py-2">${currencyBRL(Number(p.price||0))}</td>
            <td class="py-2">${p.type || '-'}</td>
            <td class="py-2 space-x-2">${canEdit ? '<button data-id="'+docu.id+'" class="text-blue-600">Editar</button>' : '<span class="text-gray-400">-</span>'}</td>`;
            productsTbody.appendChild(tr);
        });
    }
}

async function upsertUserProfile(user) {
    const { doc, setDoc, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    try {
        await setDoc(doc(window.firebaseDb, 'users', user.uid), {
            uid: user.uid,
            email: user.email || null,
            displayName: user.displayName || null,
            photoURL: user.photoURL || null,
            lastLoginAt: serverTimestamp()
        }, { merge: true });
    } catch (e) {
        console.error('user profile upsert error', e);
    }
}

async function loadUsersAndRoles(currentRole) {
    const roleStr = String(currentRole || '').toLowerCase();
    const canEditRoles = ['ceo', 'gerente'].includes(roleStr); // CEO e Gerente podem editar
    const isCeo = roleStr==='ceo';
    const isGerente = roleStr==='gerente';
    const { collection, getDocsFromServer, doc, setDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const usersCol = collection(window.firebaseDb, 'users');
    const snapUsers = await getDocsFromServer(usersCol);

    const tbody = document.getElementById('usersTbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    snapUsers.forEach(u => {
        const data = u.data();
        const role = (data.role || 'Vendedor');
        const tr = document.createElement('tr');
        // Gerar opções baseado na hierarquia de permissões
        let roleOptions = '';
        if (isCeo) {
            // CEO pode atribuir qualquer cargo
            roleOptions = `
                <option value="Vendedor" ${role==='Vendedor'?'selected':''}>Vendedor</option>
                <option value="Gerente" ${role==='Gerente'?'selected':''}>Gerente</option>
                <option value="Design" ${role==='Design'?'selected':''}>Design</option>
                <option value="Admin" ${role==='Admin'?'selected':''}>Admin</option>
                <option value="Sócio" ${role==='Sócio'?'selected':''}>Sócio</option>
                <option value="Ceo" ${role==='Ceo'?'selected':''}>Ceo</option>
            `;
        } else if (isGerente) {
            // Gerente pode atribuir apenas Vendedor
            roleOptions = `
                <option value="Vendedor" ${role==='Vendedor'?'selected':''}>Vendedor</option>
            `;
        } else {
            // Outros não podem alterar cargo
            roleOptions = `<option value="${role}" selected>${role}</option>`;
        }
        
        const selectHtml = `<select class="border border-gray-300 rounded px-2 py-1" data-uid="${u.id}" ${canEditRoles ? '' : 'disabled'}>
            ${roleOptions}
        </select>`;
        tr.innerHTML = `<td class="py-2">${data.email||'-'}</td>
        <td class="py-2">${u.id}</td>
        <td class="py-2">${selectHtml}</td>
        <td class="py-2">${canEditRoles ? '<button class="text-blue-600" data-save-role="'+u.id+'">Salvar</button>' : '<span class="text-gray-400">-</span>'}</td>`;
        tbody.appendChild(tr);
    });

    if (canEditRoles) {
        tbody.addEventListener('click', async (e) => {
            const btn = e.target.closest('[data-save-role]');
            if (!btn) return;
            const uid = btn.getAttribute('data-save-role');
            const sel = tbody.querySelector(`select[data-uid="${uid}"]`);
            if (!sel) return;
            try {
                await setDoc(doc(window.firebaseDb, 'users', uid), { role: sel.value }, { merge: true });
                btn.textContent = 'Salvo';
                setTimeout(() => btn.textContent = 'Salvar', 1200);
            } catch (err) {
                alert('Erro ao salvar role');
            }
        }, { once: true });
    }
}

async function main() {
    const ok = await ensureFirebase();
    const gate = document.getElementById('authGate');
    const dash = document.getElementById('dashboard');
    const emailForm = document.getElementById('emailLoginForm');
    const btnLogout = document.getElementById('btnLogout');
    const nameEl = document.getElementById('adminUserName');
    const initialsEl = document.getElementById('adminUserInitials');
    const roleBadge = document.getElementById('roleBadge');

    gate.classList.add('hidden');
    dash.classList.add('hidden');

    if (!ok) {
        gate.classList.remove('hidden');
        return;
    }

    const { onAuthStateChanged, signInWithEmailAndPassword, signOut } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js');

    if (emailForm && !emailForm.dataset.listenerAttached) {
        emailForm.dataset.listenerAttached = '1';
        emailForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('adminEmail').value;
            const password = document.getElementById('adminPassword').value;
            const errEl = document.getElementById('loginError');
            try {
                await signInWithEmailAndPassword(window.firebaseAuth, email, password);
            } catch (err) {
                if (errEl) { errEl.textContent = 'E-mail ou senha inválidos.'; errEl.classList.remove('hidden'); }
            }
        });
    }

    btnLogout?.addEventListener('click', async () => {
        try { await signOut(window.firebaseAuth); } catch {}
    });

    onAuthStateChanged(window.firebaseAuth, async (user) => {
        if (!user) {
            gate.classList.remove('hidden');
            dash.classList.add('hidden');
            return;
        }
        const userName = user.displayName || user.email || 'Usuário';
        if (nameEl) nameEl.textContent = userName;
        
        // Buscar foto de perfil do Firestore
        let photoURL = user.photoURL || '';
        try {
            const { doc, getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            const userDoc = await getDoc(doc(window.firebaseDb, 'users', user.uid));
            if (userDoc.exists()) {
                const userData = userDoc.data();
                photoURL = userData.photoURL || userData.photoUrl || photoURL;
            }
        } catch (err) {
            console.error('Erro ao buscar foto de perfil:', err);
        }
        
        // Atualizar avatar do admin (foto ou iniciais)
        const photoEl = document.getElementById('adminUserPhoto');
        if (initialsEl) {
            const initials = userName.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2) || 'A';
            initialsEl.textContent = initials;
        }
        
        if (photoEl) {
            if (photoURL) {
                photoEl.src = photoURL;
                photoEl.onload = function() {
                    photoEl.classList.remove('hidden');
                    if (initialsEl) initialsEl.classList.add('hidden');
                };
                photoEl.onerror = function() {
                    photoEl.classList.add('hidden');
                    if (initialsEl) initialsEl.classList.remove('hidden');
                };
                // Verificar se já está carregado
                if (photoEl.complete && photoEl.naturalHeight > 0) {
                    photoEl.classList.remove('hidden');
                    if (initialsEl) initialsEl.classList.add('hidden');
                }
            } else {
                photoEl.classList.add('hidden');
                if (initialsEl) initialsEl.classList.remove('hidden');
            }
        }
        
        let role = { role: 'viewer' };
        try {
            role = await fetchRole(user.uid);
        } catch {}
        roleBadge.textContent = `Permissões: ${role.role || 'viewer'}`;

        // Mostra o dashboard imediatamente, independentemente de erros posteriores
        gate.classList.add('hidden');
        dash.classList.remove('hidden');

        try { await loadKPIs(); } catch (e) { console.error('KPIs error', e); }
        try { await loadCharts(); } catch (e) { console.error('Charts error', e); }
        try { await loadTables(can(role, 'manage_products')); } catch (e) { console.error('Tables error', e); }
        try { await upsertUserProfile(user); } catch {}
        try { await loadUsersAndRoles(role); } catch (e) { console.error('Users error', e); }
        try { await loadPendingOrders(); } catch (e) { console.error('Pending orders error', e); }
        // try { await loadConfirmedOrders(); } catch (e) { console.error('Confirmed orders error', e); } // Desabilitado - usando nova função com paginação
    });
}

// Função para carregar pedidos confirmados
async function loadConfirmedOrders() {
    try {
        const { collection, getDocs, query, where, orderBy, limit } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        
        // Buscar pedidos com status 'paid' ou 'approved' - sem orderBy para evitar erro de índice
        const ordersRef = collection(window.firebaseDb, 'orders');
        const q = query(
            ordersRef,
            where('status', 'in', ['paid', 'approved', 'confirmed']),
            limit(50)
        );
        
        const snapshot = await getDocs(q);
        const confirmedTbody = document.getElementById('confirmedTbody');
        const confirmedCount = document.getElementById('confirmedCount');
        
        if (confirmedTbody) {
            confirmedTbody.innerHTML = '';
            
            if (snapshot.empty) {
                confirmedTbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-gray-500">Nenhum pedido confirmado encontrado</td></tr>';
            } else {
                // Ordenar manualmente por data
                const orders = [];
                snapshot.forEach(doc => {
                    const data = doc.data();
                    orders.push({ id: doc.id, ...data });
                });
                
                orders.sort((a, b) => {
                    const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt || 0);
                    const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt || 0);
                    return dateB - dateA;
                });
                
                // Função auxiliar para obter nome do item/evento
                const getItemName = (order) => {
                  // Se tiver eventType, mapear para nome legível
                  if (order.eventType) {
                    const eventMap = {
                      'modo-liga': 'Modo Liga',
                      'xtreino-tokens': 'XTreino Tokens',
                      'xtreino': 'XTreino Tokens',
                      'semanal-freitas': 'Semanal Freitas',
                      'semanal': 'Semanal Freitas',
                      'camp-freitas': 'Camp Freitas',
                      'camp': 'Camp Freitas'
                    };
                    return eventMap[order.eventType.toLowerCase()] || order.eventType;
                  }
                  // Tentar outros campos
                  return order.title || order.item || order.productName || 'Item não informado';
                };
                
                orders.forEach(order => {
                    const row = document.createElement('tr');
                    const nameDisplay = order.customerName || order.name || order.customer || '-';
                    const contactDisplay = order.phone || order.contact || '-';
                    const teamDisplay = order.teamName || order.team || '-';
                    const emailDisplay = order.buyerEmail || order.customer || '-';
                    row.innerHTML = `
                        <td class="py-2 text-sm"><strong>${nameDisplay}</strong></td>
                        <td class="py-2 text-sm">${contactDisplay}</td>
                        <td class="py-2 text-sm">${teamDisplay}</td>
                        <td class="py-2 text-sm">${emailDisplay}</td>
                        <td class="py-2 text-sm">${getItemName(order)}</td>
                    `;
                    confirmedTbody.appendChild(row);
                });
            }
        }
        
        if (confirmedCount) {
            confirmedCount.textContent = `${snapshot.size} pedidos`;
        }
        
    } catch (error) {
        console.error('Erro ao carregar pedidos confirmados:', error);
    }
}

// Função para carregar pedidos pendentes
async function loadPendingOrders() {
    try {
        const { collection, getDocs, query, where, orderBy, limit } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        
        // Buscar pedidos com status 'pending' - sem orderBy para evitar erro de índice
        const ordersRef = collection(window.firebaseDb, 'orders');
        const q = query(
            ordersRef,
            where('status', '==', 'pending'),
            limit(50)
        );
        
        const snapshot = await getDocs(q);
        const pendingTbody = document.getElementById('pendingTbody');
        const pendingCount = document.getElementById('pendingCount');
        
        if (pendingTbody) {
            pendingTbody.innerHTML = '';
            
            if (snapshot.empty) {
                pendingTbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-gray-500">Nenhum pedido pendente encontrado</td></tr>';
            } else {
                // Ordenar manualmente por data
                const orders = [];
                snapshot.forEach(doc => {
                    const data = doc.data();
                    orders.push({ id: doc.id, ...data });
                });
                
                orders.sort((a, b) => {
                    const dateA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt || 0);
                    const dateB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt || 0);
                    return dateB - dateA;
                });
                
                // Função auxiliar para obter nome do item/evento
                const getItemName = (order) => {
                  // Se tiver eventType, mapear para nome legível
                  if (order.eventType) {
                    const eventMap = {
                      'modo-liga': 'Modo Liga',
                      'xtreino-tokens': 'XTreino Tokens',
                      'xtreino': 'XTreino Tokens',
                      'semanal-freitas': 'Semanal Freitas',
                      'semanal': 'Semanal Freitas',
                      'camp-freitas': 'Camp Freitas',
                      'camp': 'Camp Freitas'
                    };
                    return eventMap[order.eventType.toLowerCase()] || order.eventType;
                  }
                  // Tentar outros campos
                  return order.title || order.item || order.productName || 'Item não informado';
                };
                
                orders.forEach(order => {
                    const row = document.createElement('tr');
                    const nameDisplay = order.customerName || order.name || order.customer || '-';
                    const contactDisplay = order.phone || order.contact || '-';
                    const teamDisplay = order.teamName || order.team || '-';
                    const emailDisplay = order.buyerEmail || order.customer || '-';
                    row.innerHTML = `
                        <td class="py-2 text-sm"><strong>${nameDisplay}</strong></td>
                        <td class="py-2 text-sm">${contactDisplay}</td>
                        <td class="py-2 text-sm">${teamDisplay}</td>
                        <td class="py-2 text-sm">${emailDisplay}</td>
                        <td class="py-2 text-sm">${getItemName(order)}</td>
                        <td class="py-2 text-sm">
                            <button onclick="approveOrder('${order.id}')" class="text-green-600 hover:text-green-800 text-xs">Aprovar</button>
                        </td>
                    `;
                    pendingTbody.appendChild(row);
                });
            }
        }
        
        if (pendingCount) {
            pendingCount.textContent = `${snapshot.size} pedidos`;
        }
        
    } catch (error) {
        console.error('Erro ao carregar pedidos pendentes:', error);
    }
}

// Função para aprovar pedido
async function approveOrder(orderId) {
    try {
        const { doc, updateDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const orderRef = doc(window.firebaseDb, 'orders', orderId);
        await updateDoc(orderRef, { status: 'approved' });
        
        alert('Pedido aprovado com sucesso!');
        
        // Recarregar as listas
        await loadPendingOrders();
        await loadConfirmedOrders();
        
    } catch (error) {
        console.error('Erro ao aprovar pedido:', error);
        alert('Erro ao aprovar pedido');
    }
}
// Função para dar tokens a um usuário
async function giveTokensToUser(userEmail, tokenAmount) {
    try {
        const { collection, getDocs, query, where, doc, updateDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        
        // Buscar usuário por email
        const usersRef = collection(window.firebaseDb, 'users');
        const q = query(usersRef, where('email', '==', userEmail));
        const snapshot = await getDocs(q);
        
        if (snapshot.empty) {
            alert('Usuário não encontrado com este email');
            return;
        }
        
        const userDoc = snapshot.docs[0];
        const userData = userDoc.data();
        const currentTokens = userData.tokens || 0;
        const newTokens = currentTokens + tokenAmount;
        
        // Atualizar tokens do usuário
        await updateDoc(doc(window.firebaseDb, 'users', userDoc.id), {
            tokens: newTokens
        });
        
        alert(`✅ ${tokenAmount} token(s) adicionado(s) ao usuário ${userEmail}. Novo saldo: ${newTokens} tokens`);
        
    } catch (error) {
        console.error('Erro ao dar tokens:', error);
        alert('Erro ao dar tokens ao usuário');
    }
}


// ===== GERENCIAMENTO DE DESTAQUES =====

let highlightsData = {};
let highlightCounter = 1;

// ===== GERENCIAMENTO DE NOTÍCIAS =====

let newsData = {};
let newsCounter = 1;

// Carregar destaques do Firestore
async function loadHighlights() {
    try {
        const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const highlightsRef = collection(window.firebaseDb, 'highlights');
        const snapshot = await getDocs(highlightsRef);
        
        highlightsData = {};
        snapshot.forEach(doc => {
            highlightsData[doc.id] = doc.data();
        });
        
        // Se não existem destaques, criar os padrão
        if (Object.keys(highlightsData).length === 0) {
            highlightsData = {
                highlight1: {
                    title: 'Modo Liga - Estratégia',
                    subtitle: 'Treinos competitivos',
                    description: 'Treinos competitivos com pontuação e ranking.',
                    image: '',
                    action: "openPurchaseModal('estrategia')",
                    hasRedirect: false,
                    redirectUrl: ''
                },
                highlight2: {
                    title: 'Campeonato Semanal',
                    subtitle: 'Etapas semanais',
                    description: 'Etapas semanais com premiações.',
                    image: '',
                    action: "openPurchaseModal('planilhas')",
                    hasRedirect: false,
                    redirectUrl: ''
                },
                highlight3: {
                    title: 'Camp de Fases',
                    subtitle: 'Eliminatórias',
                    description: 'Eliminatórias com melhores confrontos.',
                    image: '',
                    action: "openPurchaseModal('camp-fases')",
                    hasRedirect: false,
                    redirectUrl: ''
                }
            };
            
            // Salvar destaques padrão
            const { setDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            for (const [id, data] of Object.entries(highlightsData)) {
                await setDoc(doc(window.firebaseDb, 'highlights', id), data);
            }
        }
        
        // Atualizar preview
        updateHighlightsPreview(highlightsData);
        
        return highlightsData;
    } catch (error) {
        console.error('Erro ao carregar destaques:', error);
        return {};
    }
}

// Atualizar preview dos destaques
function updateHighlightsPreview(highlights) {
    const preview = document.getElementById('highlightsPreview');
    if (!preview) return;
    
    preview.innerHTML = '';
    
    Object.keys(highlights).forEach((key, index) => {
        const highlight = highlights[key];
        if (highlight) {
            const div = document.createElement('div');
            div.className = 'border border-gray-200 rounded-lg p-3';
            div.innerHTML = `
                <div class="flex items-center justify-between mb-2">
                    <h4 class="font-semibold text-sm">Destaque ${index + 1}</h4>
                    <span class="text-xs text-gray-500">${highlight.title}</span>
                </div>
                <p class="text-xs text-gray-600 mb-1">${highlight.subtitle}</p>
                <p class="text-xs text-gray-500">${highlight.description}</p>
                ${highlight.hasRedirect ? `<p class="text-xs text-blue-600 mt-1"><i class="fas fa-link mr-1"></i>Redireciona para: ${highlight.redirectUrl}</p>` : ''}
            `;
            preview.appendChild(div);
        }
    });
}

// Abrir modal de edição
function openHighlightsModal() {
    const modal = document.getElementById('modalHighlights');
    if (!modal) return;
    
    modal.classList.remove('hidden');
    
    // Carregar dados atuais e renderizar formulários
    loadHighlights().then(() => {
        renderHighlightsForm();
    });
}

// Renderizar formulário de destaques
function renderHighlightsForm() {
    const container = document.getElementById('highlightsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    Object.keys(highlightsData).forEach((key, index) => {
        const highlight = highlightsData[key];
        const highlightDiv = createHighlightForm(key, highlight, index + 1);
        container.appendChild(highlightDiv);
    });
}

// Criar formulário para um destaque
function createHighlightForm(key, highlight, index) {
    const div = document.createElement('div');
    div.className = 'border border-gray-200 rounded-lg p-4';
    div.innerHTML = `
        <div class="flex items-center justify-between mb-4">
            <h4 class="font-semibold text-lg">Destaque ${index}</h4>
            <button onclick="removeHighlight('${key}')" class="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700">
                <i class="fas fa-trash mr-1"></i>Remover
            </button>
        </div>
        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-2">Título</label>
                <input id="${key}Title" type="text" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="Ex: Modo Liga - Estratégia" value="${highlight.title || ''}">
            </div>
            <div>
                <label class="block text-sm font-medium mb-2">Subtítulo</label>
                <input id="${key}Subtitle" type="text" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="Ex: Treinos competitivos" value="${highlight.subtitle || ''}">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-2">Descrição</label>
                <textarea id="${key}Description" class="w-full border border-gray-300 rounded-lg px-3 py-2" rows="2" placeholder="Ex: Treinos competitivos com pontuação e ranking.">${highlight.description || ''}</textarea>
            </div>
            <div>
                <label class="block text-sm font-medium mb-2">URL da Imagem</label>
                <input id="${key}Image" type="url" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="https://exemplo.com/imagem.jpg" value="${highlight.image || ''}">
            </div>
            <div>
                <label class="block text-sm font-medium mb-2">Ação do Botão</label>
                <select id="${key}Action" class="w-full border border-gray-300 rounded-lg px-3 py-2" onchange="toggleCustomLinkField('${key}')">
                    <option value="openPurchaseModal('estrategia')" ${highlight.action === "openPurchaseModal('estrategia')" ? 'selected' : ''}>Abrir Modal de Compra</option>
                    <option value="buy_tokens" ${highlight.action === 'buy_tokens' ? 'selected' : ''}>Abrir Modal de Tokens</option>
                    <option value="scrollToSection('xtreinos')" ${highlight.action === "scrollToSection('xtreinos')" ? 'selected' : ''}>Ir para XTreinos</option>
                    <option value="scrollToSection('loja')" ${highlight.action === "scrollToSection('loja')" ? 'selected' : ''}>Ir para Loja</option>
                    <option value="openScheduleModal('modo-liga')" ${highlight.action === "openScheduleModal('modo-liga')" ? 'selected' : ''}>Abrir Agendamento</option>
                    <option value="openScheduleModal('semanal-freitas')" ${highlight.action === "openScheduleModal('semanal-freitas')" ? 'selected' : ''}>Abrir Agendamento Semanal</option>
                    <option value="openScheduleModal('camp-freitas')" ${highlight.action === "openScheduleModal('camp-freitas')" ? 'selected' : ''}>Abrir Agendamento Camp</option>
                    <option value="custom_link" ${highlight.action === "custom_link" ? 'selected' : ''}>Ir para Link</option>
                </select>
            </div>
            <div id="${key}CustomLinkField" class="mt-3 ${highlight.action === 'custom_link' ? '' : 'hidden'}">
                <label class="block text-sm font-medium mb-2">URL do Link</label>
                <input id="${key}CustomLinkUrl" type="url" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="https://exemplo.com" value="${highlight.customLinkUrl || ''}">
            </div>
            <div class="md:col-span-2">
                <div class="flex items-center gap-3">
                    <label class="flex items-center">
                        <input id="${key}HasRedirect" type="checkbox" class="mr-2" ${highlight.hasRedirect ? 'checked' : ''} onchange="toggleRedirectField('${key}')">
                        <span class="text-sm font-medium">Imagem com link de redirecionamento</span>
                    </label>
                </div>
                <div id="${key}RedirectField" class="mt-3 ${highlight.hasRedirect ? '' : 'hidden'}">
                    <label class="block text-sm font-medium mb-2">URL de Redirecionamento</label>
                    <input id="${key}RedirectUrl" type="url" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="https://exemplo.com" value="${highlight.redirectUrl || ''}">
                </div>
            </div>
        </div>
    `;
    return div;
}

// Fechar modal
function closeHighlightsModal() {
    const modal = document.getElementById('modalHighlights');
    if (modal) modal.classList.add('hidden');
}

// Adicionar novo destaque
function addHighlight() {
    const newKey = `highlight${Date.now()}`;
    const newHighlight = {
        title: '',
        subtitle: '',
        description: '',
        image: '',
        action: "openPurchaseModal('estrategia')",
        hasRedirect: false,
        redirectUrl: ''
    };
    
    highlightsData[newKey] = newHighlight;
    renderHighlightsForm();
}

// Remover destaque
function removeHighlight(key) {
    if (Object.keys(highlightsData).length <= 1) {
        alert('❌ Deve haver pelo menos um destaque!');
        return;
    }
    
    if (confirm('Tem certeza que deseja remover este destaque?')) {
        delete highlightsData[key];
        renderHighlightsForm();
    }
}

// Toggle campo de redirecionamento
function toggleRedirectField(key) {
    const checkbox = document.getElementById(`${key}HasRedirect`);
    const field = document.getElementById(`${key}RedirectField`);
    
    if (checkbox.checked) {
        field.classList.remove('hidden');
    } else {
        field.classList.add('hidden');
    }
}

// Toggle campo de link personalizado
function toggleCustomLinkField(key) {
    const select = document.getElementById(`${key}Action`);
    const field = document.getElementById(`${key}CustomLinkField`);
    
    if (select.value === 'custom_link') {
        field.classList.remove('hidden');
    } else {
        field.classList.add('hidden');
    }
}

// Salvar destaques
async function saveHighlights() {
    try {
        // Coletar dados dos formulários
        const highlights = {};
        
        Object.keys(highlightsData).forEach(key => {
            const title = document.getElementById(`${key}Title`)?.value.trim();
            const subtitle = document.getElementById(`${key}Subtitle`)?.value.trim();
            const description = document.getElementById(`${key}Description`)?.value.trim();
            const image = document.getElementById(`${key}Image`)?.value.trim();
            const action = document.getElementById(`${key}Action`)?.value;
            const hasRedirect = document.getElementById(`${key}HasRedirect`)?.checked || false;
            const redirectUrl = document.getElementById(`${key}RedirectUrl`)?.value.trim() || '';
            const customLinkUrl = document.getElementById(`${key}CustomLinkUrl`)?.value.trim() || '';
            
            if (title) { // Só salvar se tiver título
                highlights[key] = {
                    title,
                    subtitle,
                    description,
                    image,
                    action,
                    hasRedirect,
                    redirectUrl,
                    customLinkUrl,
                    updatedAt: new Date().toISOString()
                };
            }
        });
        
        // Limpar coleção atual
        const { collection, getDocs, deleteDoc, setDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const highlightsRef = collection(window.firebaseDb, 'highlights');
        const snapshot = await getDocs(highlightsRef);
        snapshot.forEach(doc => {
            deleteDoc(doc.ref);
        });
        
        // Salvar novos destaques
        for (const [id, data] of Object.entries(highlights)) {
            await setDoc(doc(window.firebaseDb, 'highlights', id), data);
        }
        
        // Atualizar dados locais
        highlightsData = highlights;
        
        // Atualizar preview
        updateHighlightsPreview(highlights);
        
        // Fechar modal
        closeHighlightsModal();
        
        alert('✅ Destaques salvos com sucesso!');
        
    } catch (error) {
        console.error('Erro ao salvar destaques:', error);
        alert('❌ Erro ao salvar destaques');
    }
}
// Tornar funções globais
window.approveOrder = approveOrder;
window.openHighlightsModal = openHighlightsModal;
window.closeHighlightsModal = closeHighlightsModal;
window.saveHighlights = saveHighlights;
window.addHighlight = addHighlight;
window.removeHighlight = removeHighlight;
window.toggleRedirectField = toggleRedirectField;
window.toggleCustomLinkField = toggleCustomLinkField;

// ===== FUNÇÕES DE NOTÍCIAS =====

// Carregar notícias do Firestore
async function loadNews() {
    try {
        const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const newsRef = collection(window.firebaseDb, 'news');
        const snapshot = await getDocs(newsRef);
        
        newsData = {};
        snapshot.forEach(doc => {
            newsData[doc.id] = doc.data();
        });
        
        // Se não existem notícias, criar as padrão
        if (Object.keys(newsData).length === 0) {
            newsData = {
                news1: {
                    title: 'Evento: Treinos Modo Liga Especial',
                    content: 'Vagas limitadas às 19h e 21h. Garanta sua inscrição.',
                    image: '',
                    date: new Date().toISOString(),
                    author: 'Equipe XTreino'
                },
                news2: {
                    title: 'Pausa em feriado',
                    content: 'Sem atividades nos dias 24 e 25. Retorno do semanal na semana seguinte.',
                    image: '',
                    date: new Date().toISOString(),
                    author: 'Equipe XTreino'
                },
                news3: {
                    title: 'Convidado verificado no próximo camp',
                    content: 'Participação especial em nosso campeonato de fases.',
                    image: '',
                    date: new Date().toISOString(),
                    author: 'Equipe XTreino'
                }
            };
            
            // Salvar notícias padrão
            const { setDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            for (const [id, data] of Object.entries(newsData)) {
                await setDoc(doc(window.firebaseDb, 'news', id), data);
            }
        }
        
        // Atualizar preview
        updateNewsPreview(newsData);
        
        return newsData;
    } catch (error) {
        console.error('Erro ao carregar notícias:', error);
        return {};
    }
}

// Atualizar preview das notícias
function updateNewsPreview(news) {
    const preview = document.getElementById('newsPreview');
    if (!preview) return;
    
    preview.innerHTML = '';
    
    Object.keys(news).forEach((key, index) => {
        const newsItem = news[key];
        if (newsItem) {
            const div = document.createElement('div');
            div.className = 'border border-gray-200 rounded-lg p-3';
            div.innerHTML = `
                <div class="flex items-center justify-between mb-2">
                    <h4 class="font-semibold text-sm">Notícia ${index + 1}</h4>
                    <span class="text-xs text-gray-500">${newsItem.title}</span>
                </div>
                <p class="text-xs text-gray-600 mb-1">${newsItem.content}</p>
                <p class="text-xs text-gray-500">Por: ${newsItem.author}</p>
            `;
            preview.appendChild(div);
        }
    });
}

// Abrir modal de edição de notícias
function openNewsModal() {
    const modal = document.getElementById('modalNews');
    if (!modal) return;
    
    modal.classList.remove('hidden');
    
    // Carregar dados atuais e renderizar formulários
    loadNews().then(() => {
        renderNewsForm();
    });
}

// Renderizar formulário de notícias
function renderNewsForm() {
    const container = document.getElementById('newsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    Object.keys(newsData).forEach((key, index) => {
        const newsItem = newsData[key];
        const newsDiv = createNewsForm(key, newsItem, index + 1);
        container.appendChild(newsDiv);
    });
}

// Criar formulário para uma notícia
function createNewsForm(key, newsItem, index) {
    const div = document.createElement('div');
    div.className = 'border border-gray-200 rounded-lg p-4';
    div.innerHTML = `
        <div class="flex items-center justify-between mb-4">
            <h4 class="font-semibold text-lg">Notícia ${index}</h4>
            <button onclick="removeNews('${key}')" class="px-3 py-1 bg-red-600 text-white rounded text-sm hover:bg-red-700">
                <i class="fas fa-trash mr-1"></i>Remover
            </button>
        </div>
        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-2">Título</label>
                <input id="${key}Title" type="text" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="Ex: Novo Sistema de Tokens" value="${newsItem.title || ''}">
            </div>
            <div>
                <label class="block text-sm font-medium mb-2">Autor</label>
                <input id="${key}Author" type="text" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="Ex: Equipe XTreino" value="${newsItem.author || ''}">
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium mb-2">Conteúdo</label>
                <textarea id="${key}Content" class="w-full border border-gray-300 rounded-lg px-3 py-2" rows="3" placeholder="Ex: Agora você pode comprar tokens e usar para participar dos XTreinos!">${newsItem.content || ''}</textarea>
            </div>
            <div>
                <label class="block text-sm font-medium mb-2">URL da Imagem</label>
                <input id="${key}Image" type="url" class="w-full border border-gray-300 rounded-lg px-3 py-2" placeholder="https://exemplo.com/imagem.jpg" value="${newsItem.image || ''}">
            </div>
            <div>
                <label class="block text-sm font-medium mb-2">Data</label>
                <input id="${key}Date" type="datetime-local" class="w-full border border-gray-300 rounded-lg px-3 py-2" value="${newsItem.date ? new Date(newsItem.date).toISOString().slice(0, 16) : ''}">
            </div>
        </div>
    `;
    return div;
}

// Fechar modal de notícias
function closeNewsModal() {
    const modal = document.getElementById('modalNews');
    if (modal) modal.classList.add('hidden');
}

// Adicionar nova notícia
function addNews() {
    const newKey = `news${Date.now()}`;
    const newNews = {
        title: '',
        content: '',
        image: '',
        date: new Date().toISOString(),
        author: 'Equipe XTreino'
    };
    
    newsData[newKey] = newNews;
    renderNewsForm();
}

// Remover notícia
function removeNews(key) {
    if (Object.keys(newsData).length <= 1) {
        alert('❌ Deve haver pelo menos uma notícia!');
        return;
    }
    
    if (confirm('Tem certeza que deseja remover esta notícia?')) {
        delete newsData[key];
        renderNewsForm();
    }
}

// Salvar notícias
async function saveNews() {
    try {
        // Coletar dados dos formulários
        const news = {};
        
        Object.keys(newsData).forEach(key => {
            const title = document.getElementById(`${key}Title`)?.value.trim();
            const content = document.getElementById(`${key}Content`)?.value.trim();
            const image = document.getElementById(`${key}Image`)?.value.trim();
            const author = document.getElementById(`${key}Author`)?.value.trim();
            const date = document.getElementById(`${key}Date`)?.value;
            
            if (title && content) { // Só salvar se tiver título e conteúdo
                news[key] = {
                    title,
                    content,
                    image,
                    author: author || 'Equipe XTreino',
                    date: date ? new Date(date).toISOString() : new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
            }
        });
        
        // Limpar coleção atual
        const { collection, getDocs, deleteDoc, setDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const newsRef = collection(window.firebaseDb, 'news');
        const snapshot = await getDocs(newsRef);
        snapshot.forEach(doc => {
            deleteDoc(doc.ref);
        });
        
        // Salvar novas notícias
        for (const [id, data] of Object.entries(news)) {
            await setDoc(doc(window.firebaseDb, 'news', id), data);
        }
        
        // Atualizar dados locais
        newsData = news;
        
        // Atualizar preview
        updateNewsPreview(news);
        
        // Fechar modal
        closeNewsModal();
        
        alert('✅ Notícias salvas com sucesso!');
        
    } catch (error) {
        console.error('Erro ao salvar notícias:', error);
        alert('❌ Erro ao salvar notícias');
    }
}

// Tornar funções globais
window.openNewsModal = openNewsModal;
window.closeNewsModal = closeNewsModal;
window.saveNews = saveNews;
window.addNews = addNews;
window.removeNews = removeNews;

// Carregar destaques quando o admin estiver pronto
window.addEventListener('load', () => {
    setTimeout(() => {
        if (window.firebaseDb && document.getElementById('highlightsPreview')) {
            loadHighlights();
        }
        if (window.firebaseDb && document.getElementById('newsPreview')) {
            loadNews();
        }
    }, 2000);
});

  // Security: Enhanced authentication system
  async function initAuth() {
    // Check for existing session
    const savedSession = sessionStorage.getItem('adminSession');
    if (savedSession) {
      try {
        const sessionData = JSON.parse(savedSession);
        const SESSION_TIMEOUT_LOCAL = 30 * 60 * 1000; // 30 minutes
        if (Date.now() - sessionData.timestamp < SESSION_TIMEOUT_LOCAL) {
          // Session still valid, check with Firebase
          const user = window.firebaseAuth?.currentUser;
          if (user && await isAuthorizedAdmin(user)) {
            // Buscar role do Firestore, não usar user.role que pode não existir
            try {
              const { doc, getDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
              const userRef = doc(collection(window.firebaseDb, 'users'), user.uid);
              const userSnap = await getDoc(userRef);
              const userRole = userSnap.exists() ? (userSnap.data().role || 'admin') : 'admin';
              showDashboard(userRole);
            } catch (err) {
              console.error('Erro ao buscar role:', err);
              showDashboard('admin');
            }
            return;
          }
        }
      } catch (error) {
        console.error('Session validation error:', error);
      }
      // Clear invalid session
      sessionStorage.removeItem('adminSession');
    }

    // Show login form
    showAuthGate();
  }

  // Security: Enhanced login handler
  async function handleLogin(email, password) {
    try {
      
      const { signInWithEmailAndPassword: signIn, signOut: signOutFn } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js');
      const { doc: docRef, getDoc: getDocFn } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            
      const userCredential = await signIn(window.firebaseAuth, email, password);
      const user = userCredential.user;     

      // Check if user is authorized
      if (!user || !user.email) {
        await signOutFn(window.firebaseAuth);
        showLoginError('Erro ao fazer login.');
        return;
      }

      const userDoc = await getDocFn(docRef(window.firebaseDb, 'users', user.uid));     
      
      if (!userDoc.exists()) {              
        // Criar documento do usuário automaticamente
        const { setDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const userData = {
          email: user.email,
          displayName: user.displayName || user.email.split('@')[0],
          role: 'socio', // Definir como socio por padrão
          createdAt: new Date(),
          lastLogin: Date.now()
        };
        
        await setDoc(docRef(window.firebaseDb, 'users', user.uid), userData);       
        
        // Agora tentar novamente
        const newUserDoc = await getDocFn(docRef(window.firebaseDb, 'users', user.uid));
        if (!newUserDoc.exists()) {
          await signOutFn(window.firebaseAuth);
          showLoginError('Erro ao criar documento do usuário.');
          return;
        }
        
        const newUserData = newUserDoc.data();
        const role = (newUserData.role || '').toLowerCase().trim();        
        
        // Continuar com o processo de login
        const authorizedRoles = ['admin', 'ceo', 'gerente', 'vendedor', 'design', 'designer', 'desgin', 'socio', 'sócio'];
        const isAuthorized = authorizedRoles.includes(role);
        
        if (!isAuthorized) {
          await signOutFn(window.firebaseAuth);
          showLoginError('Acesso negado. Você não tem permissão para acessar o painel administrativo.');
          return;
        }
        
        // Para socio/ceo, permitir qualquer email
        if (role === 'socio' || role === 'sócio' || role === 'ceo') {   
          
          // Save session
          const sessionData = {
            uid: user.uid,
            email: user.email,
            role: role,
            timestamp: Date.now()
          };
          sessionStorage.setItem('adminSession', JSON.stringify(sessionData));

          // Mostrar dashboard diretamente
          const authGate = document.getElementById('authGate');
          const dashboard = document.getElementById('dashboard');
          if (authGate && dashboard) {
            authGate.classList.add('hidden');
            dashboard.classList.remove('hidden');

            // Inicializar dashboard
            setTimeout(() => {
              if (typeof setView === 'function') {
                setView(role);
              }
              if (typeof startSessionTimer === 'function') {
                startSessionTimer();
              }
            }, 100);
          }
          return;
        }
        
        await signOutFn(window.firebaseAuth);
        showLoginError('Acesso negado. Você não tem permissão para acessar o painel administrativo.');
        return;
      }
      
      const userData = userDoc.data();
      const role = (userData.role || '').toLowerCase();
      
      // Limpar espaços em branco e caracteres especiais do cargo
      const cleanRole = role.trim();     
      
      // Check if role is authorized (including variations and typos)
      const authorizedRoles = ['admin', 'ceo', 'gerente', 'vendedor', 'design', 'designer', 'desgin', 'socio', 'sócio'];
      const isAuthorized = authorizedRoles.includes(cleanRole);
            
      if (!isAuthorized) {        
        await signOutFn(window.firebaseAuth);
        showLoginError('Acesso negado. Você não tem permissão para acessar o painel administrativo.');
        return;
      }      
    
      // Gerente/design/socio/ceo não precisam estar na whitelist - apenas precisam ter o role correto
      if (['admin', 'vendedor'].includes(cleanRole)) {
        
        const ADMIN_EMAILS = [
          'cleitondouglass@gmail.com',
          'cleitondouglass123@hotmail.com',
          'gilmariofreitas378@gmail.com',
          'gilmariofreitas387@gmail.com',
          'flavetyr@gmail.com',
          'admin@xtreino.dev'
        ];                
        
        if (!ADMIN_EMAILS.includes(user.email.toLowerCase())) {
          
          await signOutFn(window.firebaseAuth);
          showLoginError('Acesso negado. Email não autorizado para administração.');
          return;
        }               
      } 

      const sessionData = {
        uid: user.uid,
        email: user.email,
        role: cleanRole,
        timestamp: Date.now()
      };
      sessionStorage.setItem('adminSession', JSON.stringify(sessionData));     

      // Show dashboard      
      if (typeof showDashboard === 'function') {        
        showDashboard(role);
      } else {
        
        // Fallback: mostrar dashboard manualmente
        const authGate = document.getElementById('authGate');
        const dashboard = document.getElementById('dashboard');       
        
        if (authGate && dashboard) {
          authGate.classList.add('hidden');
          dashboard.classList.remove('hidden');          
          
          if (typeof setView === 'function') {
            setView(cleanRole);
          }
          if (typeof startSessionTimer === 'function') {
            startSessionTimer();
          }
        } else {
          console.error('❌ Elementos authGate ou dashboard não encontrados');
        }
      }
      
    } catch (error) {
      console.error('Login error:', error);
      let errorMessage = 'Erro ao fazer login.';
      
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'Usuário não encontrado.';
      } else if (error.code === 'auth/wrong-password') {
        errorMessage = 'Senha incorreta.';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Email inválido.';
      } else if (error.code === 'auth/too-many-requests') {
        errorMessage = 'Muitas tentativas. Tente novamente mais tarde.';
      }

      showLoginError(errorMessage);
    }
  }

  // Security: Setup event listeners
  function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('emailLoginForm');
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('adminEmail').value;
        const password = document.getElementById('adminPassword').value;
        
        if (!email || !password) {
          showLoginError('Por favor, preencha todos os campos.');
          return;
        }
        
        await handleLogin(email, password);
      });
    }

    // Logout button
    const logoutBtn = document.getElementById('btnLogout');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', logout);
    }

    // Reset session timer on user activity
    document.addEventListener('click', resetSessionTimer);
    document.addEventListener('keypress', resetSessionTimer);
    document.addEventListener('scroll', resetSessionTimer);
  }

  // Session timer fallbacks (no-op to avoid runtime errors)
  function startSessionTimer() {}
  function resetSessionTimer() {}

  // Auth gate helper (fallback)
  function showAuthGate() {
    try {
      const authGate = document.getElementById('authGate');
      const dashboard = document.getElementById('dashboard');
      if (authGate) authGate.classList.remove('hidden');
      if (dashboard) dashboard.classList.add('hidden');
    } catch(_) { /* noop */ }
  }

  // Basic login error renderer (fallback-safe)
  function showLoginError(message) {
    try {
      const box = document.getElementById('loginError');
      if (box) {
        box.textContent = message || 'Erro ao fazer login';
        box.classList.remove('hidden');
      } else {
        console.error('Login error:', message);
      }
    } catch (e) {
      console.error('Login error (fallback):', message, e);
    }
  }

  // Logout handler
  async function logout() {
    try {
      if (window.firebaseAuth && typeof window.firebaseAuth.signOut === 'function') {
        await window.firebaseAuth.signOut();
      }
      sessionStorage.removeItem('adminSession');
      location.reload();
    } catch (e) {
      console.error('Logout error:', e);
    }
  }
  // Initialize admin panel
  async function initAdmin() {
    try {
      setupEventListeners();
      await initAuth();
      
      // Load products if dashboard is visible
      setTimeout(() => {
        if (window.firebaseDb && document.getElementById('productsPreview') && !dashboard.classList.contains('hidden')) {
          loadProducts();
        }
      }, 2000);

      // Load Passe Booyah controls
      setTimeout(() => {
        if (window.firebaseDb && document.getElementById('booyahTbody')) {
          try { loadPasseBooyahControls(); } catch (_) {}
        }
      }, 2500);
      
      // Recomputar totais de tokens (evita contagens duplicadas)
      setTimeout(() => {
        if (window.firebaseDb) {
          try { recomputeTokenTotals(); } catch (_) {}
        }
      }, 2800);

      // Load users and setup guards
      setTimeout(() => {
        if (window.firebaseDb) {
          try {
            const roleLower = (window.adminRoleLower||'').toLowerCase();
            if (roleLower==='ceo' || roleLower==='gerente' || roleLower==='socio') {
              loadUsers();
            }
          } catch (_) {}
        }
        try { setupRoleGuards(); } catch (_) {}
      }, 800);
      
    } catch (error) {
      console.error('Admin initialization error:', error);
      showLoginError('Erro ao inicializar o painel administrativo.');
    }
  }

  // Função de teste para verificar permissões
  async function testFirestorePermissions() {
    try {
      
      const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
      
      // Testar leitura de usuários
      const usersRef = collection(window.firebaseDb, 'users');
      const usersSnapshot = await getDocs(usersRef);
      
      
      // Testar leitura de pedidos
      const ordersRef = collection(window.firebaseDb, 'orders');
      const ordersSnapshot = await getDocs(ordersRef);
      
      
      // Testar leitura de registros
      const regsRef = collection(window.firebaseDb, 'registrations');
      const regsSnapshot = await getDocs(regsRef);
      
      
      
      return true;
    } catch (error) {
      console.error('❌ Erro no teste de permissões:', error);
      return false;
    }
  }

  // Start admin panel
  initAdmin();
  
  // Testar permissões após inicialização
  setTimeout(() => {
    testFirestorePermissions();
  }, 2000);
  
  // Configurar filtros de usuários quando o DOM estiver pronto
  document.addEventListener('DOMContentLoaded', () => {
    setupUserFilters();
    try { setupRoleGuards(); } catch (_) {}
    // Configurar filtros de cupons quando DOM estiver pronto
    setupCouponUsageFilters();
  });

// ==================== FUNÇÕES DE USUÁRIOS ====================

// Variáveis para usuários
let allUsers = [];
let filteredUsers = [];
let usersCurrentPage = 1;
const usersPerPage = 10;
let currentUserFilter = 'all'; // 'all', '30days', '7days', '1day'

// Carregar usuários do Firestore
async function loadUsers() {
  try {
    
    const { collection, getDocs, query, orderBy, limit } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    // 1) Carrega usuários
    const usersRef = collection(window.firebaseDb, 'users');
    const snapshot = await getDocs(usersRef);
    
    allUsers = [];
    snapshot.forEach(doc => {
      const userData = doc.data();
      // Normaliza lastLogin para milissegundos
      let lastLoginMs = null;
      const ll = userData.lastLogin;
      if (ll) {
        if (typeof ll.toMillis === 'function') {
          lastLoginMs = ll.toMillis();
        } else if (typeof ll === 'number') {
          lastLoginMs = ll;
        } else if (typeof ll === 'object' && typeof ll.seconds === 'number') {
          lastLoginMs = ll.seconds * 1000;
        }
      }
      allUsers.push({
        id: doc.id,
        email: userData.email || 'N/A',
        role: userData.role || 'Usuário',
        lastLogin: lastLoginMs,
        name: userData.name || userData.email || 'Usuário',
        createdAt: userData.createdAt || null
      });
    });

    // 2) Usa atividade recente de pedidos como fallback de "último login"
    
    const ordersRef = collection(window.firebaseDb, 'orders');
    // Pega os mais recentes para manter leve
    const ordersSnap = await getDocs(query(ordersRef, orderBy('createdAt', 'desc'), limit(500)));
    const emailToLastActivity = new Map();
    ordersSnap.forEach(orderDoc => {
      const o = orderDoc.data() || {};
      const email = o.buyerEmail || o.customerEmail || o.customer || o.email;
      if (!email) return;
      let ts = null;
      const paid = o.paidAt || o.approvedAt || o.confirmedAt;
      const created = o.createdAt;
      const normalize = (v) => {
        if (!v) return null;
        if (typeof v.toMillis === 'function') return v.toMillis();
        if (typeof v === 'number') return v;
        if (typeof v === 'object' && typeof v.seconds === 'number') return v.seconds * 1000;
        return null;
      };
      ts = normalize(paid) || normalize(created);
      if (!ts) return;
      const prev = emailToLastActivity.get(email) || 0;
      if (ts > prev) emailToLastActivity.set(email, ts);
    });

    // 3) Mescla atividade aos usuários sem lastLogin
    allUsers = allUsers.map(u => {
      if (!u.lastLogin && emailToLastActivity.has(u.email)) {
        return { ...u, lastLogin: emailToLastActivity.get(u.email) };
      }
      return u;
    });
    
    
    applyUserFilter();
    updateUsersStats();
    displayUsers();
  } catch (error) {
    console.error('❌ Erro ao carregar usuários:', error);
  }
}

// Aplicar filtro de usuários
function applyUserFilter() {
  const now = Date.now();
  const oneDay = 24 * 60 * 60 * 1000;
  const sevenDays = 7 * oneDay;
  const thirtyDays = 30 * oneDay;
  
  filteredUsers = allUsers.filter(user => {
    if (currentUserFilter === 'all') return true;
    
    if (!user.lastLogin || isNaN(user.lastLogin)) return false;
    
    const lastLoginTime = user.lastLogin;
    const timeDiff = now - lastLoginTime;
    
    switch (currentUserFilter) {
      case '1day':
        return timeDiff <= oneDay;
      case '7days':
        return timeDiff <= sevenDays;
      case '30days':
        return timeDiff <= thirtyDays;
      default:
        return true;
    }
  });
  
  usersCurrentPage = 1; // Reset para primeira página
}

// Atualizar estatísticas de usuários
function updateUsersStats() {
  const totalUsers = allUsers.length;
  const now = Date.now();
  const thirtyDays = 30 * 24 * 60 * 60 * 1000;
  
  const activeUsers = allUsers.filter(user => {
    if (!user.lastLogin) return false;
    return (now - user.lastLogin) <= thirtyDays;
  }).length;
  
  const inactiveUsers = totalUsers - activeUsers;
  
  document.getElementById('totalUsers').textContent = totalUsers;
  document.getElementById('activeUsers').textContent = activeUsers;
  document.getElementById('inactiveUsers').textContent = inactiveUsers;
}

// Exibir usuários na tabela
function displayUsers() {
  const tbody = document.getElementById('recentUsersTableBody') || document.getElementById('usersTableBody');
  if (!tbody) return;
  
  const startIndex = (usersCurrentPage - 1) * usersPerPage;
  const endIndex = startIndex + usersPerPage;
  const pageUsers = filteredUsers.slice(startIndex, endIndex);
  
  if (pageUsers.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="4" class="py-6 text-center text-gray-500">
          ${currentUserFilter === 'all' ? 'Nenhum usuário encontrado' : 'Nenhum usuário ativo neste período'}
        </td>
      </tr>
    `;
  } else {
    tbody.innerHTML = pageUsers.map(user => {
      const lastLoginText = (user.lastLogin && !isNaN(user.lastLogin)) ? 
        new Date(user.lastLogin).toLocaleString('pt-BR') : 'Nunca';
      
      const statusClass = (user.lastLogin && !isNaN(user.lastLogin) && (Date.now() - user.lastLogin) <= (30 * 24 * 60 * 60 * 1000)) ? 
        'text-green-600' : 'text-orange-600';
      const statusText = (user.lastLogin && !isNaN(user.lastLogin) && (Date.now() - user.lastLogin) <= (30 * 24 * 60 * 60 * 1000)) ? 
        'Ativo' : 'Inativo';
      
      return `
        <tr class="border-b border-gray-100">
          <td class="py-2 px-2 text-gray-900">${user.email}</td>
          <td class="py-2 px-2 text-gray-600">${user.role}</td>
          <td class="py-2 px-2 text-gray-600">${lastLoginText}</td>
          <td class="py-2 px-2 ${statusClass}">${statusText}</td>
        </tr>
      `;
    }).join('');
  }
  
  updateUsersPagination();
  updateUsersCount();
}

// Atualizar paginação de usuários
function updateUsersPagination() {
  const paginationDiv = document.getElementById('usersPagination');
  if (!paginationDiv) return;
  
  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
  
  if (totalPages <= 1) {
    paginationDiv.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // Botão anterior
  if (usersCurrentPage > 1) {
    paginationHTML += `<button onclick="changeUsersPage(${usersCurrentPage - 1})" class="px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs hover:bg-gray-300">‹</button>`;
  }
  
  // Páginas
  for (let i = 1; i <= totalPages; i++) {
    if (i === usersCurrentPage) {
      paginationHTML += `<button class="px-2 py-1 bg-blue-matte text-white rounded text-xs">${i}</button>`;
    } else {
      paginationHTML += `<button onclick="changeUsersPage(${i})" class="px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs hover:bg-gray-300">${i}</button>`;
    }
  }
  
  // Botão próximo
  if (usersCurrentPage < totalPages) {
    paginationHTML += `<button onclick="changeUsersPage(${usersCurrentPage + 1})" class="px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs hover:bg-gray-300">›</button>`;
  }
  
  paginationDiv.innerHTML = paginationHTML;
}

// Mudar página de usuários
function changeUsersPage(page) {
  usersCurrentPage = page;
  displayUsers();
}

// Atualizar contador de usuários
function updateUsersCount() {
  const usersCount = document.getElementById('usersCount');
  const usersPageInfo = document.getElementById('usersPageInfo');
  
  if (usersCount) {
    usersCount.textContent = `${filteredUsers.length} usuários`;
  }
  
  if (usersPageInfo) {
    const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
    usersPageInfo.textContent = `Página ${usersCurrentPage} de ${totalPages}`;
  }
}
// Configurar filtros de usuários
function setupUserFilters() {
  const filterButtons = [
    { id: 'filterAllUsers', filter: 'all' },
    { id: 'filterActive30Days', filter: '30days' },
    { id: 'filterActive7Days', filter: '7days' },
    { id: 'filterActive1Day', filter: '1day' }
  ];
  
  filterButtons.forEach(({ id, filter }) => {
    const button = document.getElementById(id);
    if (button) {
      button.addEventListener('click', () => {
        // Atualizar botões ativos
        filterButtons.forEach(({ id: btnId }) => {
          const btn = document.getElementById(btnId);
          if (btn) {
            btn.className = btn.className.replace('bg-blue-matte text-white', 'bg-gray-200 text-gray-700');
          }
        });
        
        // Ativar botão atual
        button.className = button.className.replace('bg-gray-200 text-gray-700', 'bg-blue-matte text-white');
        
        // Aplicar filtro
        currentUserFilter = filter;
        applyUserFilter();
        displayUsers();
      });
    }
  });
}

// Expor funções globalmente
window.changeUsersPage = changeUsersPage;

// Inicializar sistema de filtros de horários populares
setTimeout(() => {
  if (document.getElementById('popularHoursChart')) {
    loadEventOptions();
    setupPopularHoursFilters();
    renderPopularHours();
  }
}, 1000);

// ==================== RESTRIÇÕES DE PAPÉIS ====================

function getCurrentAdminRole() {
  // Usa o papel mais confiável disponível no momento
  try {
    const fromWindow = (window.adminRoleLower || '').toString();
    if (fromWindow) return fromWindow;
  } catch(_) {}
  try {
    const session = JSON.parse(sessionStorage.getItem('adminSession') || '{}');
    if (session && session.role) return String(session.role);
  } catch(_) {}
  return undefined;
}

function canAssignRole(targetRole) {
  const role = (getCurrentAdminRole() || '').toLowerCase();
  const target = String(targetRole || '').toLowerCase();
  
  // CEO: pode atribuir qualquer cargo
  if (role === 'ceo') return true;
  
  // Gerente: pode atribuir apenas cargo de Vendedor
  if (role === 'gerente') {
    return target === 'vendedor';
  }
  
  // Outros cargos: não podem alterar funções de ninguém
  return false;
}

function setupRoleGuards() {
  const tables = [document.getElementById('usersTableBody'), document.getElementById('recentUsersTableBody')].filter(Boolean);
  tables.forEach((tbl) => {
    tbl.addEventListener('change', (e) => {
      const el = e.target;
      if (el && el.tagName === 'SELECT') {
        const newVal = el.value;
        if (!canAssignRole(newVal)) {
          e.preventDefault();
          // Reverter seleção
          const prev = el.getAttribute('data-prev') || '';
          if (prev) el.value = prev;
          alert('Gerente não pode definir cargo CEO.');
        } else {
          el.setAttribute('data-prev', newVal);
        }
      }
    });
  });
}

// Variáveis globais para filtros
let currentActiveFilter = 'all';
// allUsers já declarado na linha 3471

// Funções para gerenciar usuários (NOVA - para tabelas separadas)
let newTablesUsers = []; // Variável separada para as novas tabelas
let permissionsUsers = []; // Variável separada para a tabela de permissões
let filteredActiveUsers = []; // Usuários filtrados para a tabela de ativos
let activeUsersCurrentPage = 1; // Página atual da tabela de usuários ativos
const activeUsersPerPage = 10; // 10 usuários por página

async function loadUsersForTables() {
  try {
    const { getDocs, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const usersSnapshot = await getDocs(collection(window.firebaseDb, 'users'));
    const users = [];
    
    usersSnapshot.forEach(doc => {
      const userData = doc.data();
      users.push({
        id: doc.id,
        email: userData.email || 'N/A',
        role: userData.role || 'user',
        lastLogin: userData.lastLogin || null,
        createdAt: userData.createdAt || null
      });
    });
    
    // Armazenar usuários separadamente para cada tabela
    newTablesUsers = users; // Para Usuários Ativos
    permissionsUsers = users; // Para Usuários & Permissões (sempre todos os usuários)
    
    // Resetar paginação ao carregar
    activeUsersCurrentPage = 1;
    
    // Renderizar apenas a tabela de usuários ativos
    // A tabela de permissões é gerenciada separadamente por loadPermissionsUsers()
    renderActiveUsersTable(newTablesUsers); // Pode ser filtrado
    updateActiveUsersStats(newTablesUsers);
    
    // Adicionar event listeners para filtros (apenas para Usuários Ativos)
    setupFilterEventListeners();
  } catch (error) {
    console.error('Erro ao carregar usuários:', error);
  }
}

function setupFilterEventListeners() {
  const filterAll = document.getElementById('filterAllUsers');
  const filter30 = document.getElementById('filterActive30Days');
  const filter7 = document.getElementById('filterActive7Days');
  const filter1 = document.getElementById('filterActive1Day');
  
  if (filterAll) filterAll.onclick = () => filterActiveUsers('all');
  if (filter30) filter30.onclick = () => filterActiveUsers('30');
  if (filter7) filter7.onclick = () => filterActiveUsers('7');
  if (filter1) filter1.onclick = () => filterActiveUsers('1');
}

// Esta função não é mais usada - foi substituída por renderPermissionsTable
// Mantida apenas para compatibilidade, mas não deve ser chamada
function renderUsersTable(users) {
  
  // Não fazer nada - a tabela de permissões é gerenciada separadamente
}

function renderActiveUsersTable(users) {
  const tbody = document.getElementById('activeUsersTableBody');
  if (!tbody) return;
  
  // Salvar usuários filtrados
  filteredActiveUsers = users;
  
  // Calcular paginação
  const totalPages = Math.ceil(users.length / activeUsersPerPage);
  const startIndex = (activeUsersCurrentPage - 1) * activeUsersPerPage;
  const endIndex = startIndex + activeUsersPerPage;
  const pageUsers = users.slice(startIndex, endIndex);
  
  if (pageUsers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="py-6 text-center text-gray-500">Nenhum usuário encontrado</td></tr>';
    updateActiveUsersPagination(totalPages);
    updateActiveUsersCount();
    return;
  }
  
  tbody.innerHTML = pageUsers.map(user => {
    let lastLogin = 'Nunca';
    let isActive = false;
    
    if (user.lastLogin) {
      try {
        // Tentar diferentes formatos de data
        let date;
        if (user.lastLogin.seconds) {
          // Firestore Timestamp
          date = new Date(user.lastLogin.seconds * 1000);
        } else if (user.lastLogin.toDate) {
          // Firestore Timestamp com método toDate()
          date = user.lastLogin.toDate();
        } else if (typeof user.lastLogin === 'string') {
          // String ISO
          date = new Date(user.lastLogin);
        } else if (typeof user.lastLogin === 'number') {
          // Timestamp em milissegundos
          date = new Date(user.lastLogin);
        } else {
          date = new Date(user.lastLogin);
        }
        
        if (!isNaN(date.getTime())) {
          lastLogin = date.toLocaleDateString('pt-BR');
          isActive = (Date.now() - date.getTime()) < (7 * 24 * 60 * 60 * 1000);
        }
      } catch (error) {
        console.error('Erro ao processar data de login:', error);
        lastLogin = 'Erro';
      }
    }
    
    return `
      <tr class="border-b border-gray-100">
        <td class="py-2 px-2 text-gray-700">${user.email}</td>
        <td class="py-2 px-2">
          <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">${user.role}</span>
        </td>
        <td class="py-2 px-2 text-gray-600">${lastLogin}</td>
        <td class="py-2 px-2">
          <span class="px-2 py-1 rounded text-xs ${isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}">
            ${isActive ? 'Ativo' : 'Inativo'}
          </span>
        </td>
      </tr>
    `;
  }).join('');
  
  // Atualizar paginação e contadores
  updateActiveUsersPagination(totalPages);
  updateActiveUsersCount();
}

// Atualizar controles de paginação de usuários ativos
function updateActiveUsersPagination(totalPages) {
  const paginationDiv = document.getElementById('activeUsersPagination');
  const pageInfo = document.getElementById('activeUsersPageInfo');
  
  if (!paginationDiv) return;
  
  // Atualizar info da página
  if (pageInfo) {
    pageInfo.textContent = `Página ${activeUsersCurrentPage} de ${totalPages || 1}`;
  }
  
  // Limpar paginação anterior
  paginationDiv.innerHTML = '';
  
  if (totalPages <= 1) {
    return; // Não mostrar paginação se houver apenas 1 página
  }
  
  // Botão Anterior
  const prevBtn = document.createElement('button');
  prevBtn.textContent = '« Anterior';
  prevBtn.className = `px-3 py-1 text-xs rounded ${activeUsersCurrentPage === 1 ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`;
  prevBtn.disabled = activeUsersCurrentPage === 1;
  prevBtn.onclick = () => {
    if (activeUsersCurrentPage > 1) {
      activeUsersCurrentPage--;
      renderActiveUsersTable(filteredActiveUsers);
    }
  };
  paginationDiv.appendChild(prevBtn);
  
  // Números das páginas
  const maxVisiblePages = 5;
  let startPage = Math.max(1, activeUsersCurrentPage - Math.floor(maxVisiblePages / 2));
  let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
  
  if (endPage - startPage < maxVisiblePages - 1) {
    startPage = Math.max(1, endPage - maxVisiblePages + 1);
  }
  
  if (startPage > 1) {
    const firstBtn = document.createElement('button');
    firstBtn.textContent = '1';
    firstBtn.className = 'px-2 py-1 text-xs rounded bg-gray-200 text-gray-700 hover:bg-gray-300';
    firstBtn.onclick = () => {
      activeUsersCurrentPage = 1;
      renderActiveUsersTable(filteredActiveUsers);
    };
    paginationDiv.appendChild(firstBtn);
    
    if (startPage > 2) {
      const ellipsis = document.createElement('span');
      ellipsis.textContent = '...';
      ellipsis.className = 'px-2 py-1 text-xs text-gray-500';
      paginationDiv.appendChild(ellipsis);
    }
  }
  
  for (let i = startPage; i <= endPage; i++) {
    const pageBtn = document.createElement('button');
    pageBtn.textContent = i.toString();
    pageBtn.className = `px-2 py-1 text-xs rounded ${i === activeUsersCurrentPage ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`;
    pageBtn.onclick = () => {
      activeUsersCurrentPage = i;
      renderActiveUsersTable(filteredActiveUsers);
    };
    paginationDiv.appendChild(pageBtn);
  }
  
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      const ellipsis = document.createElement('span');
      ellipsis.textContent = '...';
      ellipsis.className = 'px-2 py-1 text-xs text-gray-500';
      paginationDiv.appendChild(ellipsis);
    }
    
    const lastBtn = document.createElement('button');
    lastBtn.textContent = totalPages.toString();
    lastBtn.className = 'px-2 py-1 text-xs rounded bg-gray-200 text-gray-700 hover:bg-gray-300';
    lastBtn.onclick = () => {
      activeUsersCurrentPage = totalPages;
      renderActiveUsersTable(filteredActiveUsers);
    };
    paginationDiv.appendChild(lastBtn);
  }
  
  // Botão Próximo
  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Próximo »';
  nextBtn.className = `px-3 py-1 text-xs rounded ${activeUsersCurrentPage === totalPages ? 'bg-gray-200 text-gray-400 cursor-not-allowed' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`;
  nextBtn.disabled = activeUsersCurrentPage === totalPages;
  nextBtn.onclick = () => {
    if (activeUsersCurrentPage < totalPages) {
      activeUsersCurrentPage++;
      renderActiveUsersTable(filteredActiveUsers);
    }
  };
  paginationDiv.appendChild(nextBtn);
}

// Atualizar contador de usuários ativos
function updateActiveUsersCount() {
  const countEl = document.getElementById('activeUsersCount');
  if (countEl) {
    countEl.textContent = `${filteredActiveUsers.length} usuário${filteredActiveUsers.length !== 1 ? 's' : ''}`;
  }
}

async function updateUserRole(userId, newRole) {
  try {
    // Atualizar estado local primeiro (para feedback imediato)
    const userIndex = permissionsUsers.findIndex(user => user.id === userId);
    if (userIndex !== -1) {
      permissionsUsers[userIndex].role = newRole;
      // A tabela de permissões é gerenciada separadamente
    }
    
    // Atualizar no Firestore
    const { updateDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    await updateDoc(doc(window.firebaseDb, 'users', userId), {
      role: newRole,
      updatedAt: new Date()
    });
    
    // Atualizar também a variável newTablesUsers para manter consistência
    const activeUserIndex = newTablesUsers.findIndex(user => user.id === userId);
    if (activeUserIndex !== -1) {
      newTablesUsers[activeUserIndex].role = newRole;
    }
    
    
  } catch (error) {
    console.error('Erro ao atualizar função do usuário:', error);
    alert('Erro ao atualizar função do usuário');
    
    // Reverter mudança local em caso de erro
    loadUsersForTables();
  }
}

// Funções de filtro para Usuários Ativos

function filterActiveUsers(filter) {
  currentActiveFilter = filter;
  
  // Resetar para primeira página ao filtrar
  activeUsersCurrentPage = 1;
  
  // Atualizar botões de filtro
  const buttons = ['filterAllUsers', 'filterActive30Days', 'filterActive7Days', 'filterActive1Day'];
  buttons.forEach(btnId => {
    const btn = document.getElementById(btnId);
    if (btn) {
      if (btnId === `filter${filter.charAt(0).toUpperCase() + filter.slice(1)}Users` || 
          (filter === 'all' && btnId === 'filterAllUsers') ||
          (filter === '30' && btnId === 'filterActive30Days') ||
          (filter === '7' && btnId === 'filterActive7Days') ||
          (filter === '1' && btnId === 'filterActive1Day')) {
        btn.className = 'px-2 py-1 bg-blue-matte text-white rounded text-xs hover:bg-blue-600 transition-colors';
      } else {
        btn.className = 'px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs hover:bg-gray-300 transition-colors';
      }
    }
  });
  
  // Filtrar usuários usando a variável separada
  let filteredUsers = newTablesUsers;
  const now = Date.now();
  
  if (filter === '30') {
    filteredUsers = newTablesUsers.filter(user => {
      if (!user.lastLogin) return false;
      let date;
      if (user.lastLogin.seconds) {
        date = new Date(user.lastLogin.seconds * 1000);
      } else if (user.lastLogin.toDate) {
        date = user.lastLogin.toDate();
      } else {
        date = new Date(user.lastLogin);
      }
      return (now - date.getTime()) <= (30 * 24 * 60 * 60 * 1000);
    });
  } else if (filter === '7') {
    filteredUsers = newTablesUsers.filter(user => {
      if (!user.lastLogin) return false;
      let date;
      if (user.lastLogin.seconds) {
        date = new Date(user.lastLogin.seconds * 1000);
      } else if (user.lastLogin.toDate) {
        date = user.lastLogin.toDate();
      } else {
        date = new Date(user.lastLogin);
      }
      return (now - date.getTime()) <= (7 * 24 * 60 * 60 * 1000);
    });
  } else if (filter === '1') {
    filteredUsers = newTablesUsers.filter(user => {
      if (!user.lastLogin) return false;
      let date;
      if (user.lastLogin.seconds) {
        date = new Date(user.lastLogin.seconds * 1000);
      } else if (user.lastLogin.toDate) {
        date = user.lastLogin.toDate();
      } else {
        date = new Date(user.lastLogin);
      }
      return (now - date.getTime()) <= (24 * 60 * 60 * 1000);
    });
  }
  
  // Atualizar APENAS a tabela de usuários ativos (NÃO a de permissões)
  renderActiveUsersTable(filteredUsers);
  updateActiveUsersStats(filteredUsers);
  
  // NÃO atualizar a tabela de Usuários & Permissões - ela deve sempre mostrar todos os usuários
}

function updateActiveUsersStats(users) {
  const total = users.length;
  const active = users.filter(user => {
    if (!user.lastLogin) return false;
    let date;
    if (user.lastLogin.seconds) {
      date = new Date(user.lastLogin.seconds * 1000);
    } else if (user.lastLogin.toDate) {
      date = user.lastLogin.toDate();
    } else {
      date = new Date(user.lastLogin);
    }
    return (Date.now() - date.getTime()) <= (7 * 24 * 60 * 60 * 1000);
  }).length;
  const inactive = total - active;
  
  const totalEl = document.getElementById('totalUsers');
  const activeEl = document.getElementById('activeUsers');
  const inactiveEl = document.getElementById('inactiveUsers');
  
  if (totalEl) totalEl.textContent = total;
  if (activeEl) activeEl.textContent = active;
  if (inactiveEl) inactiveEl.textContent = inactive;
}
// Expor funções globalmente
window.loadUsers = loadUsers;
window.loadUsersForTables = loadUsersForTables;
window.updateUserRole = updateUserRole;
window.filterActiveUsers = filterActiveUsers;

// ==================== FUNÇÕES SEPARADAS PARA CARD DE PERMISSÕES ====================

// Variáveis separadas para o card de permissões
let permissionsUsersData = [];
let permissionsCurrentPage = 1;
const permissionsPerPage = 10;

// Carregar usuários especificamente para o card de permissões
async function loadPermissionsUsers() {
  try {
    
    const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    
    const usersRef = collection(window.firebaseDb, 'users');
    const snapshot = await getDocs(usersRef);
    
    permissionsUsersData = [];
    snapshot.forEach(doc => {
      const userData = doc.data();
      permissionsUsersData.push({
        id: doc.id,
        email: userData.email || 'N/A',
        displayName: userData.displayName || userData.name || 'N/A',
        role: userData.role || 'user',
        lastLogin: userData.lastLoginAt ? userData.lastLoginAt.toDate() : null
      });
    });
    
    
    renderPermissionsTable();
    updatePermissionsPagination();
  } catch (error) {
    console.error('❌ Erro ao carregar usuários para permissões:', error);
  }
}

// Renderizar tabela de permissões
function renderPermissionsTable() {
  const tbody = document.getElementById('permissionsTableBody');
  if (!tbody) {
    
    return;
  }
  
  if (permissionsUsersData.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" class="py-6 text-center text-gray-500">Nenhum usuário encontrado</td>
      </tr>
    `;
    return;
  }
  
  const startIndex = (permissionsCurrentPage - 1) * permissionsPerPage;
  const endIndex = startIndex + permissionsPerPage;
  const usersPage = permissionsUsersData.slice(startIndex, endIndex);
  
  // Verificar se o usuário atual pode editar e quais cargos pode atribuir
  const roleFromWindow = (window.adminRoleLower || '').toLowerCase();
  const roleFromSession = (getCurrentAdminRole() || '').toLowerCase();
  const currentUserRole = roleFromWindow || roleFromSession;
  
  const canEdit = ['ceo', 'gerente'].includes(currentUserRole.toLowerCase()); // CEO e Gerente podem editar
  
  // Função para gerar opções de cargo baseado na permissão do usuário
  function getRoleOptions(userRole) {
    const allRoles = [
      { value: 'user', label: 'Usuário' },
      { value: 'vendedor', label: 'Vendedor' },
      { value: 'gerente', label: 'Gerente' },
      { value: 'design', label: 'Design' },
      { value: 'admin', label: 'Admin' },
      { value: 'socio', label: 'Sócio' },
      { value: 'ceo', label: 'Ceo' }
    ];
    
    if (currentUserRole === 'ceo') {
      // CEO pode atribuir qualquer cargo
      return allRoles.map(role => 
        `<option value="${role.value}" ${userRole === role.value ? 'selected' : ''}>${role.label}</option>`
      ).join('');
    } else if (currentUserRole === 'socio') {
      // Sócio vê todos os cargos mas não pode editar (somente leitura)
      return allRoles.map(role => 
        `<option value="${role.value}" ${userRole === role.value ? 'selected' : ''}>${role.label}</option>`
      ).join('');
    } else if (currentUserRole === 'gerente') {
      // Gerente pode atribuir apenas Vendedor
      return allRoles
        .filter(role => role.value === 'vendedor')
        .map(role => 
          `<option value="${role.value}" ${userRole === role.value ? 'selected' : ''}>${role.label}</option>`
        ).join('');
    } else {
      // Outros não podem atribuir nenhum cargo
      return allRoles
        .filter(role => role.value === userRole) // Apenas o cargo atual
        .map(role => 
          `<option value="${role.value}" selected>${role.label}</option>`
        ).join('');
    }
  }
  
  tbody.innerHTML = usersPage.map(user => `
    <tr class="border-b border-gray-100 hover:bg-gray-50">
      <td class="py-3 px-2 text-gray-700 font-medium">${user.displayName}</td>
      <td class="py-3 px-2 text-gray-600">${user.email}</td>
      <td class="py-3 px-2">
        <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">${getRoleDisplayName(user.role)}</span>
      </td>
      <td class="py-3 px-2">
        <select class="w-full text-xs border border-gray-300 rounded px-2 py-1 focus:ring-2 focus:ring-blue-500 focus:border-blue-500" 
                data-user-id="${user.id}" data-current-role="${user.role}" ${!canEdit ? 'disabled' : ''}>
          ${getRoleOptions(user.role)}
        </select>
      </td>
      <td class="py-3 px-2">
        ${canEdit ? `
          <button onclick="updatePermissionsUserRole('${user.id}')" 
                  class="px-3 py-1 bg-blue-600 text-white rounded text-xs font-medium hover:bg-blue-700 transition-colors focus:ring-2 focus:ring-blue-500 focus:ring-offset-1">
            Salvar
          </button>
        ` : currentUserRole === 'socio' ? `
          <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded text-xs font-medium cursor-not-allowed">
            Sócio - Somente Leitura
          </span>
        ` : `
          <span class="px-3 py-1 bg-gray-300 text-gray-600 rounded text-xs font-medium cursor-not-allowed">
            Somente Leitura
          </span>
        `}
      </td>
    </tr>
  `).join('');
}

// Função para obter nome de exibição da função
function getRoleDisplayName(role) {
  const roleNames = {
    'user': 'Usuário',
    'vendedor': 'Vendedor',
    'gerente': 'Gerente',
    'design': 'Design',
    'admin': 'Admin',
    'socio': 'Sócio',
    'ceo': 'Ceo'
  };
  return roleNames[role] || role;
}

// Atualizar função do usuário (específico para permissões)
async function updatePermissionsUserRole(userId) {
  try {
    const selectElement = document.querySelector(`select[data-user-id="${userId}"]`);
    if (!selectElement) {
      console.error('❌ Select element não encontrado para o usuário:', userId);
      return;
    }
    
    const newRole = selectElement.value;
    const currentRole = selectElement.getAttribute('data-current-role');
    
    if (newRole === currentRole) {
      
      return;
    }
    
    // Verificar se o usuário atual tem permissão para atribuir este cargo
    if (!canAssignRole(newRole)) {
      alert('❌ Você não tem permissão para atribuir este cargo.');
      // Reverter o select para o valor anterior
      selectElement.value = currentRole;
      return;
    }
    
    // Atualizar estado local primeiro
    const userIndex = permissionsUsersData.findIndex(user => user.id === userId);
    if (userIndex !== -1) {
      permissionsUsersData[userIndex].role = newRole;
      selectElement.setAttribute('data-current-role', newRole);
    }
    
    // Atualizar no Firestore
    const { updateDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const userRef = doc(window.firebaseDb, 'users', userId);
    await updateDoc(userRef, { role: newRole });
    
    // Log da ação
    const user = permissionsUsersData.find(u => u.id === userId);
    if (user) {
      await logAdminAction('change_role', `Alterou cargo de ${user.email} para ${getRoleDisplayName(newRole)}`);
    }
    
    
    
    // Mostrar feedback visual
    const button = selectElement.parentElement.nextElementSibling.querySelector('button');
    const originalText = button.textContent;
    button.textContent = 'Salvo!';
    button.className = 'px-3 py-1 bg-green-600 text-white rounded text-xs font-medium transition-colors';
    
    setTimeout(() => {
      button.textContent = originalText;
      button.className = 'px-3 py-1 bg-blue-600 text-white rounded text-xs font-medium hover:bg-blue-700 transition-colors focus:ring-2 focus:ring-blue-500 focus:ring-offset-1';
    }, 2000);
    
  } catch (error) {
    console.error('❌ Erro ao atualizar função do usuário:', error);
    alert('Erro ao atualizar função do usuário');
    
    // Reverter mudança local em caso de erro
    loadPermissionsUsers();
  }
}

// Atualizar paginação do card de permissões
function updatePermissionsPagination() {
  const totalPages = Math.ceil(permissionsUsersData.length / permissionsPerPage);
  const paginationContainer = document.getElementById('permissionsPagination');
  const countElement = document.getElementById('permissionsUsersCount');
  const pageInfoElement = document.getElementById('permissionsUsersPageInfo');
  
  if (countElement) {
    countElement.textContent = `${permissionsUsersData.length} usuários`;
  }
  
  if (pageInfoElement) {
    pageInfoElement.textContent = `Página ${permissionsCurrentPage} de ${totalPages}`;
  }
  
  if (!paginationContainer || totalPages <= 1) {
    if (paginationContainer) paginationContainer.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // Botão anterior
  if (permissionsCurrentPage > 1) {
    paginationHTML += `<button onclick="changePermissionsPage(${permissionsCurrentPage - 1})" class="px-2 py-1 text-xs border rounded hover:bg-gray-50">‹</button>`;
  }
  
  // Páginas
  for (let i = 1; i <= totalPages; i++) {
    if (i === permissionsCurrentPage) {
      paginationHTML += `<button class="px-2 py-1 text-xs bg-blue-600 text-white rounded">${i}</button>`;
    } else {
      paginationHTML += `<button onclick="changePermissionsPage(${i})" class="px-2 py-1 text-xs border rounded hover:bg-gray-50">${i}</button>`;
    }
  }
  
  // Botão próximo
  if (permissionsCurrentPage < totalPages) {
    paginationHTML += `<button onclick="changePermissionsPage(${permissionsCurrentPage + 1})" class="px-2 py-1 text-xs border rounded hover:bg-gray-50">›</button>`;
  }
  
  paginationContainer.innerHTML = paginationHTML;
}

// Mudar página do card de permissões
function changePermissionsPage(page) {
  permissionsCurrentPage = page;
  renderPermissionsTable();
  updatePermissionsPagination();
}

// ==================== GERENCIAMENTO DE TOKENS ====================

// Variáveis para tokens
let tokensUsersData = [];
let tokensFilteredData = [];
let tokensCurrentPage = 1;
const tokensPerPage = 5;

// Carregar usuários para gerenciamento de tokens
async function loadTokensUsers() {
  try {
    
    const { collection, getDocsFromServer } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const usersCol = collection(window.firebaseDb, 'users');
    const snapUsers = await getDocsFromServer(usersCol);
    
    tokensUsersData = [];
    snapUsers.forEach(doc => {
      const data = doc.data();
      tokensUsersData.push({
        id: doc.id,
        email: data.email || 'N/A',
        role: data.role || 'Usuário',
        tokens: data.tokens || 0
      });
    });
    
    // Ordenar por quantidade de tokens (maior para menor)
    tokensUsersData.sort((a, b) => {
      const tokensA = Number(a.tokens || 0);
      const tokensB = Number(b.tokens || 0);
      return tokensB - tokensA; // Decrescente
    });
    
    
    tokensFilteredData = [...tokensUsersData]; // Inicializar dados filtrados (já ordenado)
    renderTokensTable();
    updateTokensPagination();
  } catch (error) {
    console.error('❌ Erro ao carregar usuários para tokens:', error);
  }
}
// Renderizar tabela de tokens
function renderTokensTable() {
  const tbody = document.getElementById('tokensTableBody');
  if (!tbody) return;
  
  const startIndex = (tokensCurrentPage - 1) * tokensPerPage;
  const endIndex = startIndex + tokensPerPage;
  const usersPage = tokensFilteredData.slice(startIndex, endIndex);
  
  // Verificar se o usuário atual pode gerenciar tokens
  const currentUserRole = (window.adminRoleLower || '').toLowerCase();
  const canManageTokens = ['ceo', 'gerente'].includes(currentUserRole);
  
  tbody.innerHTML = usersPage.map(user => `
    <tr class="border-b border-gray-100">
      <td class="py-3 px-2">
        <div class="font-medium text-gray-900">${user.email}</div>
      </td>
      <td class="py-3 px-2">
        <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">${getRoleDisplayName(user.role)}</span>
      </td>
      <td class="py-3 px-2">
        <span class="font-bold text-blue-600">${user.tokens}</span>
      </td>
      <td class="py-3 px-2">
        ${canManageTokens ? `
          <div class="flex gap-1">
            <button onclick="addTokens('${user.id}', '${user.email}')" 
                    class="px-2 py-1 bg-green-600 text-white rounded text-xs hover:bg-green-700">
              + Adicionar
            </button>
            <button onclick="removeTokens('${user.id}', '${user.email}')" 
                    class="px-2 py-1 bg-red-600 text-white rounded text-xs hover:bg-red-700">
              - Remover
            </button>
          </div>
        ` : `
          <span class="px-2 py-1 bg-gray-300 text-gray-600 rounded text-xs cursor-not-allowed">
            Somente Leitura
          </span>
        `}
      </td>
    </tr>
  `).join('');
  
  // Atualizar contador
  const countElement = document.getElementById('tokensUsersCount');
  if (countElement) {
    const totalUsers = tokensUsersData.length;
    const filteredUsers = tokensFilteredData.length;
    if (filteredUsers === totalUsers) {
      countElement.textContent = `${totalUsers} usuários`;
    } else {
      countElement.textContent = `${filteredUsers} de ${totalUsers} usuários`;
    }
  }
}

// Adicionar tokens
async function addTokens(userId, userEmail) {
  const amount = prompt(`Quantos tokens adicionar para ${userEmail}?`);
  if (!amount || isNaN(amount) || amount <= 0) {
    alert('Por favor, insira um número válido maior que zero.');
    return;
  }
  
  try {
    const { doc, updateDoc, increment } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const userRef = doc(window.firebaseDb, 'users', userId);
    await updateDoc(userRef, {
      tokens: increment(parseInt(amount))
    });
    
    // Log da ação
    await logAdminAction('add_tokens', `Adicionou ${amount} tokens para ${userEmail}`);
    
    alert(`✅ ${amount} tokens adicionados para ${userEmail}`);
    loadTokensUsers(); // Recarregar dados
  } catch (error) {
    console.error('❌ Erro ao adicionar tokens:', error);
    alert('❌ Erro ao adicionar tokens. Tente novamente.');
  }
}

// Remover tokens
async function removeTokens(userId, userEmail) {
  const amount = prompt(`Quantos tokens remover de ${userEmail}?`);
  if (!amount || isNaN(amount) || amount <= 0) {
    alert('Por favor, insira um número válido maior que zero.');
    return;
  }
  
  try {
    const { doc, updateDoc, increment } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const userRef = doc(window.firebaseDb, 'users', userId);
    await updateDoc(userRef, {
      tokens: increment(-parseInt(amount))
    });
    
    // Log da ação
    await logAdminAction('remove_tokens', `Removeu ${amount} tokens de ${userEmail}`);
    
    alert(`✅ ${amount} tokens removidos de ${userEmail}`);
    loadTokensUsers(); // Recarregar dados
  } catch (error) {
    console.error('❌ Erro ao remover tokens:', error);
    alert('❌ Erro ao remover tokens. Tente novamente.');
  }
}

// Paginação de tokens
function updateTokensPagination() {
  const totalPages = Math.ceil(tokensFilteredData.length / tokensPerPage);
  const paginationContainer = document.getElementById('tokensPagination');
  if (!paginationContainer) return;
  
  if (totalPages <= 1) {
    paginationContainer.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // Botão anterior
  if (tokensCurrentPage > 1) {
    paginationHTML += `<button onclick="changeTokensPage(${tokensCurrentPage - 1})" class="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">‹</button>`;
  }
  
  // Páginas
  for (let i = 1; i <= totalPages; i++) {
    if (i === tokensCurrentPage) {
      paginationHTML += `<button class="px-2 py-1 text-xs bg-blue-600 text-white rounded">${i}</button>`;
    } else {
      paginationHTML += `<button onclick="changeTokensPage(${i})" class="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">${i}</button>`;
    }
  }
  
  // Botão próximo
  if (tokensCurrentPage < totalPages) {
    paginationHTML += `<button onclick="changeTokensPage(${tokensCurrentPage + 1})" class="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">›</button>`;
  }
  
  paginationContainer.innerHTML = paginationHTML;
}

function changeTokensPage(page) {
  const totalPages = Math.ceil(tokensFilteredData.length / tokensPerPage);
  
  // Validar página
  if (page < 1) {
    tokensCurrentPage = 1;
  } else if (page > totalPages) {
    tokensCurrentPage = totalPages;
  } else {
    tokensCurrentPage = page;
  }
  
  renderTokensTable();
  updateTokensPagination();
}

// Filtrar usuários de tokens
function filterTokensUsers() {
  const searchInput = document.getElementById('tokensSearchInput');
  if (!searchInput) return;
  
  const searchTerm = searchInput.value.toLowerCase().trim();
  
  if (searchTerm === '') {
    tokensFilteredData = [...tokensUsersData]; // Já está ordenado
  } else {
    tokensFilteredData = tokensUsersData.filter(user => 
      user.email.toLowerCase().includes(searchTerm) ||
      user.role.toLowerCase().includes(searchTerm) ||
      getRoleDisplayName(user.role).toLowerCase().includes(searchTerm)
    );
    // Manter ordenação por tokens após filtrar
    tokensFilteredData.sort((a, b) => {
      const tokensA = Number(a.tokens || 0);
      const tokensB = Number(b.tokens || 0);
      return tokensB - tokensA; // Decrescente
    });
  }
  
  tokensCurrentPage = 1; // Reset para primeira página
  renderTokensTable();
  updateTokensPagination();
}

// ==================== SISTEMA DE CUPONS ====================

// Variáveis globais para cupons
let couponsData = [];
let couponUsageData = [];
let filteredCouponUsageData = [];
let couponUsageFilters = { period: '7d', context: 'all', couponCode: 'all', productName: '' };

// Carregar cupons
async function loadCoupons() {
    try {
        
        const { collection, getDocs, orderBy, query } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const couponsRef = collection(window.firebaseDb, 'coupons');
        const q = query(couponsRef, orderBy('createdAt', 'desc'));
        const snapshot = await getDocs(q);
        
        couponsData = [];
        snapshot.forEach(doc => {
            const data = doc.data();
            couponsData.push({
                id: doc.id,
                ...data,
                createdAt: data.createdAt?.toDate() || new Date(),
                expirationDate: data.expirationDate?.toDate() || null
            });
        });
        
        
        // Garantir que afiliados estejam carregados antes de renderizar
        if (affiliatesData.length === 0) {
            try {
                await loadAffiliates();
            } catch (err) {
                console.warn('⚠️ Erro ao carregar afiliados antes de renderizar cupons:', err);
            }
        }
        renderCouponsTable();
    } catch (error) {
        console.error('❌ Erro ao carregar cupons:', error);
        const tbody = document.getElementById('couponsTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="py-6 text-center text-red-500">Erro ao carregar cupons</td>
                </tr>
            `;
        }
    }
}

// Renderizar tabela de cupons
function renderCouponsTable() {
    const tbody = document.getElementById('couponsTableBody');
    const countElement = document.getElementById('activeCouponsCount');
    
    if (!tbody) return;
    
    if (couponsData.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="py-6 text-center text-gray-500">Nenhum cupom encontrado</td>
            </tr>
        `;
        if (countElement) countElement.textContent = '0 cupons';
        return;
    }
    
    if (countElement) countElement.textContent = `${couponsData.length} cupons`;
    
    tbody.innerHTML = couponsData.map(coupon => {
        const isExpired = coupon.expirationDate && coupon.expirationDate < new Date();
        const isActive = coupon.isActive && !isExpired;
        
        const discountText = coupon.discountType === 'percentage' 
            ? `${coupon.discountValue}%` 
            : `R$ ${coupon.discountValue.toFixed(2)}`;
        
        const usageTypeText = {
            'both': 'Eventos + Loja',
            'events': 'Apenas Eventos',
            'store': 'Apenas Loja'
        }[coupon.usageType] || 'N/A';
        
        const statusBadge = isActive 
            ? '<span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">Ativo</span>'
            : '<span class="px-2 py-1 bg-red-100 text-red-800 rounded text-xs">Inativo</span>';
        
        // Buscar nome do afiliado se houver
        let affiliateName = null;
        if (coupon.affiliateId) {
            const affiliate = affiliatesData.find(a => a.id === coupon.affiliateId);
            if (affiliate) {
                affiliateName = affiliate.name || affiliate.email?.split('@')[0] || 'Afiliado';
            } else {
                // Se não encontrou, pode ser que o ID seja o email ou outro formato
                const affiliateByEmail = affiliatesData.find(a => a.email === coupon.affiliateId);
                if (affiliateByEmail) {
                    affiliateName = affiliateByEmail.name || affiliateByEmail.email?.split('@')[0] || 'Afiliado';
                } else {
                    console.warn('⚠️ Afiliado não encontrado para cupom:', coupon.code, 'affiliateId:', coupon.affiliateId);
                }
            }
        }
        
        return `
            <tr class="border-b border-gray-100 hover:bg-gray-50">
                <td class="py-2 px-2">
                    <span class="font-mono text-xs bg-gray-100 px-2 py-1 rounded">${coupon.code}</span>
                </td>
                <td class="py-2 px-2 text-xs">${discountText}</td>
                <td class="py-2 px-2">
                    <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">${usageTypeText}</span>
                </td>
                <td class="py-2 px-2 text-xs">
                    ${affiliateName ? `<span class="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded" title="Vincular a: ${affiliateName}">👤 ${affiliateName}</span>` : '<span class="text-xs text-gray-400">-</span>'}
                </td>
                <td class="py-2 px-2">${statusBadge}</td>
                <td class="py-2 px-2">
                    <div class="flex gap-1">
                        <button onclick="editCoupon('${coupon.id}')" 
                                class="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200">
                            Editar
                        </button>
                        <button onclick="toggleCouponStatus('${coupon.id}', ${!isActive})" 
                                class="px-2 py-1 text-xs rounded ${isActive ? 'bg-red-100 text-red-700 hover:bg-red-200' : 'bg-green-100 text-green-700 hover:bg-green-200'}">
                            ${isActive ? 'Desativar' : 'Ativar'}
                        </button>
                        <button onclick="deleteCoupon('${coupon.id}')" 
                                class="px-2 py-1 text-xs bg-red-100 text-red-700 rounded hover:bg-red-200">
                            Excluir
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// Carregar histórico de uso de cupons
async function loadCouponUsage() {
    try {
        
        const { collection, getDocs, orderBy, query } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const usageRef = collection(window.firebaseDb, 'couponUsage');
        const q = query(usageRef, orderBy('usedAt', 'desc'));
        const snapshot = await getDocs(q);
        
        couponUsageData = [];
        snapshot.forEach(doc => {
            const data = doc.data();
            couponUsageData.push({
                id: doc.id,
                ...data,
                usedAt: data.usedAt?.toDate() || new Date()
            });
        });
        
        
        
        // Popular select de cupons
        populateCouponCodeFilter();
        
        // Inicializar filteredCouponUsageData com todos os dados antes de aplicar filtros
        filteredCouponUsageData = [...couponUsageData];
        
        // Inicializa filtros padrão e aplica
        applyCouponUsageFilters();
    } catch (error) {
        console.error('❌ Erro ao carregar histórico de cupons:', error);
        const tbody = document.getElementById('couponUsageTableBody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="py-6 text-center text-red-500">Erro ao carregar histórico</td>
                </tr>
            `;
        }
    }
}

// Popular select de cupons no filtro
function populateCouponCodeFilter() {
    const select = document.getElementById('couponUsageCodeFilter');
    if (!select) return;
    
    // Obter códigos únicos de cupons
    const uniqueCodes = [...new Set(couponUsageData.map(u => u.couponCode).filter(Boolean))].sort();
    
    select.innerHTML = '<option value="all" selected>Todos os cupons</option>';
    uniqueCodes.forEach(code => {
        const option = document.createElement('option');
        option.value = code;
        option.textContent = code;
        select.appendChild(option);
    });
}
// Renderizar tabela de uso de cupons
function renderCouponUsageTable() {
    const tbody = document.getElementById('couponUsageTableBody');
    const countElement = document.getElementById('couponUsageCount');
    
    if (!tbody) return;
    
    // Sempre usar filteredCouponUsageData se existir (mesmo que vazio), senão usar couponUsageData
    // Isso garante que os filtros sejam respeitados mesmo quando não há resultados
    const data = Array.isArray(filteredCouponUsageData) ? filteredCouponUsageData : couponUsageData;
    
    if (data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="py-6 text-center text-gray-500">Nenhum uso de cupom encontrado</td>
            </tr>
        `;
        if (countElement) countElement.textContent = '0 usos';
        updateCouponStats([]);
        return;
    }
    
    if (countElement) countElement.textContent = `${data.length} usos`;
    
    // Estatísticas já são atualizadas em applyCouponUsageFilters
    // Não atualizar aqui para evitar duplicação
    
    tbody.innerHTML = data.map(usage => {
        // Usar os campos que realmente existem no banco
        const orderValue = usage.orderValue || 0;
        const discountAmount = usage.discountAmount || 0;
        const finalValue = usage.finalValue || (orderValue - discountAmount);
        
        // Calcular percentual - usar discountPercentage se disponível, senão calcular
        const discountPercentage = usage.discountPercentage || (orderValue > 0 ? ((discountAmount / orderValue) * 100).toFixed(2) : '0.00');
        const productName = usage.productName || usage.productId || 'N/A';
        
        return `
            <tr class="border-b border-gray-100 hover:bg-gray-50">
                <td class="py-2 px-2 text-xs">${usage.usedAt ? formatDateTime(usage.usedAt) : 'N/A'}</td>
                <td class="py-2 px-2">
                    <span class="font-mono text-xs bg-blue-100 px-2 py-1 rounded">${usage.couponCode || 'N/A'}</span>
                </td>
                <td class="py-2 px-2 text-xs">
                    <div class="font-medium">${usage.customerName ? usage.customerName.split(' ')[0] : 'N/A'}</div>
                    <div class="text-gray-500 text-xs">${usage.customerEmail ? usage.customerEmail.split('@')[0] : ''}</div>
                </td>
                <td class="py-2 px-2 text-xs">
                    <div class="font-medium">${productName}</div>
                    ${usage.productId ? `<div class="text-gray-500 text-xs">ID: ${usage.productId}</div>` : ''}
                </td>
                <td class="py-2 px-2 text-xs">R$ ${orderValue.toFixed(2)}</td>
                <td class="py-2 px-2 text-xs text-green-600 font-medium">${discountPercentage}%</td>
                <td class="py-2 px-2 text-xs text-green-600">-R$ ${discountAmount.toFixed(2)}</td>
                <td class="py-2 px-2 text-xs font-medium">R$ ${finalValue.toFixed(2)}</td>
            </tr>
        `;
    }).join('');
}

// Atualizar estatísticas de cupons
function updateCouponStats(data) {
    const total = data.length;
    const totalDiscount = data.reduce((sum, u) => sum + (u.discountAmount || 0), 0);
    const totalRevenue = data.reduce((sum, u) => sum + (u.finalValue || u.orderValue - (u.discountAmount || 0)), 0);
    const averageTicket = total > 0 ? totalRevenue / total : 0;
    
    const statsTotal = document.getElementById('couponStatsTotal');
    const statsDiscount = document.getElementById('couponStatsDiscount');
    const statsRevenue = document.getElementById('couponStatsRevenue');
    const statsAverage = document.getElementById('couponStatsAverage');
    
    if (statsTotal) statsTotal.textContent = total.toLocaleString('pt-BR');
    if (statsDiscount) statsDiscount.textContent = `R$ ${totalDiscount.toFixed(2).replace('.', ',')}`;
    if (statsRevenue) statsRevenue.textContent = `R$ ${totalRevenue.toFixed(2).replace('.', ',')}`;
    if (statsAverage) statsAverage.textContent = `R$ ${averageTicket.toFixed(2).replace('.', ',')}`;
}

// Aplicar filtros de período e contexto ao histórico de cupons
function applyCouponUsageFilters() {
    try {
        
        
        
        const now = new Date();
        let fromDate = null;
        switch (couponUsageFilters.period) {
            case '1d': fromDate = new Date(now.getTime() - 1 * 24 * 60 * 60 * 1000); break;
            case '7d': fromDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); break;
            case '15d': fromDate = new Date(now.getTime() - 15 * 24 * 60 * 60 * 1000); break;
            case '30d': fromDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000); break;
            case 'all': default: fromDate = null; break;
        }
        
        filteredCouponUsageData = couponUsageData.filter(u => {
            // Filtro por período
            let usedAt;
            if (u.usedAt instanceof Date) {
                usedAt = u.usedAt;
            } else if (u.usedAt && typeof u.usedAt.toDate === 'function') {
                usedAt = u.usedAt.toDate();
            } else {
                usedAt = new Date(u.usedAt);
            }
            const inPeriod = fromDate ? usedAt >= fromDate && usedAt <= now : true;
            
            // Filtro por contexto (events, store ou ambos)
            const ctx = (u.context || '').toLowerCase();
            const inContext = couponUsageFilters.context === 'all' ? true : ctx === couponUsageFilters.context.toLowerCase();
            
            // Filtro por código de cupom
            const matchesCoupon = couponUsageFilters.couponCode === 'all' || (u.couponCode && u.couponCode === couponUsageFilters.couponCode);
            
            // Filtro por nome do produto
            const productName = (u.productName || u.productId || '').toLowerCase();
            const productFilter = (couponUsageFilters.productName || '').toLowerCase().trim();
            const matchesProduct = !productFilter || productName.includes(productFilter);
            
            return inPeriod && inContext && matchesCoupon && matchesProduct;
        });
        
        
        
        // Atualizar contador visível
        try {
            const cnt = document.getElementById('couponUsageCount');
            if (cnt) cnt.textContent = `${filteredCouponUsageData.length} usos`;
        } catch(_){}
        
        // Atualizar estatísticas com dados filtrados
        updateCouponStats(filteredCouponUsageData);
        
        // Renderizar tabela
        renderCouponUsageTable();
    } catch (e) {
        console.error('❌ Erro ao aplicar filtros de cupons:', e);
        // fallback
        filteredCouponUsageData = couponUsageData.slice();
        updateCouponStats(filteredCouponUsageData);
        renderCouponUsageTable();
    }
}

// Exportar dados de uso de cupons
function exportCouponUsageData() {
    try {
        const data = filteredCouponUsageData.length > 0 ? filteredCouponUsageData : couponUsageData;
        
        if (data.length === 0) {
            alert('Nenhum dado para exportar');
            return;
        }
        
        // Criar CSV
        const headers = ['Data/Hora', 'Código Cupom', 'Cliente', 'Email', 'Produto', 'Valor Original', 'Desconto (%)', 'Valor Desconto', 'Valor Final'];
        const rows = data.map(u => {
            const orderValue = u.orderValue || 0;
            const discountAmount = u.discountAmount || 0;
            const finalValue = u.finalValue || (orderValue - discountAmount);
            const discountPercentage = u.discountPercentage || (orderValue > 0 ? ((discountAmount / orderValue) * 100).toFixed(2) : '0.00');
            const productName = u.productName || u.productId || 'N/A';
            const date = u.usedAt ? formatDateTime(u.usedAt) : 'N/A';
            
            return [
                date,
                u.couponCode || 'N/A',
                u.customerName || 'N/A',
                u.customerEmail || 'N/A',
                productName,
                orderValue.toFixed(2),
                discountPercentage,
                discountAmount.toFixed(2),
                finalValue.toFixed(2)
            ];
        });
        
        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
        ].join('\n');
        
        // Download
        const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `cupons_uso_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        
    } catch (error) {
        console.error('❌ Erro ao exportar dados:', error);
        alert('Erro ao exportar dados: ' + error.message);
    }
}

// Abrir modal de criação de cupom
async function openCreateCouponModal() {
    const modal = document.getElementById('createCouponModal');
    if (modal) {
        modal.classList.remove('hidden');
        // Limpar formulário
        const form = document.getElementById('createCouponForm');
        if (form) form.reset();
        
        // Popular select de afiliados (agora é async)
        await populateCouponAffiliateSelect();
    }
}

// Popular select de afiliados no modal de cupom
async function populateCouponAffiliateSelect() {
    const select = document.getElementById('couponAffiliateId');
    if (!select) return;
    
    // Limpar opções existentes (exceto a primeira)
    select.innerHTML = '<option value="">Carregando afiliados...</option>';
    
    // Se affiliatesData estiver vazio, carregar afiliados primeiro
    if (!affiliatesData || affiliatesData.length === 0) {
        try {
            await loadAffiliates();
        } catch (error) {
            console.error('Erro ao carregar afiliados:', error);
            select.innerHTML = '<option value="">Erro ao carregar afiliados</option>';
            return;
        }
    }
    
    // Limpar e adicionar opção padrão
    select.innerHTML = '<option value="">Nenhum afiliado</option>';
    
    // Adicionar afiliados ativos
    const activeAffiliates = affiliatesData.filter(a => a.affiliateStatus === 'active');
    
    if (activeAffiliates.length === 0) {
        select.innerHTML = '<option value="">Nenhum afiliado ativo</option>';
        return;
    }
    
    activeAffiliates.forEach(affiliate => {
        const option = document.createElement('option');
        option.value = affiliate.id;
        option.textContent = `${affiliate.name} (${affiliate.email})`;
        select.appendChild(option);
    });
}

// Fechar modal de criação/edição de cupom
function closeCreateCouponModal() {
    const modal = document.getElementById('createCouponModal');
    if (modal) {
        modal.classList.add('hidden');
        // Limpar ID de edição
        const editIdInput = document.getElementById('couponEditId');
        if (editIdInput) editIdInput.value = '';
        // Resetar título do modal
        const modalTitle = modal.querySelector('h3');
        if (modalTitle) modalTitle.textContent = 'Criar Novo Cupom';
        // Resetar botão de submit
        const submitBtn = document.querySelector('#createCouponForm button[type="submit"]');
        if (submitBtn) submitBtn.textContent = 'Criar Cupom';
    }
}

// Editar cupom existente
async function editCoupon(couponId) {
    try {
        const coupon = couponsData.find(c => c.id === couponId);
        if (!coupon) {
            alert('Cupom não encontrado');
            return;
        }
        
        // Abrir modal
        const modal = document.getElementById('createCouponModal');
        if (!modal) {
            alert('Modal não encontrado');
            return;
        }
        
        modal.classList.remove('hidden');
        
        // Mudar título do modal
        const modalTitle = modal.querySelector('h3');
        if (modalTitle) modalTitle.textContent = 'Editar Cupom';
        
        // Popular select de afiliados (agora é async)
        await populateCouponAffiliateSelect();
        
        // Preencher formulário com dados do cupom
        document.getElementById('couponCode').value = coupon.code || '';
        document.getElementById('discountType').value = coupon.discountType || 'percentage';
        document.getElementById('discountValue').value = coupon.discountValue || 0;
        
        // Data de expiração
        if (coupon.expirationDate) {
            const expDate = coupon.expirationDate.toDate ? coupon.expirationDate.toDate() : new Date(coupon.expirationDate);
            const dateStr = expDate.toISOString().split('T')[0];
            document.getElementById('expirationDate').value = dateStr;
        } else {
            document.getElementById('expirationDate').value = '';
        }
        
        document.getElementById('couponUsageType').value = coupon.usageType || 'both';
        
        // Selecionar afiliado se houver
        if (coupon.affiliateId) {
            const affiliateSelect = document.getElementById('couponAffiliateId');
            if (affiliateSelect) {
                affiliateSelect.value = coupon.affiliateId;
            }
        }
        
        // Adicionar campo hidden com ID do cupom sendo editado
        let editIdInput = document.getElementById('couponEditId');
        if (!editIdInput) {
            editIdInput = document.createElement('input');
            editIdInput.type = 'hidden';
            editIdInput.id = 'couponEditId';
            document.getElementById('createCouponForm').appendChild(editIdInput);
        }
        editIdInput.value = couponId;
        
        // Mudar texto do botão de submit
        const submitBtn = document.querySelector('#createCouponForm button[type="submit"]');
        if (submitBtn) submitBtn.textContent = 'Salvar Alterações';
        
    } catch (error) {
        console.error('Erro ao editar cupom:', error);
        alert('Erro ao carregar dados do cupom');
    }
}

// Criar ou atualizar cupom
async function createCoupon(event) {
    event.preventDefault();
    
    const editId = document.getElementById('couponEditId')?.value?.trim();
    const isEditing = !!editId;
    
    const affiliateIdValue = document.getElementById('couponAffiliateId')?.value?.trim() || null;
    
    const couponData = {
        code: document.getElementById('couponCode').value.toUpperCase().trim(),
        discountType: document.getElementById('discountType').value,
        discountValue: parseFloat(document.getElementById('discountValue').value),
        expirationDate: document.getElementById('expirationDate').value ? 
            new Date(document.getElementById('expirationDate').value) : null,
        usageType: document.getElementById('couponUsageType').value,
        specificEvents: [],
        affiliateId: affiliateIdValue || null // Vincular afiliado ao cupom
    };
    
    // Validações
    if (couponData.discountValue <= 0) {
        alert('O valor do desconto deve ser maior que zero');
        return;
    }
    
    if (couponData.discountType === 'percentage' && couponData.discountValue > 100) {
        alert('O desconto percentual não pode ser maior que 100%');
        return;
    }
    
    try {
        if (isEditing) {
            // Atualizar cupom existente
            
            
            const { doc, updateDoc, getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            const couponRef = doc(window.firebaseDb, 'coupons', editId);
            const couponDoc = await getDoc(couponRef);
            
            if (!couponDoc.exists()) {
                alert('Cupom não encontrado');
                return;
            }
            
            const existingCoupon = couponDoc.data();
            
            // Verificar se o código mudou e se já existe outro cupom com esse código
            if (couponData.code !== existingCoupon.code) {
                const existingCouponWithCode = couponsData.find(c => c.code === couponData.code && c.id !== editId);
                if (existingCouponWithCode) {
                    alert('Já existe outro cupom com este código');
                    return;
                }
            }
            
            // Manter campos que não devem ser alterados
            couponData.isActive = existingCoupon.isActive;
            couponData.usageCount = existingCoupon.usageCount || 0;
            couponData.createdAt = existingCoupon.createdAt;
            couponData.createdBy = existingCoupon.createdBy;
            couponData.updatedAt = new Date();
            couponData.updatedBy = window.adminRoleLower || 'admin';
            
            await updateDoc(couponRef, couponData);
            
            
            // Log da ação
            await logAdminAction('update_coupon', `Atualizou cupom ${couponData.code} (${couponData.discountType === 'percentage' ? couponData.discountValue + '%' : 'R$ ' + couponData.discountValue})`);
            
            alert('Cupom atualizado com sucesso!');
        } else {           
            
            // Verificar se o código já existe
            const existingCoupon = couponsData.find(c => c.code === couponData.code);
            if (existingCoupon) {
                alert('Já existe um cupom com este código');
                return;
            }
            
            // Adicionar campos de criação
            couponData.isActive = true;
            couponData.usageCount = 0;
            couponData.createdAt = new Date();
            couponData.createdBy = window.adminRoleLower || 'admin';
            
            // Salvar no Firestore
            const { collection, addDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
            const docRef = await addDoc(collection(window.firebaseDb, 'coupons'), couponData);
            
            
            // Log da ação
            await logAdminAction('create_coupon', `Criou cupom ${couponData.code} (${couponData.discountType === 'percentage' ? couponData.discountValue + '%' : 'R$ ' + couponData.discountValue})`);
            
            alert('Cupom criado com sucesso!');
        }
        
        // Recarregar dados
        await loadCoupons();
        
        // Fechar modal
        closeCreateCouponModal();
        
    } catch (error) {
        console.error('❌ Erro ao salvar cupom:', error);
        alert('Erro ao salvar cupom: ' + error.message);
    }
}

// Alternar status do cupom
async function toggleCouponStatus(couponId, newStatus) {
    try {
        
        
        const { doc, updateDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        await updateDoc(doc(window.firebaseDb, 'coupons', couponId), {
            isActive: newStatus
        });
        
        // Log da ação
        const coupon = couponsData.find(c => c.id === couponId);
        await logAdminAction('toggle_coupon', `${newStatus ? 'Ativou' : 'Desativou'} cupom ${coupon?.code || couponId}`);
        
        // Recarregar dados
        await loadCoupons();
        
    } catch (error) {
        console.error('❌ Erro ao alterar status do cupom:', error);
        alert('Erro ao alterar status do cupom: ' + error.message);
    }
}

// Excluir cupom
async function deleteCoupon(couponId) {
    const coupon = couponsData.find(c => c.id === couponId);
    if (!coupon) return;
    
    if (!confirm(`Tem certeza que deseja excluir o cupom "${coupon.code}"?`)) {
        return;
    }
    
    try {
        
        
        const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        await deleteDoc(doc(window.firebaseDb, 'coupons', couponId));
        
        // Log da ação
        await logAdminAction('delete_coupon', `Excluiu cupom ${coupon.code}`);
        
        // Recarregar dados
        await loadCoupons();
        
        alert('Cupom excluído com sucesso!');
        
    } catch (error) {
        console.error('❌ Erro ao excluir cupom:', error);
        alert('Erro ao excluir cupom: ' + error.message);
    }
}

// ==================== HISTÓRICO DO ADMIN ====================

// Variáveis para histórico
let adminHistoryData = [];
let adminHistoryFilteredData = [];
let adminHistoryCurrentPage = 1;
const adminHistoryPerPage = 5;

// Carregar histórico do admin
async function loadAdminHistory() {
  try {
    
    const { collection, getDocsFromServer, orderBy, limit, query } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const historyCol = collection(window.firebaseDb, 'adminHistory');
    const q = query(historyCol, orderBy('timestamp', 'desc'), limit(50));
    const snapHistory = await getDocsFromServer(q);
    
    adminHistoryData = [];
    snapHistory.forEach(doc => {
      const data = doc.data();
      adminHistoryData.push({
        id: doc.id,
        ...data
      });
    });
    
    
    adminHistoryFilteredData = [...adminHistoryData]; // Inicializar dados filtrados
    renderAdminHistoryTable();
    updateAdminHistoryPagination();
  } catch (error) {
    console.error('❌ Erro ao carregar histórico do admin:', error);
    // Se não conseguir carregar, mostrar mensagem na tabela
    const tbody = document.getElementById('adminHistoryTableBody');
    if (tbody) {
      tbody.innerHTML = `
        <tr>
          <td colspan="4" class="py-6 text-center text-gray-500">
            Nenhum histórico encontrado. As ações aparecerão aqui conforme forem realizadas.
          </td>
        </tr>
      `;
    }
  }
}

// Renderizar tabela de histórico
function renderAdminHistoryTable() {
  const tbody = document.getElementById('adminHistoryTableBody');
  if (!tbody) return;
  
  const startIndex = (adminHistoryCurrentPage - 1) * adminHistoryPerPage;
  const endIndex = startIndex + adminHistoryPerPage;
  const historyPage = adminHistoryFilteredData.slice(startIndex, endIndex);
  
  tbody.innerHTML = historyPage.map(entry => `
    <tr class="border-b border-gray-100">
      <td class="py-3 px-2">
        <div class="text-xs text-gray-600">${formatDateTime(entry.timestamp)}</div>
      </td>
      <td class="py-3 px-2">
        <div class="space-y-1">
          <div class="font-medium text-xs text-gray-900">${entry.adminName || 'N/A'}</div>
        </div>
      </td>
      <td class="py-3 px-2">
        <span class="px-2 py-1 bg-gray-100 text-gray-700 rounded text-xs">${getActionDisplayName(entry.action)}</span>
      </td>
      <td class="py-3 px-2">
        <div class="text-xs text-gray-600 max-w-[200px] truncate" title="${entry.details || ''}">${entry.details || 'N/A'}</div>
      </td>
    </tr>
  `).join('');
  
  // Atualizar contador
  const countElement = document.getElementById('adminHistoryCount');
  if (countElement) {
    const totalActions = adminHistoryData.length;
    const filteredActions = adminHistoryFilteredData.length;
    if (filteredActions === totalActions) {
      countElement.textContent = `${totalActions} ações`;
    } else {
      countElement.textContent = `${filteredActions} de ${totalActions} ações`;
    }
  }
}
// Log de ação do admin
async function logAdminAction(action, details) {
  try {
    
    const { collection, addDoc, serverTimestamp, doc, getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const historyCol = collection(window.firebaseDb, 'adminHistory');
    
    // Coleta robusta dos dados do admin
    const sessionUser = JSON.parse(sessionStorage.getItem('adminSession') || '{}');
    const authUser = (window.firebaseAuth && window.firebaseAuth.currentUser) ? window.firebaseAuth.currentUser : {};
    const uid = sessionUser.uid || authUser?.uid || null;
    let adminEmail = sessionUser.email || authUser?.email || 'N/A';
    let adminRole = sessionUser.role || (window.adminRoleLower || '').toLowerCase() || 'N/A';
    
    
    
    // Buscar dados completos do usuário para obter o nome
    let adminName = 'N/A';
    if (uid) {
      try {
        
        const userRef = doc(window.firebaseDb, 'users', uid);
        const userSnap = await getDoc(userRef);
        
        
        if (userSnap.exists()) {
          const userData = userSnap.data();
          
          
          // Tentar diferentes campos para o nome
          if (userData.name && userData.name.trim() !== '') {
            adminName = userData.name;
          } else if (userData.displayName && userData.displayName.trim() !== '') {
            adminName = userData.displayName;
          } else if (userData.email) {
            // Usar parte do email antes do @ como nome
            adminName = userData.email.split('@')[0];
          } else {
            adminName = 'Usuário';
          }

          // Completar email/role se faltarem
          if (adminEmail === 'N/A' && userData.email) adminEmail = userData.email;
          if (!adminRole || adminRole === 'N/A') adminRole = (userData.role || '').toLowerCase() || 'N/A';
          
          
        } else {
          console.warn('⚠️ Documento do usuário não existe no Firebase');
          // Usar parte do email como nome
          if (adminEmail && adminEmail !== 'N/A') {
            adminName = adminEmail.split('@')[0];
          } else {
            adminName = 'Usuário';
          }
        }
      } catch (error) {
        console.warn('⚠️ Erro ao buscar nome do usuário:', error);
        // Usar parte do email como nome
        if (adminEmail && adminEmail !== 'N/A') {
          adminName = adminEmail.split('@')[0];
        } else {
          adminName = 'Usuário';
        }
      }
    } else {
      console.warn('⚠️ UID não encontrado na sessão');
      // Usar parte do email como nome
      if (adminEmail && adminEmail !== 'N/A') {
        adminName = adminEmail.split('@')[0];
      } else {
        adminName = 'Usuário';
      }
    }
    
    const logData = {
      action: action,
      details: details,
      adminName: adminName,
      timestamp: serverTimestamp()
    };
    
    
    
    await addDoc(historyCol, logData);
    
    
    // Recarregar histórico
    loadAdminHistory();
  } catch (error) {
    console.error('❌ Erro ao registrar ação do admin:', error);
    console.error('❌ Detalhes do erro:', error.message);
  }
}

// Obter nome de exibição da ação
function getActionDisplayName(action) {
  const actionNames = {
    'add_tokens': 'Adicionar Tokens',
    'remove_tokens': 'Remover Tokens',
    'change_role': 'Alterar Cargo',
    'login': 'Login',
    'logout': 'Logout',
    'export_data': 'Exportar Dados'
  };
  return actionNames[action] || action;
}

// Formatar data e hora
function formatDateTime(timestamp) {
  if (!timestamp) return 'N/A';
  
  const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
  return date.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Paginação do histórico
function updateAdminHistoryPagination() {
  const totalPages = Math.ceil(adminHistoryFilteredData.length / adminHistoryPerPage);
  const paginationContainer = document.getElementById('adminHistoryPagination');
  if (!paginationContainer) return;
  
  if (totalPages <= 1) {
    paginationContainer.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // Botão anterior
  if (adminHistoryCurrentPage > 1) {
    paginationHTML += `<button onclick="changeAdminHistoryPage(${adminHistoryCurrentPage - 1})" class="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">‹</button>`;
  }
  
  // Páginas
  for (let i = 1; i <= totalPages; i++) {
    if (i === adminHistoryCurrentPage) {
      paginationHTML += `<button class="px-2 py-1 text-xs bg-blue-600 text-white rounded">${i}</button>`;
    } else {
      paginationHTML += `<button onclick="changeAdminHistoryPage(${i})" class="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">${i}</button>`;
    }
  }
  
  // Botão próximo
  if (adminHistoryCurrentPage < totalPages) {
    paginationHTML += `<button onclick="changeAdminHistoryPage(${adminHistoryCurrentPage + 1})" class="px-2 py-1 text-xs bg-gray-200 text-gray-700 rounded hover:bg-gray-300">›</button>`;
  }
  
  paginationContainer.innerHTML = paginationHTML;
}

function changeAdminHistoryPage(page) {
  adminHistoryCurrentPage = page;
  renderAdminHistoryTable();
  updateAdminHistoryPagination();
}

// Filtrar histórico do admin
function filterAdminHistory() {
  const searchInput = document.getElementById('historySearchInput');
  if (!searchInput) return;
  
  const searchTerm = searchInput.value.toLowerCase().trim();
  
  if (searchTerm === '') {
    adminHistoryFilteredData = [...adminHistoryData];
  } else {
    adminHistoryFilteredData = adminHistoryData.filter(entry => 
      (entry.adminEmail && entry.adminEmail.toLowerCase().includes(searchTerm)) ||
      (entry.adminName && entry.adminName.toLowerCase().includes(searchTerm)) ||
      (entry.action && entry.action.toLowerCase().includes(searchTerm)) ||
      (entry.details && entry.details.toLowerCase().includes(searchTerm)) ||
      (entry.adminRole && entry.adminRole.toLowerCase().includes(searchTerm)) ||
      (getActionDisplayName(entry.action) && getActionDisplayName(entry.action).toLowerCase().includes(searchTerm))
    );
  }
  
  adminHistoryCurrentPage = 1; // Reset para primeira página
  renderAdminHistoryTable();
  updateAdminHistoryPagination();
}

// Expor funções globalmente
window.loadPermissionsUsers = loadPermissionsUsers;
// window.listAllSalesItems removido
window.updatePermissionsUserRole = updatePermissionsUserRole;
window.changePermissionsPage = changePermissionsPage;
window.loadTokensUsers = loadTokensUsers;
window.addTokens = addTokens;
window.removeTokens = removeTokens;
window.changeTokensPage = changeTokensPage;
window.filterTokensUsers = filterTokensUsers;
window.loadAdminHistory = loadAdminHistory;
window.changeAdminHistoryPage = changeAdminHistoryPage;
window.filterAdminHistory = filterAdminHistory;

// Expor funções de cupons globalmente
window.loadCoupons = loadCoupons;
window.loadCouponUsage = loadCouponUsage;

// ==================== SISTEMA DE AFILIADOS - ADMIN ====================

// Variáveis globais para afiliados
let affiliatesData = [];
let affiliateSalesData = [];

// Carregar afiliados
async function loadAffiliates() {
    try {
        
        const { collection, getDocs, query, where, orderBy } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        
        // Buscar usuários com role 'Afiliado'
        const usersRef = collection(window.firebaseDb, 'users');
        // Tentar com orderBy, se falhar, buscar sem orderBy
        let snapshot;
        try {
            const q = query(usersRef, where('role', '==', 'Afiliado'), orderBy('createdAt', 'desc'));
            snapshot = await getDocs(q);
        } catch (error) {
            // Se não houver índice, buscar sem orderBy
            console.warn('Índice não encontrado, buscando sem orderBy:', error);
            const q = query(usersRef, where('role', '==', 'Afiliado'));
            snapshot = await getDocs(q);
        }
        
        affiliatesData = [];
        snapshot.forEach(doc => {
            const data = doc.data();
            // Tratar createdAt de forma segura (pode ser Timestamp, Date, string ou número)
            let createdAt = new Date();
            if (data.createdAt) {
                if (data.createdAt.toDate && typeof data.createdAt.toDate === 'function') {
                    // É um Timestamp do Firestore
                    createdAt = data.createdAt.toDate();
                } else if (data.createdAt instanceof Date) {
                    // Já é uma Date
                    createdAt = data.createdAt;
                } else if (typeof data.createdAt === 'string' || typeof data.createdAt === 'number') {
                    // É string ou número (timestamp)
                    createdAt = new Date(data.createdAt);
                }
            }
            
            affiliatesData.push({
                id: doc.id,
                email: data.email || '',
                name: data.name || data.displayName || data.email?.split('@')[0] || 'N/A',
                commissionRate: data.commissionRate || 10, // Mantido para compatibilidade
                commissionRateEvents: data.commissionRateEvents || data.commissionRate || 10,
                commissionRateProducts: data.commissionRateProducts || data.commissionRate || 10,
                status: data.affiliateStatus || 'active',
                affiliateStatus: data.affiliateStatus || 'active', // Manter ambos para compatibilidade
                createdAt: createdAt
            });
        });
        
        
        
        // Carregar vendas e comissões para cada afiliado
        await loadAffiliateSales();
        
        // Popular filtro de afiliados
        populateAffiliateFilter();
        
        // Renderizar tabela
        renderAffiliatesTable();
        updateAffiliateStats();
        
        // Re-renderizar cupons para atualizar nomes de afiliados vinculados
        if (couponsData.length > 0) {
            renderCouponsTable();
        }
    } catch (error) {
        console.error('❌ Erro ao carregar afiliados:', error);
        const tbody = document.getElementById('affiliatesTableBody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="8" class="py-6 text-center text-red-500">Erro ao carregar afiliados</td></tr>';
        }
    }
}

// Carregar vendas de afiliados
async function loadAffiliateSales() {
    try {
        const { collection, getDocs, query, orderBy } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const salesRef = collection(window.firebaseDb, 'affiliate_sales');
        
        // Tentar com orderBy, se falhar, buscar sem orderBy
        let snapshot;
        try {
            const q = query(salesRef, orderBy('createdAt', 'desc'));
            snapshot = await getDocs(q);
        } catch (error) {
            // Se não houver índice, buscar sem orderBy
            console.warn('Índice não encontrado para affiliate_sales, buscando sem orderBy:', error);
            const q = query(salesRef);
            snapshot = await getDocs(q);
        }
        
        affiliateSalesData = [];
        snapshot.forEach(doc => {
            const data = doc.data();
            // Tratar createdAt de forma segura (pode ser Timestamp, Date, string ou número)
            let createdAt = new Date();
            if (data.createdAt) {
                if (data.createdAt.toDate && typeof data.createdAt.toDate === 'function') {
                    // É um Timestamp do Firestore
                    createdAt = data.createdAt.toDate();
                } else if (data.createdAt instanceof Date) {
                    // Já é uma Date
                    createdAt = data.createdAt;
                } else if (typeof data.createdAt === 'string' || typeof data.createdAt === 'number') {
                    // É string ou número (timestamp)
                    createdAt = new Date(data.createdAt);
                }
            }
            
            affiliateSalesData.push({
                id: doc.id,
                ...data,
                createdAt: createdAt
            });
        });
        
        
        renderAffiliateSalesTable();
    } catch (error) {
        console.error('❌ Erro ao carregar vendas de afiliados:', error);
    }
}

// Popular filtro de afiliados
function populateAffiliateFilter() {
    const select = document.getElementById('affiliateSalesFilter');
    if (!select) return;
    
    select.innerHTML = '<option value="all">Todos os afiliados</option>';
    affiliatesData.forEach(affiliate => {
        const option = document.createElement('option');
        option.value = affiliate.id;
        option.textContent = `${affiliate.name} (${affiliate.email})`;
        select.appendChild(option);
    });
}

// Renderizar tabela de afiliados
function renderAffiliatesTable() {
    const tbody = document.getElementById('affiliatesTableBody');
    if (!tbody) return;
    
    if (affiliatesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="py-6 text-center text-gray-500">Nenhum afiliado encontrado</td></tr>';
        return;
    }
    
    tbody.innerHTML = affiliatesData.map(affiliate => {
        // Calcular estatísticas do afiliado
        const sales = affiliateSalesData.filter(s => s.affiliateId === affiliate.id);
        const totalSales = sales.length;
        const totalCommission = sales.reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
        const pendingCommission = sales
            .filter(s => s.status === 'pending')
            .reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
        
        const statusBadge = affiliate.status === 'active'
            ? '<span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">Ativo</span>'
            : '<span class="px-2 py-1 bg-red-100 text-red-800 rounded text-xs">Inativo</span>';
        
        return `
            <tr class="border-b border-gray-100 hover:bg-gray-50">
                <td class="py-2 px-2 text-xs font-medium">${affiliate.name}</td>
                <td class="py-2 px-2 text-xs">${affiliate.email}</td>
                <td class="py-2 px-2 text-xs">
                    <div>Eventos: ${affiliate.commissionRateEvents || affiliate.commissionRate || 10}%</div>
                    <div class="text-gray-500">Produtos: ${affiliate.commissionRateProducts || affiliate.commissionRate || 10}%</div>
                </td>
                <td class="py-2 px-2 text-xs">${totalSales}</td>
                <td class="py-2 px-2 text-xs font-medium">R$ ${totalCommission.toFixed(2)}</td>
                <td class="py-2 px-2 text-xs text-orange-600">R$ ${pendingCommission.toFixed(2)}</td>
                <td class="py-2 px-2 text-xs">${statusBadge}</td>
                <td class="py-2 px-2 text-xs">
                    <div class="flex gap-1">
                        <button onclick="editAffiliate('${affiliate.id}')" 
                                class="px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-xs">
                            Editar
                        </button>
                        <button onclick="viewAffiliateDetails('${affiliate.id}')" 
                                class="px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 text-xs">
                            Detalhes
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// Renderizar tabela de vendas de afiliados
function renderAffiliateSalesTable() {
    const tbody = document.getElementById('affiliateSalesTableBody');
    if (!tbody) return;
    
    const affiliateFilter = document.getElementById('affiliateSalesFilter')?.value || 'all';
    const statusFilter = document.getElementById('affiliateSalesStatusFilter')?.value || 'all';
    
    let filteredSales = affiliateSalesData;
    
    if (affiliateFilter !== 'all') {
        filteredSales = filteredSales.filter(s => s.affiliateId === affiliateFilter);
    }
    
    if (statusFilter !== 'all') {
        filteredSales = filteredSales.filter(s => s.status === statusFilter);
    }
    
    if (filteredSales.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9" class="py-6 text-center text-gray-500">Nenhuma venda encontrada</td></tr>';
        return;
    }
    
    tbody.innerHTML = filteredSales.map(sale => {
        const affiliate = affiliatesData.find(a => a.id === sale.affiliateId);
        const date = sale.createdAt ? new Date(sale.createdAt).toLocaleDateString('pt-BR') : 'N/A';
        const statusBadge = sale.status === 'paid'
            ? '<span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">Paga</span>'
            : '<span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">Pendente</span>';
        
        return `
            <tr class="border-b border-gray-100 hover:bg-gray-50">
                <td class="py-2 px-2 text-xs">${date}</td>
                <td class="py-2 px-2 text-xs">${affiliate?.name || sale.affiliateId || 'N/A'}</td>
                <td class="py-2 px-2 text-xs">${sale.customerName || sale.customerEmail || 'N/A'}</td>
                <td class="py-2 px-2 text-xs">
                    <div>${sale.productName || sale.productId || 'N/A'}</div>
                    <div class="text-xs text-gray-500">${sale.saleType === 'event' ? '📅 Evento' : '🛒 Produto'}</div>
                </td>
                <td class="py-2 px-2 text-xs font-medium">R$ ${(sale.saleValue || 0).toFixed(2)}</td>
                <td class="py-2 px-2 text-xs">${(sale.commissionRate || 0).toFixed(1)}%</td>
                <td class="py-2 px-2 text-xs font-medium text-green-600">R$ ${(sale.commissionAmount || 0).toFixed(2)}</td>
                <td class="py-2 px-2 text-xs">${statusBadge}</td>
                <td class="py-2 px-2 text-xs">
                    ${sale.status === 'pending' ? `
                        <button onclick="approveAffiliateCommission('${sale.id}')" 
                                class="px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200 text-xs">
                            Aprovar
                        </button>
                    ` : ''}
                </td>
            </tr>
        `;
    }).join('');
}

// Atualizar estatísticas de afiliados
function updateAffiliateStats() {
    const totalAffiliates = affiliatesData.length;
    const totalSales = affiliateSalesData.length;
    const totalCommission = affiliateSalesData.reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
    const pendingCommission = affiliateSalesData
        .filter(s => s.status === 'pending')
        .reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
    
    const statsTotal = document.getElementById('affiliateStatsTotal');
    const statsSales = document.getElementById('affiliateStatsSales');
    const statsCommission = document.getElementById('affiliateStatsCommission');
    const statsPending = document.getElementById('affiliateStatsPending');
    
    if (statsTotal) statsTotal.textContent = totalAffiliates;
    if (statsSales) statsSales.textContent = totalSales;
    if (statsCommission) statsCommission.textContent = `R$ ${totalCommission.toFixed(2).replace('.', ',')}`;
    if (statsPending) statsPending.textContent = `R$ ${pendingCommission.toFixed(2).replace('.', ',')}`;
}

// Abrir modal de criação de afiliado
function openCreateAffiliateModal() {
    const modal = document.getElementById('createAffiliateModal');
    const title = document.getElementById('affiliateModalTitle');
    const form = document.getElementById('createAffiliateForm');
    const editId = document.getElementById('affiliateEditId');
    
    if (modal) {
        modal.classList.remove('hidden');
        if (title) title.textContent = 'Criar Novo Afiliado';
        if (form) form.reset();
        if (editId) editId.value = '';
    }
}

// Fechar modal de criação de afiliado
function closeCreateAffiliateModal() {
    const modal = document.getElementById('createAffiliateModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

// Criar/editar afiliado
async function createOrUpdateAffiliate(event) {
    if (event) event.preventDefault();
    
    const email = document.getElementById('affiliateEmail')?.value?.trim();
    const commissionRateEvents = parseFloat(document.getElementById('affiliateCommissionRateEvents')?.value || 0);
    const commissionRateProducts = parseFloat(document.getElementById('affiliateCommissionRateProducts')?.value || 0);
    const status = document.getElementById('affiliateStatus')?.value || 'active';
    const editId = document.getElementById('affiliateEditId')?.value;
    
    if (!email) {
        showToast('error', 'Email é obrigatório', 'Erro');
        return;
    }
    
    if (commissionRateEvents < 0 || commissionRateEvents > 100) {
        showToast('error', 'Percentual de comissão de eventos deve estar entre 0 e 100', 'Erro');
        return;
    }
    
    if (commissionRateProducts < 0 || commissionRateProducts > 100) {
        showToast('error', 'Percentual de comissão de produtos deve estar entre 0 e 100', 'Erro');
        return;
    }
    
    try {
        const { collection, query, where, getDocs, doc, updateDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        
        // Buscar usuário pelo email
        const usersRef = collection(window.firebaseDb, 'users');
        const q = query(usersRef, where('email', '==', email));
        const snapshot = await getDocs(q);
        
        if (snapshot.empty) {
            showToast('error', 'Usuário não encontrado. O usuário deve estar cadastrado no sistema primeiro.', 'Erro');
            return;
        }
        
        const userDoc = snapshot.docs[0];
        const userId = userDoc.id;
        
        // Atualizar role e dados do afiliado
        await updateDoc(doc(window.firebaseDb, 'users', userId), {
            role: 'Afiliado',
            commissionRate: commissionRateEvents, // Mantido para compatibilidade (usa eventos como padrão)
            commissionRateEvents: commissionRateEvents,
            commissionRateProducts: commissionRateProducts,
            affiliateStatus: status,
            updatedAt: new Date()
        });
        
        await logAdminAction('manage_affiliate', editId ? `Editou afiliado ${email}` : `Criou afiliado ${email} com ${commissionRateEvents}% eventos e ${commissionRateProducts}% produtos`);
        
        // Recarregar dados
        await loadAffiliates();
        
        // Fechar modal
        closeCreateAffiliateModal();
        
        showToast('success', editId ? 'Afiliado atualizado com sucesso!' : 'Afiliado criado com sucesso!', 'Sucesso');
    } catch (error) {
        console.error('❌ Erro ao criar/editar afiliado:', error);
        showToast('error', 'Erro ao criar/editar afiliado: ' + error.message, 'Erro');
    }
}

// Editar afiliado
function editAffiliate(affiliateId) {
    const affiliate = affiliatesData.find(a => a.id === affiliateId);
    if (!affiliate) return;
    
    const modal = document.getElementById('createAffiliateModal');
    const title = document.getElementById('affiliateModalTitle');
    const emailInput = document.getElementById('affiliateEmail');
    const commissionEventsInput = document.getElementById('affiliateCommissionRateEvents');
    const commissionProductsInput = document.getElementById('affiliateCommissionRateProducts');
    const statusSelect = document.getElementById('affiliateStatus');
    const editId = document.getElementById('affiliateEditId');
    
    if (modal) {
        modal.classList.remove('hidden');
        if (title) title.textContent = 'Editar Afiliado';
        if (emailInput) emailInput.value = affiliate.email;
        if (commissionEventsInput) commissionEventsInput.value = affiliate.commissionRateEvents || affiliate.commissionRate || 10;
        if (commissionProductsInput) commissionProductsInput.value = affiliate.commissionRateProducts || affiliate.commissionRate || 10;
        if (statusSelect) statusSelect.value = affiliate.status;
        if (editId) editId.value = affiliateId;
    }
}

// Ver detalhes do afiliado
function viewAffiliateDetails(affiliateId) {
    const affiliate = affiliatesData.find(a => a.id === affiliateId);
    const sales = affiliateSalesData.filter(s => s.affiliateId === affiliateId);
    
    if (!affiliate) return;
    
    const totalSales = sales.length;
    const totalCommission = sales.reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
    const pendingCommission = sales
        .filter(s => s.status === 'pending')
        .reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
    
    alert(`Detalhes do Afiliado:\n\n` +
          `Nome: ${affiliate.name}\n` +
          `Email: ${affiliate.email}\n` +
          `Comissão: ${affiliate.commissionRate}%\n` +
          `Status: ${affiliate.status === 'active' ? 'Ativo' : 'Inativo'}\n` +
          `Total de Vendas: ${totalSales}\n` +
          `Comissão Total: R$ ${totalCommission.toFixed(2)}\n` +
          `Comissão Pendente: R$ ${pendingCommission.toFixed(2)}`);
}

// Aprovar comissão de afiliado
async function approveAffiliateCommission(saleId) {
    if (!confirm('Deseja aprovar e marcar esta comissão como paga?')) {
        return;
    }
    
    try {
        const { doc, updateDoc, collection, addDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        
        await updateDoc(doc(window.firebaseDb, 'affiliate_sales', saleId), {
            status: 'paid',
            paidAt: new Date(),
            paidBy: window.adminRoleLower || 'admin'
        });
        
        // Criar registro de comissão paga
        const sale = affiliateSalesData.find(s => s.id === saleId);
        if (sale) {
            await addDoc(collection(window.firebaseDb, 'affiliate_commissions'), {
                affiliateId: sale.affiliateId,
                saleId: saleId,
                amount: sale.commissionAmount,
                status: 'paid',
                paymentMethod: 'Manual',
                createdAt: new Date(),
                paidAt: new Date()
            });
        }
        
        await logAdminAction('approve_commission', `Aprovou comissão de venda ${saleId}`);
        
        // Recarregar dados
        await loadAffiliateSales();
        await loadAffiliates();
        
        alert('Comissão aprovada e marcada como paga!');
    } catch (error) {
        console.error('❌ Erro ao aprovar comissão:', error);
        alert('Erro ao aprovar comissão: ' + error.message);
    }
}

// Expor funções globalmente
window.loadAffiliates = loadAffiliates;
window.openCreateAffiliateModal = openCreateAffiliateModal;
window.closeCreateAffiliateModal = closeCreateAffiliateModal;
window.editAffiliate = editAffiliate;
window.viewAffiliateDetails = viewAffiliateDetails;
window.approveAffiliateCommission = approveAffiliateCommission;

// Configurar formulário e filtros
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('createAffiliateForm');
    if (form) {
        form.addEventListener('submit', createOrUpdateAffiliate);
    }
    
    // Configurar filtros de vendas
    const affiliateFilter = document.getElementById('affiliateSalesFilter');
    const statusFilter = document.getElementById('affiliateSalesStatusFilter');
    
    if (affiliateFilter) {
        affiliateFilter.addEventListener('change', () => {
            renderAffiliateSalesTable();
        });
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', () => {
            renderAffiliateSalesTable();
        });
    }
});

// Configurar event listeners dos filtros de cupons
function setupCouponUsageFilters() {
  // Aguardar um pouco para garantir que o DOM está pronto
  setTimeout(() => {
    try {
      const periodSel = document.getElementById('couponUsagePeriod');
      const ctxSel = document.getElementById('couponUsageContext');
      const codeSel = document.getElementById('couponUsageCodeFilter');
      const productInput = document.getElementById('couponUsageProductFilter');
      const applyBtn = document.getElementById('couponUsageApply');
      const resetBtn = document.getElementById('couponUsageReset');
      const exportBtn = document.getElementById('couponUsageExport');
      
      if (!applyBtn || !resetBtn || !exportBtn) {
        console.warn('Elementos de filtro de cupons não encontrados, tentando novamente...');
        // Tentar novamente após mais tempo
        setTimeout(setupCouponUsageFilters, 500);
        return;
      }
      
      // Função para aplicar filtros
      const applyFn = (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        couponUsageFilters.period = (periodSel?.value || '7d');
        couponUsageFilters.context = (ctxSel?.value || 'all');
        couponUsageFilters.couponCode = (codeSel?.value || 'all');
        couponUsageFilters.productName = (productInput?.value || '').trim();
        
        applyCouponUsageFilters();
      };
      
      // Função para resetar filtros
      const resetFn = (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        if (periodSel) periodSel.value = '7d';
        if (ctxSel) ctxSel.value = 'all';
        if (codeSel) codeSel.value = 'all';
        if (productInput) productInput.value = '';
        couponUsageFilters = { period: '7d', context: 'all', couponCode: 'all', productName: '' };
        
        applyCouponUsageFilters();
      };
      
      // Função para exportar
      const exportFn = (e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        exportCouponUsageData();
      };
      
      // Remover listeners antigos antes de adicionar novos
      const newApplyBtn = applyBtn.cloneNode(true);
      const newResetBtn = resetBtn.cloneNode(true);
      const newExportBtn = exportBtn.cloneNode(true);
      
      applyBtn.parentNode.replaceChild(newApplyBtn, applyBtn);
      resetBtn.parentNode.replaceChild(newResetBtn, resetBtn);
      exportBtn.parentNode.replaceChild(newExportBtn, exportBtn);
      
      // Adicionar listeners aos novos elementos
      newApplyBtn.addEventListener('click', applyFn);
      newResetBtn.addEventListener('click', resetFn);
      newExportBtn.addEventListener('click', exportFn);
      
      // Configurar listeners dos selects e input
      if (periodSel) {
        periodSel.removeEventListener('change', applyFn);
        periodSel.addEventListener('change', applyFn);
      }
      if (ctxSel) {
        ctxSel.removeEventListener('change', applyFn);
        ctxSel.addEventListener('change', applyFn);
      }
      if (codeSel) {
        codeSel.removeEventListener('change', applyFn);
        codeSel.addEventListener('change', applyFn);
      }
      if (productInput) {
        // Remover listener antigo se existir
        const oldHandler = productInput.oninput;
        productInput.oninput = null;
        productInput.addEventListener('input', () => {
          couponUsageFilters.productName = productInput.value.trim();
          applyCouponUsageFilters();
        });
      }
      
      
    } catch (error) {
      console.error('❌ Erro ao configurar filtros de cupons:', error);
    }
  }, 100);
}
// Listar pedidos de camisa e marcar envio
async function loadShirtOrders(){
  try{
    const body = document.getElementById('shirtOrdersBody');
    if (!body) return;
    const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const snap = await getDocs(collection(window.firebaseDb,'orders'));
    const rows = [];
    snap.forEach(d=>{
      const data = d.data();
      const t = String(data.title||data.item||'').toLowerCase();
      if (t.includes('camisa')){
        const shipping = data.shipping || (data.productOptions && data.productOptions.delivery) || {};
        const status = data.shippingStatus || (data.shirtShipped?'shipped':'pending') || 'pending';
        const addr = shipping.address ? `${shipping.address}, ${shipping.number||''} - ${shipping.district||''} - ${shipping.city||''}/${shipping.state||''}` : '';
        const nameOnShirt = (shipping.shirtName) || (data.productOptions && data.productOptions.name) || '';
        const extra = nameOnShirt ? ` • Nome na camisa: ${nameOnShirt}` : '';
        rows.push(`
          <tr class="border-b border-gray-100">
            <td class="py-2 px-2">${data.customer||data.buyerEmail||data.email||''}</td>
            <td class="py-2 px-2">${data.title||''}</td>
            <td class="py-2 px-2">${addr ? addr + extra : '<span class=\'text-gray-400\'>Sem dados</span>'}</td>
            <td class="py-2 px-2">${status==='shipped' ? '<span class="text-green-600">Enviado</span>' : '<span class="text-yellow-600">Aguardando</span>'}</td>
            <td class="py-2 px-2">
              <button class="px-2 py-1 border rounded mr-2" onclick="openShirtOrder('${d.id}')">Abrir</button>
              ${status==='shipped' ? '' : `<button class=\"px-2 py-1 bg-green-600 text-white rounded\" onclick=\"markShirtAsShipped('${d.id}')\">Marcar enviado</button>`}
            </td>
          </tr>
        `);
      }
    });
    body.innerHTML = rows.length? rows.join('') : '<tr><td colspan="5" class="py-6 text-center text-gray-500">Nenhum pedido de camisa encontrado</td></tr>';
  }catch(e){
    const body = document.getElementById('shirtOrdersBody');
    if (body) body.innerHTML = '<tr><td colspan="5" class="py-6 text-center text-red-500">Erro ao carregar</td></tr>';
  }
}

async function markShirtAsShipped(orderId){
  try{
    const { doc, updateDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    await updateDoc(doc(collection(window.firebaseDb,'orders'), orderId),{
      shippingStatus: 'shipped',
      shippedAt: new Date()
    });
    await loadShirtOrders();
  }catch(e){
    alert('Erro ao marcar enviado');
  }
}
window.markShirtAsShipped = markShirtAsShipped;
window.loadShirtOrders = loadShirtOrders;
function closeShirtOrderModal(){
  const m = document.getElementById('shirtOrderModal');
  if (m){ m.classList.add('hidden'); m.classList.remove('flex'); }
}
async function openShirtOrder(orderId){
  try{
    const { doc, getDoc, collection } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const snap = await getDoc(doc(collection(window.firebaseDb,'orders'), orderId));
    if (!snap.exists()) return;
    const o = snap.data();
    const m = document.getElementById('shirtOrderModal');
    if (!m) return;
    const po = o.productOptions || {};
    const shipping = o.shipping || po.delivery || {};
    const cityUf = [shipping.city, shipping.state].filter(Boolean).join('/');
    const status = o.shippingStatus === 'shipped' || o.shirtShipped ? 'Enviado' : 'Aguardando';
    // preencher campos
    const set = (id, html) => { const el = m.querySelector('#'+id); if (el) el.innerHTML = html || ''; };
    set('shirtOrderTitle', o.title || o.item || '-');
    set('shirtOrderCustomer', o.customerName || o.customer || o.buyerEmail || '-');
    set('shirtOrderEmail', o.buyerEmail || o.customer || '-');
    set('shirtOrderStatus', status);
    set('shirtOrderId', orderId);
    set('shirtOrderAmount', (o.amount!=null? Number(o.amount) : 0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}));
    set('shirtOrderSize', po.size || '-');
    set('shirtOrderNameOnShirt', (shipping.shirtName || po.name || '-') );
    set('shipNameVal', shipping.name || '');
    set('shipCpfVal', shipping.cpf || '');
    set('shipCepVal', shipping.cep || '');
    set('shipAddressVal', shipping.address || '');
    set('shipNumberVal', shipping.number || '');
    set('shipComplementVal', shipping.complement || '');
    set('shipDistrictVal', shipping.district || '');
    set('shipCityVal', shipping.city || '');
    set('shipStateVal', shipping.state || '');
    // abrir
    m.classList.remove('hidden'); m.classList.add('flex');
  }catch(_){ }
}
window.openShirtOrder = openShirtOrder;
window.closeShirtOrderModal = closeShirtOrderModal;
window.openCreateCouponModal = openCreateCouponModal;
window.closeCreateCouponModal = closeCreateCouponModal;
window.createCoupon = createCoupon;
window.editCoupon = editCoupon;
window.toggleCouponStatus = toggleCouponStatus;
window.deleteCoupon = deleteCoupon;

// Carregar usuários quando o admin for inicializado
document.addEventListener('DOMContentLoaded', function() {
  // Aguardar Firebase E usuário autenticado antes de carregar dados protegidos
  const waitForFirebaseAndAuth = () => {
    if (window.firebaseReady && window.firebaseDb && window.firebaseAuth) {
      const { onAuthStateChanged } = window.firebaseAuthModule || {};
      // Usar import dinâmico para aguardar auth state
      import('https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js').then(({ onAuthStateChanged }) => {
        onAuthStateChanged(window.firebaseAuth, (user) => {
          if (user) {
            loadUsersForTables();
            loadAdminWhatsAppLinks();
          }
        });
      }).catch(() => {});
    } else {
      setTimeout(waitForFirebaseAndAuth, 150);
    }
  };
  waitForFirebaseAndAuth();
  
  // Event listener para formulário de criação de cupons
  const createCouponForm = document.getElementById('createCouponForm');
  if (createCouponForm) {
    createCouponForm.addEventListener('submit', createCoupon);
  }
  
  // Listener de formAddTeam já registrado via onsubmit dentro de initAdmin — não duplicar aqui
  
  // Listeners de filtros do uso de cupons
  // Event listeners já configurados acima na função initAdmin
});

// ===== Reset de Dados (Perigoso) =====
function openResetDataModal(){
  const m = document.getElementById('resetDataModal');
  if (m){ m.classList.remove('hidden'); m.classList.add('flex'); }
}
function closeResetDataModal(){
  const m = document.getElementById('resetDataModal');
  if (m){ m.classList.add('hidden'); m.classList.remove('flex'); }
}
async function deleteCollectionDocs(colName){
  const log = (t)=>{ const el = document.getElementById('resetDataLog'); if (el) el.innerHTML += `<div>${t}</div>`; };
  try{
    const { collection, getDocs, deleteDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const snap = await getDocs(collection(window.firebaseDb, colName));
    let count = 0;
    for (const d of snap.docs){
      try{ await deleteDoc(doc(window.firebaseDb, colName, d.id)); count++; }catch(e){ log(`Erro ao apagar ${colName}/${d.id}`); }
    }
    log(`✔ ${colName}: ${count} documentos apagados.`);
  }catch(e){
    log(`❌ Falha ao apagar coleção ${colName}`);
  }
}
async function zeroUserTokens(){
  const log = (t)=>{ const el = document.getElementById('resetDataLog'); if (el) el.innerHTML += `<div>${t}</div>`; };
  try{
    const { collection, getDocs, updateDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const users = await getDocs(collection(window.firebaseDb,'users'));
    let count = 0;
    for (const u of users.docs){
      try{ await updateDoc(doc(window.firebaseDb,'users',u.id), { tokens: 0 }); count++; }catch(_){ }
    }
    log(`✔ users.tokens zerados (${count} usuários).`);
  }catch(e){ log('❌ Falha ao zerar tokens'); }
}
async function performDataReset(){
  const logEl = document.getElementById('resetDataLog'); if (logEl) logEl.innerHTML = '';
  const confirmText = (document.getElementById('resetConfirm')?.value||'').trim().toUpperCase();
  if (confirmText !== 'ZERAR'){ alert('Digite ZERAR para confirmar.'); return; }
  const wants = {
    orders: document.getElementById('resetOrders')?.checked,
    regs: document.getElementById('resetRegistrations')?.checked,
    couponUsage: document.getElementById('resetCouponUsage')?.checked,
    news: document.getElementById('resetNews')?.checked,
  };
  if (!wants.orders && !wants.regs && !wants.couponUsage && !wants.news){
    alert('Selecione pelo menos uma opção.'); return;
  }
  const tasks = [];
  if (wants.orders) tasks.push(deleteCollectionDocs('orders'));
  if (wants.regs) tasks.push(deleteCollectionDocs('registrations'));
  if (wants.couponUsage) tasks.push(deleteCollectionDocs('couponUsage'));
  if (wants.news) tasks.push(deleteCollectionDocs('news'));
  await Promise.allSettled(tasks);
  const log = (t)=>{ const el = document.getElementById('resetDataLog'); if (el) el.innerHTML += `<div>${t}</div>`; };
  log('<b>Concluído.</b> Atualize as seções para ver o efeito.');
}
window.openResetDataModal = openResetDataModal;
window.closeResetDataModal = closeResetDataModal;
window.performDataReset = performDataReset;

// Navegação rápida entre seções a partir do Gerenciamento de Tokens
function jumpToSelectedSection(selectId){
  try{
    const sel = document.getElementById(selectId);
    const target = sel && sel.value ? document.getElementById(sel.value) : null;
    if (target){ target.scrollIntoView({ behavior:'smooth', block:'start' }); }
  }catch(_){ }
}
window.jumpToSelectedSection = jumpToSelectedSection;

// ==================== PASSE BOOYAH CONTROLS ====================
async function loadPasseBooyahControls(){
  try{
    const tbody = document.getElementById('booyahTbody');
    const countEl = document.getElementById('booyahCount');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="5" class="py-6 text-center text-gray-500">Carregando registros...</td></tr>';

    const { collection, query, where, orderBy, getDocs, updateDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');

    // Buscar pedidos de Passe Booyah aprovados/pendentes de confirmação
    const ordersRef = collection(window.firebaseDb, 'orders');
    const q = query(ordersRef, where('productId','==','passe-booyah'));
    const snap = await getDocs(q);

    const rows = [];
    let total = 0;
    snap.forEach(d => {
      const o = d.data() || {};
      const status = (o.status||'').toLowerCase();
      const isPaid = status==='paid' || status==='approved' || status==='confirmed';
      // Mostrar todos, mas com ação apenas para pagos não confirmados
      const confirmed = !!o.booyahConfirmed;
      const playerId = (o.productOptions && (o.productOptions.playerId || o.productOptions.id || o.playerId)) || '';
      rows.push({ id:d.id, name:o.customerName||'-', email:o.customer||o.buyerEmail||'-', playerId, confirmed, canConfirm: isPaid && !confirmed });
      total++;
    });

    if (countEl) countEl.textContent = `${total} registros`;

    if (rows.length === 0){
      tbody.innerHTML = '<tr><td colspan="5" class="py-6 text-center text-gray-500">Nenhum registro encontrado</td></tr>';
      return;
    }

    tbody.innerHTML = rows.map(r => `
      <tr class="border-b border-gray-100">
        <td class="py-2 px-2">${r.name}</td>
        <td class="py-2 px-2">${r.email}</td>
        <td class="py-2 px-2">${r.playerId || '<span class="text-gray-400">—</span>'}</td>
        <td class="py-2 px-2">${r.confirmed ? '<span class="px-2 py-1 text-[10px] rounded-full bg-green-100 text-green-700">Confirmado</span>' : '<span class="px-2 py-1 text-[10px] rounded-full bg-yellow-100 text-yellow-700">Pendente</span>'}</td>
        <td class="py-2 px-2">
          ${r.canConfirm ? `<button class="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded text-xs" onclick="confirmPasseBooyah('${r.id}')">Confirmar</button>` : '<span class="text-gray-400 text-xs">—</span>'}
        </td>
      </tr>
    `).join('');

    // Expor função no escopo global
    window.confirmPasseBooyah = async function(orderId){
      try{
        const ok = confirm('Confirmar entrega do Passe Booyah?');
        if (!ok) return;
        const ref = doc(window.firebaseDb, 'orders', orderId);
        await updateDoc(ref, { booyahConfirmed: true, booyahConfirmedAt: new Date() });
        await loadPasseBooyahControls();
      }catch(err){
        console.error('Erro ao confirmar Passe Booyah:', err);
        alert('Erro ao confirmar. Tente novamente.');
      }
    }
  }catch(err){
    console.error('Erro ao carregar Passe Booyah:', err);
  }
}

// ==================== TOKEN TOTALS RECOMPUTE ====================
async function recomputeTokenTotals(){
  try{
    const { collection, getDocsFromServer } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');

    // 1) Total de tokens comprados: somar explicitamente a quantidade do título/item
    const ordersSnap = await getDocsFromServer(collection(window.firebaseDb,'orders'));
    let totalPurchased = 0;
    ordersSnap.forEach(d => {
      const o = d.data() || {};
      const title = (o.title||'') + ' ' + (o.item||'') + ' ' + (o.description||'');
      const lower = title.toLowerCase();
      if (lower.includes('token') && (o.status==='paid' || o.status==='approved' || o.status==='confirmed')){
        // Busca padrão: "NN Token" no texto
        const m = title.match(/(\d+)\s*Token/i);
        const qty = m ? parseInt(m[1],10) : (Number(o.quantity)||1);
        totalPurchased += isFinite(qty) ? qty : 0;
      }
    });

    // 2) Total de tokens usados: contar registrations com paidWithTokens
    const regsSnap = await getDocsFromServer(collection(window.firebaseDb,'registrations'));
    let totalUsed = 0;
    regsSnap.forEach(d => {
      const r = d.data() || {};
      if (r.paidWithTokens === true){
        totalUsed += Number(r.tokensUsed || r.tokenCost || 1);
      }
    });

    // 3) Atualizar UI
    const purchasedEl = document.getElementById('totalTokensPurchased');
    const usedEl = document.getElementById('totalTokensUsed');
    if (purchasedEl) purchasedEl.textContent = totalPurchased;
    if (usedEl) usedEl.textContent = totalUsed;

    // 4) Atualizar contagem de compras (cards e paginação)
    const countEl = document.getElementById('tokensCount');
    if (countEl) countEl.textContent = `${totalPurchased} compras`;

    
  }catch(err){
    console.error('❌ Error recomputing tokens:', err);
  }
}

// ==================== GERENCIAMENTO DE LINKS DO WHATSAPP ====================

// Função para mostrar notificações
function showNotification(message, type = 'info') {
  // Criar elemento de notificação
  const notification = document.createElement('div');
  notification.className = `fixed top-4 right-4 z-50 px-4 py-3 rounded-lg shadow-lg max-w-sm ${
    type === 'success' ? 'bg-green-500 text-white' :
    type === 'error' ? 'bg-red-500 text-white' :
    type === 'warning' ? 'bg-yellow-500 text-black' :
    'bg-blue-500 text-white'
  }`;
  notification.textContent = message;
  
  // Adicionar ao DOM
  document.body.appendChild(notification);
  
  // Remover após 3 segundos
  setTimeout(() => {
    if (notification.parentNode) {
      notification.parentNode.removeChild(notification);
    }
  }, 3000);
}

let currentEditingWhatsAppLink = null;

// Abrir modal de links do WhatsApp
function openWhatsAppLinksModal() {
  const modal = document.getElementById('modalWhatsAppLinks');
  if (modal) {
    modal.classList.remove('hidden');
    // Não recarregar aqui, já foi carregado automaticamente
  }
}

// Fechar modal de links do WhatsApp
function closeWhatsAppLinksModal() {
  const modal = document.getElementById('modalWhatsAppLinks');
  if (modal) {
    modal.classList.add('hidden');
    clearWhatsAppLinkForm();
  }
}

// Limpar formulário de link do WhatsApp
function clearWhatsAppLinkForm() {
  currentEditingWhatsAppLink = null;
  document.getElementById('whatsappLinkFormTitle').textContent = 'Adicionar Novo Link';
  document.getElementById('whatsappLinkForm').reset();
}

// Carregar links do WhatsApp do Firestore
async function loadAdminWhatsAppLinks() {
  try {
    if (!window.firebaseDb) {
      console.warn('Firebase não inicializado ainda');
      return;
    }
    
    const { collection, getDocs, orderBy, query } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    
    const whatsappLinksRef = collection(window.firebaseDb, 'whatsapp_links');
    const q = query(whatsappLinksRef, orderBy('eventType', 'asc'));
    const snapshot = await getDocs(q);
    
    const links = [];
    snapshot.forEach(doc => {
      links.push({ id: doc.id, ...doc.data() });
    });
    
    // Ordenar manualmente por eventType e depois por schedule
    links.sort((a, b) => {
      if (a.eventType !== b.eventType) {
        return a.eventType.localeCompare(b.eventType);
      }
      // Se eventType for igual, ordenar por schedule (null primeiro)
      if (!a.schedule && !b.schedule) return 0;
      if (!a.schedule) return -1;
      if (!b.schedule) return 1;
      return a.schedule.localeCompare(b.schedule);
    });
    
    // Armazenar todos os links para filtro
    allWhatsAppLinks = links;
    
    // Configurar filtros se ainda não foram configurados
    if (!window.whatsappFiltersSetup) {
      setupWhatsAppFilters();
      window.whatsappFiltersSetup = true;
    }
    
    renderWhatsAppLinksTable(links);
    renderWhatsAppLinksList(links);
    
  } catch (error) {
    console.error('❌ Erro ao carregar links do WhatsApp:', error);
    showNotification('Erro ao carregar links do WhatsApp', 'error');
  }
}

// Renderizar tabela de links do WhatsApp
function renderWhatsAppLinksTable(links) {
  const tbody = document.getElementById('whatsappLinksTableBody');
  if (!tbody) return;
  
  if (links.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-gray-500 py-4">Nenhum link cadastrado</td></tr>';
    return;
  }
  
  tbody.innerHTML = links.map(link => `
    <tr class="border-b border-gray-100 hover:bg-gray-50">
      <td class="py-2 px-3">
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
          ${getEventTypeLabel(link.eventType)}
        </span>
      </td>
      <td class="py-2 px-3">${link.schedule || 'Todos'}</td>
      <td class="py-2 px-3">
        <a href="${link.link}" target="_blank" class="text-green-600 hover:text-green-800 text-xs break-all" title="${link.link}">
          ${link.link}
        </a>
      </td>
      <td class="py-2 px-3">
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${link.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
          ${link.status === 'active' ? 'Ativo' : 'Inativo'}
        </span>
      </td>
      <td class="py-2 px-3">
        <div class="flex gap-2">
          <button onclick="editWhatsAppLink('${link.id}')" class="text-blue-600 hover:text-blue-800 text-xs">
            <i class="fas fa-edit"></i>
          </button>
          <button onclick="deleteWhatsAppLink('${link.id}')" class="text-red-600 hover:text-red-800 text-xs">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}
// Renderizar lista de links do WhatsApp no modal
function renderWhatsAppLinksList(links) {
  const container = document.getElementById('whatsappLinksList');
  if (!container) return;
  
  if (links.length === 0) {
    container.innerHTML = '<div class="text-center text-gray-500 py-4">Nenhum link cadastrado</div>';
    return;
  }
  
  container.innerHTML = links.map(link => `
    <div class="bg-white border border-gray-200 rounded-lg p-4">
      <div class="flex items-center justify-between">
        <div class="flex-1">
          <div class="flex items-center gap-3 mb-2">
            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              ${getEventTypeLabel(link.eventType)}
            </span>
            <span class="text-sm text-gray-600">${link.schedule || 'Todos os horários'}</span>
            <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${link.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
              ${link.status === 'active' ? 'Ativo' : 'Inativo'}
            </span>
          </div>
          <p class="text-sm text-gray-800 mb-1">${link.description || 'Sem descrição'}</p>
          <a href="${link.link}" target="_blank" class="text-green-600 hover:text-green-800 text-sm break-all" title="${link.link}">
            ${link.link}
          </a>
        </div>
        <div class="flex gap-2 ml-4">
          <button onclick="editWhatsAppLink('${link.id}')" class="px-3 py-1 bg-blue-600 text-white rounded text-xs hover:bg-blue-700">
            <i class="fas fa-edit mr-1"></i>Editar
          </button>
          <button onclick="deleteWhatsAppLink('${link.id}')" class="px-3 py-1 bg-red-600 text-white rounded text-xs hover:bg-red-700">
            <i class="fas fa-trash mr-1"></i>Excluir
          </button>
        </div>
      </div>
    </div>
  `).join('');
}

// Obter label do tipo de evento
function getEventTypeLabel(eventType) {
  const labels = {
    'xtreino-tokens': 'XTreino Tokens',
    'xtreino-gratuito': 'XTreino Gratuito',
    'modo-liga': 'Modo Liga',
    'camp-freitas': 'Camp Freitas',
    'semanal-freitas': 'Semanal Freitas',
    'treino': 'Treino Normal'
  };
  return labels[eventType] || eventType;
}

// Salvar link do WhatsApp
async function saveWhatsAppLink() {
  try {
    if (!window.firebaseDb) {
      showNotification('Firebase não inicializado ainda', 'error');
      return;
    }
    
    const eventType = document.getElementById('whatsappEventType').value;
    const schedule = document.getElementById('whatsappSchedule').value.trim();
    const link = document.getElementById('whatsappLink').value.trim();
    const status = document.getElementById('whatsappStatus').value;
    const description = document.getElementById('whatsappDescription').value.trim();
    
    if (!eventType || !link) {
      showNotification('Preencha todos os campos obrigatórios', 'error');
      return;
    }
    
    const { collection, addDoc, updateDoc, doc, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    
    const linkData = {
      eventType,
      schedule: schedule || null,
      link,
      status,
      description: description || null,
      updatedAt: serverTimestamp()
    };
    
    if (currentEditingWhatsAppLink) {
      // Atualizar link existente
      const linkRef = doc(window.firebaseDb, 'whatsapp_links', currentEditingWhatsAppLink);
      await updateDoc(linkRef, linkData);
      showNotification('Link atualizado com sucesso!', 'success');
    } else {
      // Criar novo link
      linkData.createdAt = serverTimestamp();
      await addDoc(collection(window.firebaseDb, 'whatsapp_links'), linkData);
      showNotification('Link criado com sucesso!', 'success');
    }
    
    // Limpar cache para forçar atualização
    whatsappLinksCache.clear();
    
    
    clearWhatsAppLinkForm();
    loadAdminWhatsAppLinks();
    
  } catch (error) {
    console.error('❌ Erro ao salvar link do WhatsApp:', error);
    showNotification('Erro ao salvar link do WhatsApp', 'error');
  }
}

// Editar link do WhatsApp
async function editWhatsAppLink(linkId) {
  try {
    
    
    if (!window.firebaseDb) {
      showNotification('Firebase não inicializado ainda', 'error');
      return;
    }
    
    const { doc, getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    
    const linkRef = doc(window.firebaseDb, 'whatsapp_links', linkId);
    const linkSnap = await getDoc(linkRef);
    
    if (linkSnap.exists()) {
      const linkData = linkSnap.data();
      
      
      currentEditingWhatsAppLink = linkId;
      
      // Preencher o formulário
      document.getElementById('whatsappLinkFormTitle').textContent = 'Editar Link';
      document.getElementById('whatsappEventType').value = linkData.eventType || '';
      document.getElementById('whatsappSchedule').value = linkData.schedule || '';
      document.getElementById('whatsappLink').value = linkData.link || '';
      document.getElementById('whatsappStatus').value = linkData.status || 'active';
      document.getElementById('whatsappDescription').value = linkData.description || '';
      
      // Abrir o modal
      openWhatsAppLinksModal();
      
      
    } else {      
      showNotification('Link não encontrado', 'error');
    }
    
  } catch (error) {
    console.error('❌ Erro ao carregar link para edição:', error);
    showNotification('Erro ao carregar link para edição', 'error');
  }
}

// Excluir link do WhatsApp
async function deleteWhatsAppLink(linkId) {
  if (!confirm('Tem certeza que deseja excluir este link?')) {
    return;
  }
  
  try {
    if (!window.firebaseDb) {
      showNotification('Firebase não inicializado ainda', 'error');
      return;
    }
    
    const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    
    const linkRef = doc(window.firebaseDb, 'whatsapp_links', linkId);
    await deleteDoc(linkRef);
    
    showNotification('Link excluído com sucesso!', 'success');
    loadAdminWhatsAppLinks();
    
  } catch (error) {
    console.error('❌ Erro ao excluir link do WhatsApp:', error);
    showNotification('Erro ao excluir link do WhatsApp', 'error');
  }
}

// Cache para links do WhatsApp (com TTL)
let whatsappLinksCache = new Map();
const CACHE_TTL = 30000; // 30 segundos

// Função para obter link do WhatsApp dinamicamente
async function getWhatsAppLink(eventType, schedule = null) {
  try {
    

    if (!window.firebaseDb) {
      console.warn('⚠️ Firebase não inicializado ainda');
      return 'https://chat.whatsapp.com/SEU_GRUPO_PADRAO';
    }

    // Normalizações para evitar desencontro de formatos
    const normalizeType = (t) => String(t || '')
      .toLowerCase()
      .trim()
      .replace(/\s+/g, '-')
      .replace('xtreino-gratuito', 'xtreino-gratuito')
      .replace('xtreino-tokens', 'xtreino-tokens')
      .replace('modo liga', 'modo-liga')
      .replace('camp', 'camp-freitas');

    const normalizeHour = (h) => {
      if (!h) return null;
      const s = String(h).toLowerCase().trim();
      // extrai apenas a hora (aceita "Sexta - 18h", "18", "18h", "18:00")
      const m = s.match(/(\d{1,2})/);
      return m ? `${parseInt(m[1], 10)}h` : null;
    };

    const type = normalizeType(eventType);
    const hour = normalizeHour(schedule);

    // Verificar cache primeiro (com chaves normalizadas)
    const cacheKey = `${type}_${hour || 'general'}`;
    const cached = whatsappLinksCache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp) < CACHE_TTL) {
      
      return cached.link;
    }

    const { collection, getDocs, query, where } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');

    const whatsappLinksRef = collection(window.firebaseDb, 'whatsapp_links');

    // 1) Tenta link específico para o horário (schedule = '18h')
    if (hour) {
      
      const specificQuery = query(
        whatsappLinksRef,
        where('eventType', '==', type),
        where('schedule', '==', hour),
        where('status', '==', 'active')
      );
      const specificSnapshot = await getDocs(specificQuery);

      

      if (!specificSnapshot.empty) {
        const link = specificSnapshot.docs[0].data().link;
        

        whatsappLinksCache.set(cacheKey, { link, timestamp: Date.now() });
        return link;
      }
    }

    // 2) Tenta link geral eventType + schedule = null
    
    const generalQuery = query(
      whatsappLinksRef,
      where('eventType', '==', type),
      where('schedule', '==', null),
      where('status', '==', 'active')
    );
    const generalSnapshot = await getDocs(generalQuery);

    if (!generalSnapshot.empty) {
      const link = generalSnapshot.docs[0].data().link;
      
      whatsappLinksCache.set(cacheKey, { link, timestamp: Date.now() });
      return link;
    }

    // 3) Alguns cadastros podem usar string vazia em vez de null para "sem horário"
    
    const generalEmptyQuery = query(
      whatsappLinksRef,
      where('eventType', '==', type),
      where('schedule', '==', ''),
      where('status', '==', 'active')
    );
    const generalEmptySnapshot = await getDocs(generalEmptyQuery);

    if (!generalEmptySnapshot.empty) {
      const link = generalEmptySnapshot.docs[0].data().link;
      
      whatsappLinksCache.set(cacheKey, { link, timestamp: Date.now() });
      return link;
    }

    // 4) Fallback para links padrão se não encontrar no Firestore
    const defaultLinks = {
      'xtreino-tokens': 'https://chat.whatsapp.com/SEU_GRUPO_TOKENS',
      'xtreino-gratuito': 'https://chat.whatsapp.com/SEU_GRUPO_GRATUITO',
      'modo-liga': 'https://chat.whatsapp.com/SEU_GRUPO_MODO_LIGA',
      'camp-freitas': 'https://chat.whatsapp.com/SEU_GRUPO_CAMP_FREITAS',
      'semanal-freitas': 'https://chat.whatsapp.com/SEU_GRUPO_SEMANAL',
      'treino': 'https://chat.whatsapp.com/SEU_GRUPO_TREINO'
    };

    const fallbackLink = defaultLinks[type] || 'https://chat.whatsapp.com/SEU_GRUPO_PADRAO';
    

    whatsappLinksCache.set(cacheKey, { link: fallbackLink, timestamp: Date.now() });
    return fallbackLink;

  } catch (error) {
    console.error('❌ Erro ao obter link do WhatsApp:', error);
    return 'https://chat.whatsapp.com/SEU_GRUPO_PADRAO';
  }
}
// Função para criar automaticamente todos os links do WhatsApp
async function createAllWhatsAppLinks() {
  try {
    if (!window.firebaseDb) {
      showNotification('Firebase não inicializado', 'error');
      return;
    }

    const { collection, addDoc, getDocs, query, where } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    
    // Definir todos os eventos e seus horários
    const eventConfigs = {
      'xtreino-tokens': {
        name: 'XTreino Freitas',
        schedules: ['14h', '15h', '16h', '17h', '18h', '19h', '20h', '21h', '22h', '23h'],
        defaultLink: 'https://chat.whatsapp.com/SEU_GRUPO_XTREINO_FREITAS'
      },
      'modo-liga': {
        name: 'XTreino Modo Liga',
        schedules: ['14h', '15h', '17h', '18h'],
        defaultLink: 'https://chat.whatsapp.com/SEU_GRUPO_MODO_LIGA'
      },
      'camp-freitas': {
        name: 'Campeonato Freitas Season⁴',
        schedules: ['20h', '21h', '22h', '23h'],
        defaultLink: 'https://chat.whatsapp.com/SEU_GRUPO_CAMP_FREITAS'
      },
      'semanal-freitas': {
        name: 'Semanal Freitas',
        schedules: ['19h', '20h', '21h', '22h'],
        defaultLink: 'https://chat.whatsapp.com/SEU_GRUPO_SEMANAL_FREITAS'
      }
    };

    const whatsappLinksRef = collection(window.firebaseDb, 'whatsapp_links');
    let createdCount = 0;
    let skippedCount = 0;

    for (const [eventType, config] of Object.entries(eventConfigs)) {
      // Criar link geral para o evento (sem horário específico)
      const generalQuery = query(
        whatsappLinksRef,
        where('eventType', '==', eventType),
        where('schedule', '==', null)
      );
      const generalSnapshot = await getDocs(generalQuery);
      
      if (generalSnapshot.empty) {
        await addDoc(whatsappLinksRef, {
          eventType: eventType,
          schedule: null,
          link: config.defaultLink,
          status: 'active',
          description: `Link geral para ${config.name}`,
          createdAt: new Date(),
          createdBy: 'system'
        });
        createdCount++;
        
      } else {
        skippedCount++;
        
      }

      // Criar links específicos para cada horário
      for (const schedule of config.schedules) {
        const specificQuery = query(
          whatsappLinksRef,
          where('eventType', '==', eventType),
          where('schedule', '==', schedule)
        );
        const specificSnapshot = await getDocs(specificQuery);
        
        if (specificSnapshot.empty) {
          await addDoc(whatsappLinksRef, {
            eventType: eventType,
            schedule: schedule,
            link: config.defaultLink,
            status: 'active',
            description: `${config.name} - ${schedule}`,
            createdAt: new Date(),
            createdBy: 'system'
          });
          createdCount++;
          
        } else {
          skippedCount++;
          
        }
      }
    }

    showNotification(`Links criados: ${createdCount} | Já existiam: ${skippedCount}`, 'success');
    
    // Recarregar a lista de links
    await loadAdminWhatsAppLinks();
    
  } catch (error) {
    console.error('Erro ao criar links automaticamente:', error);
    showNotification('Erro ao criar links automaticamente', 'error');
  }
}

// Variável para armazenar todos os links (para filtro)
let allWhatsAppLinks = [];

// Função para filtrar links do WhatsApp
function filterWhatsAppLinks() {
  const eventFilter = document.getElementById('whatsappEventFilter')?.value || '';
  const statusFilter = document.getElementById('whatsappStatusFilter')?.value || '';
  const searchFilter = document.getElementById('whatsappSearchFilter')?.value.toLowerCase() || '';
  
  
  
  let filteredLinks = allWhatsAppLinks.filter(link => {
    // Filtro por evento
    if (eventFilter && link.eventType !== eventFilter) {
      return false;
    }
    
    // Filtro por status
    if (statusFilter && link.status !== statusFilter) {
      return false;
    }
    
    // Filtro por busca (busca em eventType, schedule, link, description)
    if (searchFilter) {
      const searchText = `${link.eventType} ${link.schedule || ''} ${link.link} ${link.description || ''}`.toLowerCase();
      if (!searchText.includes(searchFilter)) {
        return false;
      }
    }
    
    return true;
  });
  
  
  
  // Renderizar apenas os links filtrados
  renderWhatsAppLinksTable(filteredLinks);
  renderWhatsAppLinksList(filteredLinks);
}

// Função para configurar os filtros
function setupWhatsAppFilters() {
  const eventFilter = document.getElementById('whatsappEventFilter');
  const statusFilter = document.getElementById('whatsappStatusFilter');
  const searchFilter = document.getElementById('whatsappSearchFilter');
  
  if (eventFilter) {
    eventFilter.addEventListener('change', filterWhatsAppLinks);
  }
  
  if (statusFilter) {
    statusFilter.addEventListener('change', filterWhatsAppLinks);
  }
  
  if (searchFilter) {
    searchFilter.addEventListener('input', filterWhatsAppLinks);
  }
}

// Expor funções globalmente
window.openWhatsAppLinksModal = openWhatsAppLinksModal;
window.closeWhatsAppLinksModal = closeWhatsAppLinksModal;
window.clearWhatsAppLinkForm = clearWhatsAppLinkForm;
window.saveWhatsAppLink = saveWhatsAppLink;
window.editWhatsAppLink = editWhatsAppLink;
window.deleteWhatsAppLink = deleteWhatsAppLink;
window.getWhatsAppLink = getWhatsAppLink;
window.createAllWhatsAppLinks = createAllWhatsAppLinks;
window.filterWhatsAppLinks = filterWhatsAppLinks;

// ==================== PAINEL DO AFILIADO ====================

// Carregar dados do painel de afiliado
async function loadAffiliatePanelData(affiliateId) {
  try {
    
    
    // Carregar vendas do afiliado
    const { collection, query, where, getDocs, orderBy } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const salesRef = collection(window.firebaseDb, 'affiliate_sales');
    const salesQuery = query(
      salesRef,
      where('affiliateId', '==', affiliateId),
      orderBy('createdAt', 'desc')
    );
    const salesSnap = await getDocs(salesQuery);
    
    const sales = [];
    salesSnap.forEach(doc => {
      const data = doc.data();
      sales.push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toDate() || new Date()
      });
    });
    
    // Atualizar estatísticas
    updateAffiliatePanelStats(sales);
    
    // Renderizar tabela de conversões
    renderAffiliatePanelSales(sales);
    
    // Configurar botão de solicitar pagamento
    setupPaymentRequestButton(affiliateId, sales);
    
    // Configurar filtro
    const filter = document.getElementById('affiliatePanelSalesFilter');
    if (filter) {
      filter.addEventListener('change', () => {
        renderAffiliatePanelSales(sales);
      });
    }
    
    
  } catch (error) {
    console.error('❌ Erro ao carregar dados do painel de afiliado:', error);
    const tbody = document.getElementById('affiliatePanelSalesTableBody');
    if (tbody) {
      tbody.innerHTML = '<tr><td colspan="7" class="py-6 text-center text-red-500">Erro ao carregar conversões</td></tr>';
    }
  }
}

// Atualizar estatísticas do painel
function updateAffiliatePanelStats(sales) {
  const totalSales = sales.length;
  const totalCommission = sales.reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
  const pendingCommission = sales
    .filter(s => s.status === 'pending')
    .reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
  const paidCommission = sales
    .filter(s => s.status === 'paid')
    .reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
  
  const totalSalesEl = document.getElementById('affiliatePanelTotalSales');
  const totalCommissionEl = document.getElementById('affiliatePanelTotalCommission');
  const pendingCommissionEl = document.getElementById('affiliatePanelPendingCommission');
  const paidCommissionEl = document.getElementById('affiliatePanelPaidCommission');
  const availableBalanceEl = document.getElementById('affiliatePanelAvailableBalance');
  
  if (totalSalesEl) totalSalesEl.textContent = totalSales;
  if (totalCommissionEl) totalCommissionEl.textContent = `R$ ${totalCommission.toFixed(2).replace('.', ',')}`;
  if (pendingCommissionEl) pendingCommissionEl.textContent = `R$ ${pendingCommission.toFixed(2).replace('.', ',')}`;
  if (paidCommissionEl) paidCommissionEl.textContent = `R$ ${paidCommission.toFixed(2).replace('.', ',')}`;
  if (availableBalanceEl) availableBalanceEl.textContent = `R$ ${pendingCommission.toFixed(2).replace('.', ',')}`;
}

// Renderizar vendas do afiliado
function renderAffiliatePanelSales(sales) {
  const tbody = document.getElementById('affiliatePanelSalesTableBody');
  if (!tbody) return;
  
  const filter = document.getElementById('affiliatePanelSalesFilter')?.value || 'all';
  const filteredSales = filter === 'all' ? sales : sales.filter(s => s.status === filter);
  
  if (filteredSales.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="py-6 text-center text-gray-500">Nenhuma conversão encontrada</td></tr>';
    return;
  }
  
  tbody.innerHTML = filteredSales.map(sale => {
    const date = sale.createdAt ? new Date(sale.createdAt).toLocaleDateString('pt-BR') : 'N/A';
    const statusBadge = sale.status === 'paid' 
      ? '<span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">Paga</span>'
      : '<span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs">Pendente</span>';
    
    const saleTypeIcon = sale.saleType === 'event' ? '📅' : sale.saleType === 'product' ? '🛒' : '📦';
    const saleTypeText = sale.saleType === 'event' ? 'Evento' : sale.saleType === 'product' ? 'Produto' : 'N/A';
    
    return `
      <tr class="border-b border-gray-100 hover:bg-gray-50">
        <td class="py-3 px-4 text-sm">${date}</td>
        <td class="py-3 px-4 text-sm">${sale.customerName || sale.customerEmail || 'N/A'}</td>
        <td class="py-3 px-4 text-sm">
          <div>${sale.productName || sale.productId || 'N/A'}</div>
          <div class="text-xs text-gray-500">${saleTypeIcon} ${saleTypeText}</div>
        </td>
        <td class="py-3 px-4 text-sm font-medium">R$ ${(sale.saleValue || 0).toFixed(2).replace('.', ',')}</td>
        <td class="py-3 px-4 text-sm">${(sale.commissionRate || 0).toFixed(1)}%</td>
        <td class="py-3 px-4 text-sm font-medium text-green-600">R$ ${(sale.commissionAmount || 0).toFixed(2).replace('.', ',')}</td>
        <td class="py-3 px-4 text-sm">${statusBadge}</td>
      </tr>
    `;
  }).join('');
}

// Configurar botão de solicitar pagamento
function setupPaymentRequestButton(affiliateId, sales) {
  const pendingCommission = sales
    .filter(s => s.status === 'pending')
    .reduce((sum, s) => sum + (s.commissionAmount || 0), 0);
  
  const minAmount = 25.00;
  const canRequest = pendingCommission >= minAmount;
  
  const form = document.getElementById('affiliatePaymentRequestForm');
  const message = document.getElementById('affiliatePaymentRequestMessage');
  const messageText = document.getElementById('affiliatePaymentRequestText');
  const amountInput = document.getElementById('affiliateRequestAmount');
  const submitBtn = document.getElementById('btnSubmitPaymentRequest');
  
  if (canRequest) {
    if (form) form.classList.remove('hidden');
    if (message) message.classList.add('hidden');
    if (amountInput) {
      amountInput.max = pendingCommission;
      amountInput.value = pendingCommission.toFixed(2);
    }
    
    if (submitBtn) {
      submitBtn.onclick = async () => {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processando...';
        try {
          await submitPaymentRequest(affiliateId, pendingCommission);
        } finally {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Solicitar Pagamento';
        }
      };
    }
  } else {
    if (form) form.classList.add('hidden');
    if (message) {
      message.classList.remove('hidden');
      if (messageText) {
        const missing = (minAmount - pendingCommission).toFixed(2);
        messageText.textContent = `Você precisa de mais R$ ${missing.replace('.', ',')} para solicitar pagamento. Valor mínimo: R$ 25,00`;
      }
    }
  }
}

// Solicitar pagamento
async function submitPaymentRequest(affiliateId, maxAmount) {
  try {
    const amountInput = document.getElementById('affiliateRequestAmount');
    const amount = parseFloat(amountInput?.value || 0);
    
    if (!amount || amount < 25.00) {
      alert('O valor mínimo para solicitação é R$ 25,00');
      return;
    }
    
    if (amount > maxAmount) {
      alert(`O valor solicitado não pode ser maior que o saldo disponível (R$ ${maxAmount.toFixed(2)})`);
      return;
    }
    
    if (!confirm(`Confirmar solicitação de pagamento no valor de R$ ${amount.toFixed(2).replace('.', ',')}?`)) {
      return;
    }
    
    // Criar solicitação de pagamento
    const { collection, addDoc, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
    const paymentRequestsRef = collection(window.firebaseDb, 'affiliate_payment_requests');
    
    await addDoc(paymentRequestsRef, {
      affiliateId: affiliateId,
      amount: amount,
      status: 'pending',
      requestedAt: serverTimestamp(),
      createdAt: new Date()
    });
    
    // Usar toast se disponível, senão alert
    if (typeof showSuccessToast === 'function') {
      showSuccessToast('Solicitação de pagamento enviada com sucesso! Aguarde a aprovação.', 'Sucesso');
    } else {
      alert('Solicitação de pagamento enviada com sucesso! Aguarde a aprovação.');
    }
    
    // Recarregar dados
    await loadAffiliatePanelData(affiliateId);
  } catch (error) {
    console.error('❌ Erro ao solicitar pagamento:', error);
    alert('Erro ao solicitar pagamento. Por favor, tente novamente.');
  }
}

// Expor funções globalmente
window.loadAffiliatePanelData = loadAffiliatePanelData;
window.submitPaymentRequest = submitPaymentRequest;

// ===== GERENCIAMENTO DE PRODUTOS =====

let productsData = [];
let productCounter = 1;

// Abrir modal de produtos
function openProductsModal() {
    loadProducts();
    const modal = document.getElementById('modalProducts');
    if (modal) modal.classList.remove('hidden');
}

// Fechar modal de produtos
function closeProductsModal() {
    const modal = document.getElementById('modalProducts');
    if (modal) modal.classList.add('hidden');
}

// Carregar produtos do Firestore
async function loadProducts() {
    try {
        const { collection, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const productsRef = collection(window.firebaseDb, 'products');
        const snapshot = await getDocs(productsRef);
        
        productsData = [];
        snapshot.forEach(doc => {
            productsData.push({ id: doc.id, ...doc.data() });
        });
        
        renderProducts();
    } catch (error) {
        console.error('Erro ao carregar produtos:', error);
        showToast('error', 'Erro ao carregar produtos', 'Erro');
    }
}

// Renderizar produtos na interface
function renderProducts() {
    const container = document.getElementById('productsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (productsData.length === 0) {
        container.innerHTML = '<div class="text-center py-8 text-gray-500">Nenhum produto cadastrado. Clique em "Adicionar" para criar um novo.</div>';
        return;
    }
    
    productsData.forEach((product, index) => {
        const productDiv = document.createElement('div');
        productDiv.className = 'bg-white border border-gray-200 rounded-lg p-6 mb-4';
        productDiv.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Nome do Produto</label>
                    <input type="text" value="${product.name || ''}" class="w-full border rounded px-3 py-2 text-sm" 
                           onchange="productsData[${index}].name = this.value" placeholder="Ex: Sensibilidade, Planilha">
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Descrição</label>
                    <input type="text" value="${product.description || ''}" class="w-full border rounded px-3 py-2 text-sm"
                           onchange="productsData[${index}].description = this.value" placeholder="Descrição breve">
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Preço (R$)</label>
                    <input type="number" value="${product.price || 0}" step="0.01" class="w-full border rounded px-3 py-2 text-sm"
                           onchange="productsData[${index}].price = parseFloat(this.value)" placeholder="0.00">
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Categoria</label>
                    <select onchange="productsData[${index}].category = this.value" class="w-full border rounded px-3 py-2 text-sm">
                        <option value="">Selecione</option>
                        <option value="digital" ${product.category === 'digital' ? 'selected' : ''}>Produto Digital</option>
                        <option value="physical" ${product.category === 'physical' ? 'selected' : ''}>Produto Físico</option>
                        <option value="service" ${product.category === 'service' ? 'selected' : ''}>Serviço</option>
                    </select>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                <div>
                    <label class="block text-xs text-gray-500 mb-1">URL da Imagem</label>
                    <input type="url" value="${product.image || ''}" class="w-full border rounded px-3 py-2 text-sm"
                           onchange="productsData[${index}].image = this.value" placeholder="https://...">
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Link de Download/Acesso</label>
                    <input type="url" value="${product.downloadLink || ''}" class="w-full border rounded px-3 py-2 text-sm"
                           onchange="productsData[${index}].downloadLink = this.value" placeholder="https://...">
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Status</label>
                    <select onchange="productsData[${index}].active = this.value === 'true'" class="w-full border rounded px-3 py-2 text-sm">
                        <option value="true" ${product.active !== false ? 'selected' : ''}>Ativo</option>
                        <option value="false" ${product.active === false ? 'selected' : ''}>Inativo</option>
                    </select>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div>
                    <label class="block text-xs text-gray-500 mb-1">Estoque (se aplicável)</label>
                    <input type="number" value="${product.stock || 0}" class="w-full border rounded px-3 py-2 text-sm"
                           onchange="productsData[${index}].stock = parseInt(this.value)" placeholder="0">
                </div>
                <div>
                    <label class="block text-xs text-gray-500 mb-1">ID do Produto (será salvo)</label>
                    <input type="text" value="${product.id || ''}" class="w-full border rounded px-3 py-2 text-sm bg-gray-100" disabled>
                </div>
            </div>
            <div class="mt-4 flex justify-end gap-2">
                <button onclick="deleteProduct(${index})" class="px-3 py-1 bg-red-100 text-red-700 rounded text-sm hover:bg-red-200">
                    <i class="fas fa-trash mr-1"></i>Excluir
                </button>
            </div>
        `;
        container.appendChild(productDiv);
    });
}

// Adicionar novo produto
function addProduct() {
    const newProduct = {
        id: `product_${Date.now()}`,
        name: '',
        description: '',
        price: 0,
        category: 'digital',
        image: '',
        downloadLink: '',
        active: true,
        stock: 0,
        createdAt: new Date()
    };
    
    productsData.push(newProduct);
    renderProducts();
    
    // Scroll para o novo produto
    setTimeout(() => {
        const container = document.getElementById('productsContainer');
        if (container) container.scrollTop = container.scrollHeight;
    }, 100);
}

// Deletar produto
function deleteProduct(index) {
    if (confirm('Tem certeza que deseja deletar este produto?')) {
        productsData.splice(index, 1);
        renderProducts();
    }
}

// Salvar produtos no Firestore
async function saveProducts() {
    try {
        if (productsData.length === 0) {
            showToast('warning', 'Nenhum produto para salvar', 'Aviso');
            return;
        }
        
        const { collection, doc, setDoc, deleteDoc, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const productsRef = collection(window.firebaseDb, 'products');
        
        // Primeiro, deletar produtos que foram removidos
        const existingSnap = await getDocs(productsRef);
        const existingIds = new Set(productsData.map(p => p.id));
        
        for (const existingDoc of existingSnap.docs) {
            if (!existingIds.has(existingDoc.id)) {
                await deleteDoc(doc(window.firebaseDb, 'products', existingDoc.id));
            }
        }
        
        // Salvar/atualizar produtos
        for (const product of productsData) {
            const productRef = doc(window.firebaseDb, 'products', product.id);
            const { id, ...productData } = product;
            await setDoc(productRef, {
                ...productData,
                updatedAt: new Date()
            });
        }
        
        showToast('success', `${productsData.length} produto(s) salvo(s) com sucesso!`, 'Sucesso');
        closeProductsModal();
    } catch (error) {
        console.error('Erro ao salvar produtos:', error);
        showToast('error', 'Erro ao salvar produtos: ' + error.message, 'Erro');
    }
}

// Expor funções globalmente
window.openProductsModal = openProductsModal;
window.closeProductsModal = closeProductsModal;
window.addProduct = addProduct;
window.deleteProduct = deleteProduct;

// ==================== ADMIN NOTIFICATION SYSTEM ====================

function toggleNotifUserField() {
    const target = document.getElementById('notifTarget');
    const row = document.getElementById('notifUserIdRow');
    if (!target || !row) return;
    if (target.value === 'user') {
        row.classList.remove('hidden');
    } else {
        row.classList.add('hidden');
    }
}

async function sendAdminNotification() {
    const titleEl = document.getElementById('notifTitle');
    const messageEl = document.getElementById('notifMessage');
    const targetEl = document.getElementById('notifTarget');
    const userIdEl = document.getElementById('notifUserId');

    if (!titleEl || !messageEl || !targetEl) return;

    const title = titleEl.value.trim();
    const message = messageEl.value.trim();
    const target = targetEl.value;
    const targetUserId = (target === 'user' && userIdEl) ? userIdEl.value.trim() : null;

    if (!title) { showToast('warning', 'Informe o título da notificação.', 'Atenção'); return; }
    if (!message) { showToast('warning', 'Informe a mensagem da notificação.', 'Atenção'); return; }
    if (target === 'user' && !targetUserId) { showToast('warning', 'Informe o UID do usuário destinatário.', 'Atenção'); return; }

    if (!window.firebaseDb) { showToast('error', 'Firebase não inicializado.', 'Erro'); return; }

    const btn = document.querySelector('[onclick="sendAdminNotification()"]');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Enviando...'; }

    try {
        const { collection, addDoc, serverTimestamp } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const user = window.firebaseAuth?.currentUser;

        await addDoc(collection(window.firebaseDb, 'notifications'), {
            title,
            message,
            type: target,
            targetUserId: targetUserId || null,
            createdAt: serverTimestamp(),
            createdBy: user ? (user.displayName || user.email || user.uid) : 'Admin',
            createdByUid: user ? user.uid : null
        });

        showToast('success', `Notificação enviada para ${target === 'all' ? 'todos os usuários' : 'usuário específico'}.`, 'Sucesso');
        titleEl.value = '';
        messageEl.value = '';
        if (userIdEl) userIdEl.value = '';
        await loadAdminNotifications();
    } catch (err) {
        console.error('Erro ao enviar notificação:', err);
        showToast('error', 'Erro ao enviar notificação: ' + (err.message || err), 'Erro');
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-paper-plane mr-2"></i>Enviar Notificação'; }
    }
}

async function loadAdminNotifications() {
    const listEl = document.getElementById('adminNotifList');
    if (!listEl) return;
    if (!window.firebaseDb) { listEl.innerHTML = '<p class="text-gray-400 text-sm text-center py-4">Firebase não disponível.</p>'; return; }

    listEl.innerHTML = '<div class="text-center text-gray-400 py-4 text-sm"><i class="fas fa-spinner fa-spin mr-2"></i>Carregando...</div>';

    try {
        const { collection, getDocs, query, orderBy, limit, deleteDoc, doc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const q = query(collection(window.firebaseDb, 'notifications'), orderBy('createdAt', 'desc'), limit(30));
        const snap = await getDocs(q);

        if (snap.empty) {
            listEl.innerHTML = '<p class="text-gray-400 text-sm text-center py-6">Nenhuma notificação enviada ainda.</p>';
            return;
        }

        listEl.innerHTML = snap.docs.map(d => {
            const n = d.data();
            const dateStr = n.createdAt ? new Date(n.createdAt.toDate ? n.createdAt.toDate() : n.createdAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-';
            const targetLabel = n.type === 'all' ? '<span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Todos</span>' : `<span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-mono">${n.targetUserId || 'Específico'}</span>`;
            return `<div class="flex items-start gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <div class="flex-1 min-w-0">
                    <div class="flex flex-wrap items-center gap-2 mb-1">
                        <span class="font-semibold text-sm text-gray-900">${escapeAdminHtml(n.title || '-')}</span>
                        ${targetLabel}
                    </div>
                    <p class="text-xs text-gray-600 leading-relaxed">${escapeAdminHtml(n.message || '')}</p>
                    <div class="text-xs text-gray-400 mt-1">Enviado em ${dateStr} por ${escapeAdminHtml(n.createdBy || 'Admin')}</div>
                </div>
                <button onclick="deleteAdminNotification('${d.id}')" title="Excluir" class="flex-shrink-0 text-red-400 hover:text-red-600 p-1">
                    <i class="fas fa-trash text-xs"></i>
                </button>
            </div>`;
        }).join('');
    } catch (err) {
        console.error('Erro ao carregar notificações:', err);
        listEl.innerHTML = '<p class="text-red-400 text-sm text-center py-4">Erro ao carregar notificações.</p>';
    }
}

async function deleteAdminNotification(notifId) {
    if (!notifId || !window.firebaseDb) return;
    if (!confirm('Tem certeza que deseja excluir esta notificação?')) return;
    try {
        const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        await deleteDoc(doc(window.firebaseDb, 'notifications', notifId));
        showToast('success', 'Notificação excluída.', 'Sucesso');
        await loadAdminNotifications();
    } catch (err) {
        console.error('Erro ao excluir notificação:', err);
        showToast('error', 'Erro ao excluir notificação.', 'Erro');
    }
}

function escapeAdminHtml(str) {
    if (!str) return '';
    return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

window.toggleNotifUserField = toggleNotifUserField;
window.sendAdminNotification = sendAdminNotification;
window.loadAdminNotifications = loadAdminNotifications;
window.deleteAdminNotification = deleteAdminNotification;
window.saveProducts = saveProducts;

// ============================================================
// GERENCIAR EVENTOS
// ============================================================

let currentEventTab = 'camp';

function openEventsModal() {
    const modal = document.getElementById('modalEvents');
    if (!modal) return;
    modal.classList.remove('hidden');
    switchEventTab('camp');
}

function closeEventsModal() {
    const modal = document.getElementById('modalEvents');
    if (modal) modal.classList.add('hidden');
    cancelEventForm();
}

function switchEventTab(tab) {
    currentEventTab = tab;
    const tabs = ['camp', 'xtreino', 'diario'];
    const titles = { camp: 'Campeonatos Criados', xtreino: 'X-Treinos Criados', diario: 'Diário Criados' };
    const activeClass = 'bg-white shadow text-orange-600';
    const inactiveClass = 'text-gray-600 hover:bg-white';

    tabs.forEach(t => {
        const btn = document.getElementById('evtTab-' + t);
        if (!btn) return;
        btn.className = 'flex-1 py-2 px-4 rounded-md text-sm font-semibold transition-all ' + (t === tab ? activeClass : inactiveClass);
    });

    const listTitle = document.getElementById('evtListTitle');
    if (listTitle) listTitle.textContent = titles[tab];

    // SOLO só disponível em CAMP
    const tipoWrapper = document.getElementById('evtTipoWrapper');
    const tipoSelect = document.getElementById('evtTipo');
    if (tab === 'camp') {
        if (tipoWrapper) tipoWrapper.style.display = '';
        if (tipoSelect) {
            tipoSelect.innerHTML = '<option value="SOLO">SOLO</option><option value="DUO">DUO</option><option value="SQUAD">SQUAD</option>';
        }
        const gruposWrapper = document.getElementById('evtGruposWrapper');
        if (gruposWrapper) gruposWrapper.style.display = '';
    } else {
        if (tipoWrapper) tipoWrapper.style.display = '';
        if (tipoSelect) {
            tipoSelect.innerHTML = '<option value="DUO">DUO</option><option value="SQUAD">SQUAD</option>';
        }
        const gruposWrapper = document.getElementById('evtGruposWrapper');
        if (gruposWrapper) gruposWrapper.style.display = 'none';
    }

    cancelEventForm();
    loadEventsList(tab);
}

function onEvtModoChange() {
    const modo = document.getElementById('evtModo')?.value;
    const hint = document.getElementById('evtVagasHint');
    if (!hint) return;
    if (modo === 'LIGA') {
        hint.textContent = 'Modo LIGA: deve ser 12 ou 15';
    } else {
        hint.textContent = 'Modo NORMAL: múltiplos de 12';
    }
}

function openNewEventForm() {
    document.getElementById('evtEditId').value = '';
    document.getElementById('evtEditCategory').value = currentEventTab;
    document.getElementById('evtFormTitle').textContent = 'Novo Evento';
    document.getElementById('evtName').value = '';
    document.getElementById('evtTipo').value = currentEventTab === 'camp' ? 'SOLO' : 'DUO';
    document.getElementById('evtModo').value = 'NORMAL';
    document.getElementById('evtStatus').value = 'Aberto';
    document.getElementById('evtPremiado').value = 'NÃO';
    document.getElementById('evtEntrada').value = 'GRÁTIS';
    document.getElementById('evtVagas').value = '';
    const gruposEl = document.getElementById('evtGrupos');
    if (gruposEl) gruposEl.value = '';
    document.getElementById('evtData').value = '';
    document.getElementById('evtDescricao').value = '';
    document.getElementById('evtFormError').classList.add('hidden');
    onEvtModoChange();
    document.getElementById('evtFormArea').scrollIntoView({ behavior: 'smooth' });
}

function cancelEventForm() {
    document.getElementById('evtEditId').value = '';
    document.getElementById('evtFormTitle').textContent = 'Novo Evento';
    document.getElementById('evtName').value = '';
    document.getElementById('evtVagas').value = '';
    const gruposEl = document.getElementById('evtGrupos');
    if (gruposEl) gruposEl.value = '';
    document.getElementById('evtData').value = '';
    document.getElementById('evtDescricao').value = '';
    document.getElementById('evtFormError').classList.add('hidden');
    // Limpar campos novos
    const precoInput = document.getElementById('evtPreco');
    if (precoInput) precoInput.value = '';
    const precoWrapper = document.getElementById('evtPrecoWrapper');
    if (precoWrapper) precoWrapper.style.display = 'none';
    clearEvtImage();
    const firstSize = document.querySelector('input[name="evtBannerSize"][value="1920x1080"]');
    if (firstSize) firstSize.checked = true;
}

function validateEventForm(category) {
    const name = document.getElementById('evtName').value.trim();
    const modo = document.getElementById('evtModo').value;
    const vagas = parseInt(document.getElementById('evtVagas').value, 10);

    if (!name) return 'Informe o nome do evento.';
    if (!vagas || vagas < 1) return 'Informe a quantidade de vagas.';

    if (modo === 'NORMAL') {
        if (vagas % 12 !== 0) return `Modo NORMAL: a quantidade de vagas deve ser múltiplo de 12. Você informou ${vagas}.`;
    } else if (modo === 'LIGA') {
        if (vagas !== 12 && vagas !== 15) return `Modo LIGA: a quantidade de vagas deve ser 12 ou 15. Você informou ${vagas}.`;
    }

    if (category === 'camp') {
        const grupos = parseInt(document.getElementById('evtGrupos')?.value, 10);
        if (!grupos || grupos < 1) return 'Informe a quantidade de grupos para o Campeonato.';
    }

    return null;
}

let _isSavingEvent = false;

// ---- Helpers de upload de imagem do evento ----
function onEvtEntradaChange() {
    const isPago = document.getElementById('evtEntrada').value === 'PAGO';
    const wrapper = document.getElementById('evtPrecoWrapper');
    if (wrapper) wrapper.style.display = isPago ? '' : 'none';
}

function onEvtImageSelected(input) {
    const file = input.files && input.files[0];
    if (!file) return;
    const preview = document.getElementById('evtImagePreview');
    const previewImg = document.getElementById('evtImagePreviewImg');
    const previewName = document.getElementById('evtImagePreviewName');
    if (preview && previewImg) {
        previewImg.src = URL.createObjectURL(file);
        if (previewName) previewName.textContent = file.name;
        preview.classList.remove('hidden');
    }
    document.getElementById('evtImageUrl').value = '';
    const urlDirect = document.getElementById('evtImageUrlDirect');
    if (urlDirect) urlDirect.value = '';
}

function onEvtImageUrlInput(input) {
    const url = input.value.trim();
    const preview = document.getElementById('evtImagePreview');
    const previewImg = document.getElementById('evtImagePreviewImg');
    const previewName = document.getElementById('evtImagePreviewName');
    const fileInput = document.getElementById('evtImageInput');
    if (url) {
        if (fileInput) fileInput.value = '';
        document.getElementById('evtImageUrl').value = url;
        if (previewImg) previewImg.src = url;
        if (previewName) previewName.textContent = 'Link direto';
        if (preview) preview.classList.remove('hidden');
    } else {
        document.getElementById('evtImageUrl').value = '';
        if (preview) preview.classList.add('hidden');
    }
}

function clearEvtImage() {
    const input = document.getElementById('evtImageInput');
    const preview = document.getElementById('evtImagePreview');
    const previewImg = document.getElementById('evtImagePreviewImg');
    if (input) input.value = '';
    if (previewImg) previewImg.src = '';
    if (preview) preview.classList.add('hidden');
    const urlField = document.getElementById('evtImageUrl');
    if (urlField) urlField.value = '';
    const urlDirect = document.getElementById('evtImageUrlDirect');
    if (urlDirect) urlDirect.value = '';
}

async function uploadEvtImage(file, eventId) {
    const { ref, uploadBytes, getDownloadURL } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-storage.js');
    const { getAuth } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-auth.js');

    // Diagnóstico: verificar auth e bucket
    const auth = getAuth(window.firebaseApp);
    const currentUser = auth.currentUser;
    const bucketUrl = window.firebaseStorage?._url || window.firebaseStorage?.app?.options?.storageBucket || 'desconhecido';
    console.log('[Storage Upload] Auth user:', currentUser ? currentUser.email : 'NÃO AUTENTICADO');
    console.log('[Storage Upload] Bucket:', bucketUrl);
    console.log('[Storage Upload] File:', file.name, file.size, 'bytes');

    if (!currentUser) {
        throw new Error('Usuário não autenticado. Faça login novamente.');
    }

    const path = `events/${eventId || ('new_' + Date.now())}_${file.name}`;
    console.log('[Storage Upload] Path:', path);
    const storageRef = ref(window.firebaseStorage, path);
    await uploadBytes(storageRef, file);
    const url = await getDownloadURL(storageRef);
    console.log('[Storage Upload] Sucesso! URL:', url);
    return url;
}
// ---- Fim helpers ----

async function saveEventForm() {
    if (_isSavingEvent) return;

    const category = currentEventTab;
    const error = validateEventForm(category);
    const errorEl = document.getElementById('evtFormError');

    if (error) {
        errorEl.textContent = error;
        errorEl.classList.remove('hidden');
        return;
    }
    errorEl.classList.add('hidden');

    const saveBtn = document.querySelector('#evtFormArea button[onclick="saveEventForm()"]');
    const originalHtml = saveBtn ? saveBtn.innerHTML : null;

    _isSavingEvent = true;
    if (saveBtn) {
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Salvando...';
    }

    const editId = document.getElementById('evtEditId').value;
    const bannerSizeEl = document.querySelector('input[name="evtBannerSize"]:checked');
    const entrada = document.getElementById('evtEntrada').value;

    const data = {
        category,
        name: document.getElementById('evtName').value.trim(),
        tipo: document.getElementById('evtTipo').value,
        modo: document.getElementById('evtModo').value,
        status: document.getElementById('evtStatus').value,
        premiado: document.getElementById('evtPremiado').value,
        entrada,
        vagas: parseInt(document.getElementById('evtVagas').value, 10),
        descricao: document.getElementById('evtDescricao').value.trim(),
        bannerSize: bannerSizeEl ? bannerSizeEl.value : '1920x1080',
        updatedAt: new Date().toISOString()
    };

    if (entrada === 'PAGO') {
        const preco = parseFloat(document.getElementById('evtPreco').value);
        if (preco > 0) data.preco = preco;
    } else {
        data.preco = null;
    }

    const dataVal = document.getElementById('evtData').value;
    if (dataVal) data.eventDate = new Date(dataVal).toISOString();

    if (category === 'camp') {
        data.grupos = parseInt(document.getElementById('evtGrupos')?.value, 10) || 0;
    }

    if (!editId) data.createdAt = new Date().toISOString();

    // Manter imageUrl existente como default
    const existingImageUrl = document.getElementById('evtImageUrl').value;
    if (existingImageUrl) data.imageUrl = existingImageUrl;

    try {
        // Fazer upload da imagem se uma nova foi selecionada
        const imageFile = document.getElementById('evtImageInput').files?.[0];
        if (imageFile && window.firebaseStorage) {
            if (saveBtn) saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-1"></i>Enviando imagem...';
            const tempId = editId || ('tmp_' + Date.now());
            try {
                data.imageUrl = await uploadEvtImage(imageFile, tempId);
            } catch (uploadErr) {
                console.error('Erro no upload da imagem:', uploadErr);
                showToast('warning', 'Imagem não enviada (permissão negada). O evento será salvo sem imagem. Verifique as regras do Firebase Storage.', 'Atenção');
                // Continua sem imageUrl — o evento é salvo mesmo assim
            }
        }

        const { collection, doc, addDoc, updateDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        if (editId) {
            await updateDoc(doc(window.firebaseDb, 'adminEvents', editId), data);
            showToast('success', 'Evento atualizado com sucesso.', 'Salvo');
        } else {
            await addDoc(collection(window.firebaseDb, 'adminEvents'), data);
            showToast('success', 'Evento criado com sucesso.', 'Criado');
        }
        cancelEventForm();
        await loadEventsList(category);
    } catch (err) {
        console.error('Erro ao salvar evento:', err);
        errorEl.textContent = 'Erro ao salvar evento: ' + (err.message || err);
        errorEl.classList.remove('hidden');
    } finally {
        _isSavingEvent = false;
        if (saveBtn) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = originalHtml || '<i class="fas fa-save mr-1"></i>Salvar Evento';
        }
    }
}

async function loadEventsList(category) {
    const listEl = document.getElementById('evtList');
    if (!listEl || !window.firebaseDb) return;
    listEl.innerHTML = '<div class="text-center py-8 text-gray-400"><i class="fas fa-spinner fa-spin text-2xl"></i></div>';

    try {
        const { collection, query, where, orderBy, getDocs } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const colRef = collection(window.firebaseDb, 'adminEvents');
        let snap;
        try {
            snap = await getDocs(query(colRef, where('category', '==', category), orderBy('createdAt', 'desc')));
        } catch (indexErr) {
            if (indexErr?.code === 'failed-precondition') {
                snap = await getDocs(query(colRef, where('category', '==', category)));
            } else {
                throw indexErr;
            }
        }

        if (snap.empty) {
            listEl.innerHTML = '<div class="text-center py-10 text-gray-400"><i class="fas fa-calendar-times text-3xl mb-2 block"></i>Nenhum evento cadastrado ainda.</div>';
            return;
        }

        const categoryLabels = { camp: 'CAMP', xtreino: 'XTREINO', diario: 'DIÁRIO' };
        const statusColors = {
            'Aberto': 'bg-green-100 text-green-700',
            'Em andamento': 'bg-blue-100 text-blue-700',
            'Fechado': 'bg-red-100 text-red-700'
        };

        listEl.innerHTML = snap.docs.map(d => {
            const ev = d.data();
            const statusCls = statusColors[ev.status] || 'bg-gray-100 text-gray-600';
            const dateStr = ev.eventDate ? new Date(ev.eventDate).toLocaleString('pt-BR') : '—';
            const gruposStr = category === 'camp' && ev.grupos ? `<span class="text-xs text-gray-500">Grupos: <b>${ev.grupos}</b></span>` : '';
            return `<div class="bg-white border border-gray-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-3">
                <div class="flex-1 min-w-0">
                    <div class="flex flex-wrap items-center gap-2 mb-1">
                        <span class="font-bold text-sm text-gray-800 truncate">${escapeAdminHtml(ev.name)}</span>
                        <span class="text-xs px-2 py-0.5 rounded-full font-semibold ${statusCls}">${ev.status || 'Aberto'}</span>
                        <span class="text-xs px-2 py-0.5 rounded-full bg-orange-100 text-orange-700 font-semibold">${ev.tipo}</span>
                        <span class="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">${ev.modo}</span>
                    </div>
                    <div class="flex flex-wrap gap-3 text-xs text-gray-500">
                        <span>Vagas: <b>${ev.vagas}</b></span>
                        ${gruposStr}
                        <span>Premiado: <b>${ev.premiado}</b></span>
                        <span>Entrada: <b>${ev.entrada}</b></span>
                        <span>Data: <b>${dateStr}</b></span>
                    </div>
                    ${ev.descricao ? `<p class="text-xs text-gray-400 mt-1 truncate">${escapeAdminHtml(ev.descricao)}</p>` : ''}
                </div>
                <div class="flex gap-2 flex-shrink-0">
                    <button onclick="editEventItem('${d.id}')" title="Editar" class="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-xs font-semibold hover:bg-blue-100">
                        <i class="fas fa-pen mr-1"></i>Editar
                    </button>
                    <button onclick="deleteEventItem('${d.id}')" title="Excluir" class="px-3 py-1.5 bg-red-50 text-red-600 rounded-lg text-xs font-semibold hover:bg-red-100">
                        <i class="fas fa-trash mr-1"></i>Excluir
                    </button>
                </div>
            </div>`;
        }).join('');
    } catch (err) {
        console.error('Erro ao carregar eventos:', err);
        listEl.innerHTML = '<div class="text-center py-8 text-red-400">Erro ao carregar eventos.</div>';
    }
}

async function editEventItem(eventId) {
    if (!window.firebaseDb) return;
    try {
        const { doc, getDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const snap = await getDoc(doc(window.firebaseDb, 'adminEvents', eventId));
        if (!snap.exists()) { showToast('error', 'Evento não encontrado.', 'Erro'); return; }
        const ev = snap.data();

        document.getElementById('evtEditId').value = eventId;
        document.getElementById('evtFormTitle').textContent = 'Editar Evento';
        document.getElementById('evtName').value = ev.name || '';
        document.getElementById('evtTipo').value = ev.tipo || 'SOLO';
        document.getElementById('evtModo').value = ev.modo || 'NORMAL';
        document.getElementById('evtStatus').value = ev.status || 'Aberto';
        document.getElementById('evtPremiado').value = ev.premiado || 'NÃO';
        document.getElementById('evtEntrada').value = ev.entrada || 'GRÁTIS';
        document.getElementById('evtVagas').value = ev.vagas || '';
        const gruposEl = document.getElementById('evtGrupos');
        if (gruposEl) gruposEl.value = ev.grupos || '';
        if (ev.eventDate) {
            const dt = new Date(ev.eventDate);
            const pad = n => String(n).padStart(2, '0');
            document.getElementById('evtData').value = `${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}T${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
        } else {
            document.getElementById('evtData').value = '';
        }
        document.getElementById('evtDescricao').value = ev.descricao || '';

        // Preço
        const precoInput = document.getElementById('evtPreco');
        if (precoInput) precoInput.value = ev.preco || '';
        onEvtEntradaChange();

        // Banner size
        if (ev.bannerSize) {
            const sizeRadio = document.querySelector(`input[name="evtBannerSize"][value="${ev.bannerSize}"]`);
            if (sizeRadio) sizeRadio.checked = true;
        }

        // Imagem existente
        clearEvtImage();
        if (ev.imageUrl) {
            const preview = document.getElementById('evtImagePreview');
            const previewImg = document.getElementById('evtImagePreviewImg');
            const previewName = document.getElementById('evtImagePreviewName');
            const urlField = document.getElementById('evtImageUrl');
            if (previewImg) previewImg.src = ev.imageUrl;
            if (previewName) previewName.textContent = 'Imagem atual';
            if (preview) preview.classList.remove('hidden');
            if (urlField) urlField.value = ev.imageUrl;
        }

        document.getElementById('evtFormError').classList.add('hidden');
        onEvtModoChange();
        document.getElementById('evtFormArea').scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
        console.error('Erro ao carregar evento para edição:', err);
        showToast('error', 'Erro ao carregar evento.', 'Erro');
    }
}

async function deleteEventItem(eventId) {
    if (!confirm('Tem certeza que deseja excluir este evento?')) return;
    try {
        const { doc, deleteDoc } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        await deleteDoc(doc(window.firebaseDb, 'adminEvents', eventId));
        showToast('success', 'Evento excluído.', 'Excluído');
        await loadEventsList(currentEventTab);
    } catch (err) {
        console.error('Erro ao excluir evento:', err);
        showToast('error', 'Erro ao excluir evento.', 'Erro');
    }
}

async function loadEventsPreview() {
    const previewEl = document.getElementById('eventsPreview');
    if (!previewEl || !window.firebaseDb) return;

    try {
        const { collection, getDocs, query, orderBy, limit } = await import('https://www.gstatic.com/firebasejs/10.13.0/firebase-firestore.js');
        const colRef = collection(window.firebaseDb, 'adminEvents');
        let snap;
        try {
            snap = await getDocs(query(colRef, orderBy('createdAt', 'desc'), limit(6)));
        } catch (indexErr) {
            if (indexErr?.code === 'failed-precondition') {
                snap = await getDocs(query(colRef, limit(6)));
            } else {
                throw indexErr;
            }
        }

        if (snap.empty) {
            previewEl.innerHTML = '<p class="text-sm text-gray-400 text-center py-3">Nenhum evento cadastrado. Clique em "Criar / Gerenciar" para começar.</p>';
            return;
        }

        const catLabel = { camp: '🏆 Campeonato', xtreino: '🎮 X-Treino', diario: '📅 Diário' };
        const statusColors = { 'Aberto': 'bg-green-100 text-green-700', 'Em andamento': 'bg-blue-100 text-blue-700', 'Fechado': 'bg-red-100 text-red-700' };

        previewEl.innerHTML = snap.docs.map(d => {
            const ev = d.data();
            const statusCls = statusColors[ev.status] || 'bg-gray-100 text-gray-600';
            const catStr = catLabel[ev.category] || ev.category;
            return `<div class="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                <div class="flex items-center gap-2 min-w-0">
                    <span class="text-xs text-gray-500 whitespace-nowrap">${catStr}</span>
                    <span class="font-medium text-sm truncate">${escapeAdminHtml(ev.name)}</span>
                    <span class="text-xs px-1.5 py-0.5 rounded-full ${statusCls} whitespace-nowrap">${ev.status || 'Aberto'}</span>
                </div>
                <span class="text-xs text-gray-400 whitespace-nowrap ml-2">${ev.tipo} · ${ev.modo} · ${ev.vagas} vagas</span>
            </div>`;
        }).join('');
    } catch (err) {
        const previewEl2 = document.getElementById('eventsPreview');
        if (previewEl2) previewEl2.innerHTML = '<p class="text-sm text-gray-400 text-center py-3">Não foi possível carregar eventos.</p>';
    }
}

window.loadEventsPreview = loadEventsPreview;
window.openEventsModal = openEventsModal;
window.closeEventsModal = closeEventsModal;
window.switchEventTab = switchEventTab;
window.onEvtModoChange = onEvtModoChange;
window.openNewEventForm = openNewEventForm;
window.cancelEventForm = cancelEventForm;
window.saveEventForm = saveEventForm;
window.editEventItem = editEventItem;
window.deleteEventItem = deleteEventItem;
window.onEvtImageSelected = onEvtImageSelected;
window.onEvtImageUrlInput = onEvtImageUrlInput;
window.clearEvtImage = clearEvtImage;
window.onEvtEntradaChange = onEvtEntradaChange;